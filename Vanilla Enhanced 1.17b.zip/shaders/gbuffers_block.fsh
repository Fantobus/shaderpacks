#version 120

uniform sampler2D texture;
uniform sampler2D lightmap;

uniform float frameTimeCounter;
uniform int worldTime;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 worldPos;
varying float blockId;

vec3 saturation(vec3 color, float sat) {
    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    return mix(vec3(gray), color, sat);
}

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb;
    
    if (color.a < 0.1) discard;
    
    color.rgb *= lightmapColor;
    
    // Yağmur efekti
    if (rainStrength > 0.01) {
        color.rgb = saturation(color.rgb, 1.0 - rainStrength * 0.15);
    }
    
    color.rgb = pow(color.rgb, vec3(0.88));
    
    gl_FragColor = color;
}