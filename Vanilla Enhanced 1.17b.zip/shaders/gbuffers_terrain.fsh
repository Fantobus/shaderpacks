#version 120

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D normals;
uniform sampler2D specular;

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int worldTime;
uniform float rainStrength;
uniform float wetness;
uniform int isEyeInWater;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;

uniform ivec2 eyeBrightnessSmooth;
uniform float near;
uniform float far;

// Shader options
const float PBR_STRENGTH = 1.0;
const float FOG_DENSITY = 1.0;
const float FOG_START = 0.5;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

const float PI = 3.14159265359;

// ============================================================================
// NOISE
// ============================================================================

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float calculateUnderwaterCaustics(vec3 wp, float time) {
    vec2 uv = wp.xz * 0.3;
    float c1 = noise(uv + time * 0.05);
    c1 = pow(max(c1, 0.0), 2.5) * 1.8;
    vec2 uv2 = wp.xz * 0.45 - time * 0.08;
    float c2 = noise(uv2);
    c2 = pow(max(c2, 0.0), 3.5) * 1.5;
    float caustics = (c1 + c2) * 0.5;
    float wave = sin(wp.x * 0.4 + time * 0.6) * cos(wp.z * 0.4 - time * 0.5);
    caustics *= (1.0 + wave * 0.4);
    return caustics;
}

// ============================================================================
// COLOR UTILS
// ============================================================================

vec3 saturation(vec3 color, float sat) {
    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    return mix(vec3(gray), color, sat);
}

vec3 contrast(vec3 color, float cont) {
    return (color - 0.5) * cont + 0.5;
}

vec3 getSmoothDayNightColor() {
    vec3 morningColor = vec3(0.82, 0.72, 0.82);
    vec3 dayColor     = vec3(0.92, 0.82, 0.92);
    vec3 eveningColor = vec3(0.78, 0.58, 0.48);
    vec3 nightColor   = vec3(0.58, 0.72, 0.68);
    if (worldTime <= 6000) {
        float t = smoothstep(500.0, 6000.0, float(worldTime));
        return mix(morningColor, dayColor, t);
    } else if (worldTime <= 13000) {
        return dayColor;
    } else if (worldTime <= 18000) {
        float t = smoothstep(13000.0, 18000.0, float(worldTime));
        return mix(dayColor, eveningColor, t);
    } else {
        float t = smoothstep(18000.0, 23000.0, float(worldTime));
        return mix(eveningColor, nightColor, t);
    }
}

vec3 depthColorGrading(vec3 color, vec3 vp, float skyLight) {
    float distance = length(vp);
    float depthFactor = clamp(distance / 18.0, 0.0, 1.0);
    vec3 distantColor = mix(color, vec3(0.62, 0.72, 0.92), depthFactor * 0.12);
    if (skyLight < 0.35) {
        vec3 warmTint = vec3(1.08, 0.96, 0.82);
        distantColor *= mix(vec3(1.0), warmTint, depthFactor * 0.18);
    }
    return distantColor;
}

// ============================================================================
// PBR — TÜM YÖNLERDEN IŞIK (DÜZELTME)
// ============================================================================

vec3 dynamicPBR(vec3 color, vec3 n, vec3 wp, vec3 viewDir, float skyLight, float blockLight) {
    // Normal map
    vec3 normalMap = texture2D(normals, texcoord).rgb;
    vec3 enhancedNormal = normalize(n);
    if (length(normalMap - 0.5) > 0.01) {
        normalMap = normalMap * 2.0 - 1.0;
        enhancedNormal = normalize(n + normalMap * 0.45);
    }

    float brightness = dot(color, vec3(0.299, 0.587, 0.114));
    float metallic   = brightness > 0.52 ? 0.72 : 0.0;
    vec3 specColor   = mix(vec3(0.04), color, metallic);
    vec3 totalSpec   = vec3(0.0);

    float skyLightWeight = smoothstep(0.10, 0.50, skyLight);

    // ----------------------------------------------------------------
    // GÜNEŞ / AY IŞIĞI — view-space'ten düzgün world-space'e çevir
    // ----------------------------------------------------------------
    if (skyLightWeight > 0.0) {
        bool isDay = (worldTime >= 0 && worldTime <= 12000) ||
                     (worldTime >= 23000 && worldTime <= 24000);

        vec3 lightViewDir;
        if (isDay) {
            // sunPosition view-space'te geliyor, normalize et
            lightViewDir = length(sunPosition) > 0.1
                ? normalize(sunPosition)
                : normalize(vec3(0.0, 1.0, 0.3));
        } else {
            lightViewDir = length(moonPosition) > 0.1
                ? normalize(moonPosition)
                : normalize(vec3(0.0, 0.6, -0.8));
        }

        // View-space -> world-space dönüşümü (rotasyon kısmı)
        vec3 lightDir = normalize((gbufferModelViewInverse * vec4(lightViewDir, 0.0)).xyz);

        float NdotL = max(dot(enhancedNormal, lightDir), 0.0);

        vec3 reflDir = reflect(-lightDir, enhancedNormal);
        float VdotR  = max(dot(viewDir, reflDir), 0.0);
        float specPow = isDay ? 72.0 : 36.0;
        float spec   = pow(VdotR, specPow);

        vec3 lightColor = getSmoothDayNightColor();
        float lightInt  = isDay ? 1.05 : 0.42;

        // Fresnel approximation (Schlick)
        float fresnel = pow(1.0 - max(dot(viewDir, enhancedNormal), 0.0), 5.0);
        vec3 F = mix(specColor, vec3(1.0), fresnel);

        totalSpec += F * spec * skyLightWeight * lightColor * NdotL * lightInt * PBR_STRENGTH;

        // Ambient diffuse — gökyüzünden gelen dolaylı ışık (omnidirectional)
        float ambientUp   = max(dot(enhancedNormal, vec3(0.0, 1.0, 0.0)), 0.0);
        float ambientDown = max(dot(enhancedNormal, vec3(0.0, -1.0, 0.0)), 0.0) * 0.2;
        float ambientSide = (1.0 - ambientUp - ambientDown) * 0.5;
        float ambientFactor = ambientUp + ambientDown + ambientSide;
        vec3 ambientColor = lightColor * ambientFactor * skyLightWeight * 0.18;
        totalSpec += color * ambientColor;
    }

    // ----------------------------------------------------------------
    // TORCH IŞIĞI — pozisyona değil, yüzeyin bulunduğu noktaya göre
    // omnidirectional torch: tüm yönlerden eşit etkiler
    // ----------------------------------------------------------------
    float blockLightWeight = smoothstep(0.10, 0.40, blockLight);
    if (blockLightWeight > 0.0) {
        vec3 torchColor = vec3(0.82, 0.42, 0.22);
        float torchIntensity = blockLightWeight * blockLightWeight;

        // Omnidirectional: her yön bileşenini topla
        float diffX_pos = max(dot(enhancedNormal, vec3( 1.0, 0.0, 0.0)), 0.0);
        float diffX_neg = max(dot(enhancedNormal, vec3(-1.0, 0.0, 0.0)), 0.0);
        float diffY_pos = max(dot(enhancedNormal, vec3( 0.0, 1.0, 0.0)), 0.0);
        float diffY_neg = max(dot(enhancedNormal, vec3( 0.0,-1.0, 0.0)), 0.0);
        float diffZ_pos = max(dot(enhancedNormal, vec3( 0.0, 0.0, 1.0)), 0.0);
        float diffZ_neg = max(dot(enhancedNormal, vec3( 0.0, 0.0,-1.0)), 0.0);

        // 6 yönün ortalaması — gerçek bir point light'a yakın
        float omniDiff = (diffX_pos + diffX_neg + diffY_pos + diffY_neg + diffZ_pos + diffZ_neg) / 3.0;
        omniDiff = max(omniDiff, 0.25); // minimum ambient torch

        // Speküler: en dominant yönden
        // Torch'un "varsayılan" konumu yüzeyin biraz üstünde
        vec3 toTorch = normalize(vec3(0.0, 1.0, 0.0)); // yukarıdan gelen (genel)
        vec3 torchReflDir = reflect(-toTorch, enhancedNormal);
        float torchVdotR  = max(dot(viewDir, torchReflDir), 0.0);
        float torchSpec   = pow(torchVdotR, 18.0);

        // Rim light (kenar aydınlatma)
        float rimFactor = 1.0 - max(dot(viewDir, enhancedNormal), 0.0);
        float rimLight  = pow(rimFactor, 3.2) * 0.28;

        totalSpec += (specColor * torchSpec * omniDiff + rimLight) 
                     * torchIntensity * torchColor * PBR_STRENGTH;
    }

    return color + totalSpec;
}

// ============================================================================
// FOG — GERÇEKÇİ ATMOSFERİK SIS
// ============================================================================

vec3 calculateFog(vec3 color, vec3 vp) {
    float dist = length(vp);

    // Exponential-squared fog (gerçekçi atmosfer)
    float fogDensity = 0.0055 * FOG_DENSITY;
    if (rainStrength > 0.0) fogDensity *= (1.0 + rainStrength * 3.5); // yağmurda sis artar

    float fogFactor = 1.0 - exp(-fogDensity * fogDensity * dist * dist);
    fogFactor = clamp(fogFactor, 0.0, 0.85);

    // FOG_START ayarı — yakın mesafede sis başlatma
    float fogStart = far * 0.4 * FOG_START;
    fogFactor *= smoothstep(fogStart, far * 0.9, dist);

    // Sis rengi gün/gece durumuna göre değişir
    bool isDay = (worldTime >= 0 && worldTime <= 12000) || worldTime >= 23000;
    vec3 fogColorDay   = vec3(0.75, 0.82, 0.92);
    vec3 fogColorNight = vec3(0.08, 0.10, 0.18);
    vec3 fogColorRain  = vec3(0.42, 0.44, 0.48);

    // Gündoğumu/batımı geçişleri
    float dayF = isDay ? 1.0 : 0.0;
    float sunriseT = smoothstep(22500.0, 24000.0, float(worldTime));
    float sunsetT  = smoothstep(11000.0, 13500.0, float(worldTime));
    float twilight = max(sunriseT, sunsetT);

    vec3 fogColor = mix(fogColorNight, fogColorDay, dayF);
    vec3 duskFog  = vec3(0.85, 0.62, 0.42);
    fogColor = mix(fogColor, duskFog, twilight * 0.5);
    fogColor = mix(fogColor, fogColorRain, rainStrength * 0.6);

    return mix(color, fogColor, fogFactor);
}

// ============================================================================
// MAIN
// ============================================================================

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb;

    if (color.a < 0.1) discard;

    float skyLight   = lmcoord.y;
    float blockLight = lmcoord.x;
    
    // ============ METALLIC TANIMI (YENİ) ============
    float brightness = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    float metallic = brightness > 0.52 ? 0.72 : 0.0;
    // ================================================

    float dayNightBlend = smoothstep(0.08, 0.9, skyLight);
    vec3 dayNightTint   = mix(vec3(1.0), getSmoothDayNightColor(), dayNightBlend);

    vec3 viewDir     = normalize(-viewPos);
    float lightStrength = max(max(skyLight, blockLight), 0.12);

    color.rgb = depthColorGrading(color.rgb, viewPos, skyLight);

    float pbrThreshold = smoothstep(0.18, 0.45, lightStrength);
    if (pbrThreshold > 0.0) {
        vec3 pbrResult   = dynamicPBR(color.rgb, normal, worldPos, viewDir, skyLight, blockLight);
        float pbrStrength = smoothstep(0.32, 0.82, lightStrength);
        color.rgb = mix(color.rgb, pbrResult, pbrStrength * pbrThreshold * 2.1);
    }

    color.rgb *= dayNightTint;

    vec3 enhancedLightmap = pow(lightmapColor, vec3(0.88)) * 0.9;
    color.rgb *= enhancedLightmap;

    float torchGlow = smoothstep(0.28, 0.70, blockLight) * 0.20;
    color.rgb += vec3(1.0, 0.58, 0.32) * torchGlow;

    if (rainStrength > 0.01) {
        color.rgb = saturation(color.rgb, 1.0 - rainStrength * 0.16);
    }

    // =========================================================================
    // FOG — su altı değilse uygula
    // =========================================================================
    if (isEyeInWater != 1) {
        color.rgb = calculateFog(color.rgb, viewPos);
    }

    // =========================================================================
    // SU ALTI
    // =========================================================================
    if (isEyeInWater == 1) {
        float time = frameTimeCounter;
        float distance = length(viewPos);

        vec3 waterTint = (worldTime >= 6000 && worldTime <= 18000)
            ? vec3(0.48, 0.72, 1.0)
            : vec3(0.35, 0.52, 0.75);

        color.rgb *= waterTint;

        float caustics = calculateUnderwaterCaustics(worldPos, time);
        float causticsStrength = 0.0;
        if (worldTime >= 6000 && worldTime <= 18000) {
            causticsStrength = smoothstep(0.15, 0.45, skyLight) * 0.8;
            causticsStrength *= exp(-distance * 0.08);
        }
        color.rgb += vec3(0.95, 1.0, 1.0) * caustics * causticsStrength;

        float depthFade = exp(-distance * 0.045);
        vec3 deepWaterColor = vec3(0.08, 0.22, 0.42);
        if (worldTime < 6000 || worldTime > 18000) deepWaterColor *= 0.5;
        color.rgb = mix(deepWaterColor, color.rgb, depthFade);

        float particleNoise = noise(worldPos.xz * 0.5 + time * 0.02);
        particleNoise += noise(worldPos.xz * 1.2 - time * 0.03) * 0.5;
        particleNoise *= exp(-distance * 0.1);
        color.rgb += vec3(0.6, 0.75, 0.85) * particleNoise * 0.03;

        if (skyLight > 0.4) {
            vec3 viewRay = normalize(viewPos);
            float godRays = abs(sin(worldPos.x * 0.1 + time * 0.1) * cos(worldPos.z * 0.1 - time * 0.08));
            godRays *= pow(max(viewRay.y, 0.0), 2.0);
            godRays *= exp(-distance * 0.1);
            color.rgb += vec3(0.7, 0.85, 1.0) * godRays * skyLight * 0.15;
        }
    }

    color.rgb = contrast(color.rgb, 1.3);
    color.rgb = saturation(color.rgb, 1.42);


    // G‑buffer ek yazmaçları (composite için)
    // colortex1: world‑space normal
    // colortex1: world‑space normal (0‑1 range)
    // G-buffer çıktıları

    gl_FragData[1] = vec4(normal.x * 0.5 + 0.5, normal.y * 0.5 + 0.5, metallic, 0.5);


    float near = 0.05;
    float far = 256.0;
    float packedWorldY = (worldPos.y + 64.0) / 256.0;
    gl_FragData[2] = vec4(worldPos.xz * 0.05 + 0.5, packedWorldY, 1.0);
    gl_FragColor = color;
}