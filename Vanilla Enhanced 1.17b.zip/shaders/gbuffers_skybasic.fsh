#version 120

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform int worldTime;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec3 viewDir;
varying vec4 glcolor;

const float PI = 3.14159265359;

// ============================================================================
// NOISE / FBM
// ============================================================================

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    // Quintic interpolation — cubic'e göre daha yumuşak kenarlar
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm(vec2 p) {
    float value     = 0.0;
    float amplitude = 0.52;
    float frequency = 1.0;
    float weight    = 0.0;

    for (int i = 0; i < 6; i++) {
        value     += amplitude * noise(p * frequency);
        weight    += amplitude;
        amplitude *= 0.48;   // biraz daha yavaş düşüyor → daha geniş bulut kitleleri
        frequency *= 2.1;
    }
    return value / weight;   // normalize — her zaman [0,1] aralığında kalır
}

// ============================================================================
// ZAMAN
// ============================================================================

// worldTime'ı [0,1] aralığında döner
float normTime() {
    return float(worldTime) / 24000.0;
}

// Belirli bir zaman etrafında smooth tepecik: width = yarı-genişlik (normalize)
float timePeak(float centerTime, float halfWidth) {
    float nt  = normTime();
    float nc  = centerTime / 24000.0;
    float hw  = halfWidth  / 24000.0;

    float diff = abs(nt - nc);
    if (diff > 0.5) diff = 1.0 - diff;  // dairesel wrap

    return smoothstep(hw, 0.0, diff);
}

// 0=gece, 1=gündüz — cosine tabanlı, sürekli
float dayFraction() {
    float cycle = cos((normTime() - 0.25) * 2.0 * PI);
    return clamp((cycle + 1.0) * 0.5, 0.0, 1.0);
}

// ============================================================================
// GÖK GRADİENT
// ============================================================================

vec3 calculateSkyGradient(vec3 dir) {
    float altitude = clamp(dir.y, 0.0, 1.0);

    // Temel gündüz/gece renkleri
    vec3 dayZenith    = vec3(0.18, 0.42, 0.82);   // koyu mavi
    vec3 dayHorizon   = vec3(0.60, 0.78, 0.95);   // açık mavi-beyaz
    vec3 nightZenith  = vec3(0.02, 0.04, 0.12);
    vec3 nightHorizon = vec3(0.06, 0.08, 0.16);

    float dayF = pow(dayFraction(), 1.15);

    vec3 zenith  = mix(nightZenith,  dayZenith,  dayF);
    vec3 horizon = mix(nightHorizon, dayHorizon, dayF);

    // Altitude curve: pow < 1 → horizon bandı daha geniş
    vec3 sky = mix(horizon, zenith, pow(altitude, 0.65));

    // Şafak / gün batımı tonu — horizon seviyesinde en güçlü
    float sunrisePeak = timePeak(23500.0, 1800.0);
    float sunsetPeak  = timePeak(12500.0, 1800.0);
    float twilight    = max(sunrisePeak, sunsetPeak);

    vec3 sunriseHue = vec3(0.95, 0.52, 0.22);
    vec3 sunsetHue  = vec3(0.88, 0.38, 0.18);
    vec3 duskHue    = mix(sunriseHue, sunsetHue, sunsetPeak / max(twilight, 0.001));

    // Horizon'a yakın yoğun, yukarıya doğru söner
    float horizonMask = pow(1.0 - altitude, 2.8) * twilight;
    sky = mix(sky, duskHue, horizonMask * 0.72);

    // Gün batımı / şafak'ta zenitde hafif pembe/mor yansıma
    sky = mix(sky, vec3(0.55, 0.38, 0.62), horizonMask * altitude * 0.25);

    return clamp(sky, 0.0, 1.0);
}

// ============================================================================
// BULUTLAR
// ============================================================================

vec3 renderClouds(vec3 skyColor, vec3 dir) {
    // Ufkun altı ve çok dik yukarısı — bulut yok
    // Eski: smoothstep(0.05, 0.35) * smoothstep(0.75, 0.5) → dar bant, patlak kenarlar
    // Yeni: daha geniş ve yumuşak maske
    float cloudMask = smoothstep(0.0, 0.18, dir.y) *    // ufuktan yumuşak çıkış
                      smoothstep(1.0, 0.55, dir.y);     // zenitten yumuşak düşüş

    if (cloudMask < 0.005) return skyColor;

    float time   = frameTimeCounter * 0.008;  // daha yavaş = daha doğal hareket
    float invY   = 1.0 / max(dir.y, 0.08);   // perspektif projeksiyon
    vec2  cloudUV = dir.xz * invY * 0.55;

    // İki katmanlı FBM — farklı hız ve ölçek → daha organik görünüm
    vec2 offset1 = vec2(time * 0.22, time * 0.11);
    vec2 offset2 = vec2(-time * 0.14, time * 0.07);

    float layer1 = fbm(cloudUV * 1.10 + offset1);
    float layer2 = fbm(cloudUV * 0.65 + offset2) * 0.5;
    float raw    = (layer1 + layer2) / 1.5;

    // Threshold: smoothstep ile yumu geçiş — eskiden hard (0.48, 0.82)
    // Genişletilmiş aralık → daha az kesik kenar
    float clouds = smoothstep(0.40, 0.72, raw);
    clouds *= cloudMask;

    if (clouds < 0.008) return skyColor;

    // ----------------------------------------------------------------
    // BULUT RENGİ — additive karıştırma yerine tek bir lerp zinciri
    // ----------------------------------------------------------------
    float dayF      = dayFraction();
    float sunriseF  = timePeak(23500.0, 1800.0);
    float sunsetF   = timePeak(12500.0, 1800.0);
    float twilightF = max(sunriseF, sunsetF);
    float nightF    = 1.0 - clamp(dayF + twilightF, 0.0, 1.0);

    // Bulutun yoğunluğuna göre: ince bulut aydınlık, kalın bulut koyu
    // pow(clouds, k) → bulut içindeki ton farkı
    float thinThick = 1.0 - pow(clouds, 1.6);

    vec3 dayLight   = mix(vec3(0.55, 0.58, 0.64), vec3(0.96, 0.96, 0.94), thinThick);
    vec3 sunriseCol = mix(vec3(0.40, 0.30, 0.32), vec3(0.94, 0.70, 0.52), thinThick);
    vec3 sunsetCol  = mix(vec3(0.38, 0.26, 0.28), vec3(0.88, 0.52, 0.36), thinThick);
    vec3 nightCol   = mix(vec3(0.06, 0.08, 0.12), vec3(0.16, 0.20, 0.28), thinThick);

    // Önce gündüz/gece, sonra üstüne alacakaranlık geçişi
    vec3 duskCol    = mix(sunriseCol, sunsetCol, sunsetF / max(twilightF, 0.001));
    vec3 cloudColor = mix(nightCol, dayLight, dayF);
        cloudColor  = mix(cloudColor, duskCol, twilightF * 0.78);

    // Yağmurda bulutlar kurşuni
    cloudColor = mix(cloudColor, vec3(0.38, 0.40, 0.44), rainStrength * 0.55);

    // Gökyüzü-bulut karışımı: gökyüzü tamamen silinmiyor (0.92 max)
    float cloudOpacity = clouds * mix(0.88, 0.72, twilightF);
    skyColor = mix(skyColor, cloudColor, cloudOpacity);

    // Çok ince bulut kenarlarında gökyüzü rengi hafifçe parlar
    skyColor *= (1.0 - clouds * 0.12);

    return skyColor;
}

// ============================================================================
// MAIN
// ============================================================================

void main() {
    vec3 dir = normalize(viewDir);
    
    vec3 skyColor = calculateSkyGradient(dir);
    skyColor = renderClouds(skyColor, dir);
    
    // Yağmur — hafif gri örtü
    if (rainStrength > 0.0) {
        skyColor *= mix(1.0, 0.62, rainStrength);
        skyColor  = mix(skyColor, vec3(0.36, 0.38, 0.42), rainStrength * 0.28);
    }
    
    // Gamma: hafif lift, fazla parlak değil
    skyColor = pow(clamp(skyColor, 0.0, 1.0), vec3(0.88));
    
    gl_FragColor = vec4(skyColor, 1.0);
}
