#version 120

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;
varying float blockId;

void main() {
    blockId = mc_Entity.x;
    
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    
    normal = normalize(gl_NormalMatrix * gl_Normal);
    
    vec4 position = gl_Vertex;
    vec4 viewPosition = gbufferModelView * position;
    
    worldPos = (gbufferModelViewInverse * viewPosition).xyz + cameraPosition;
    viewPos = viewPosition.xyz;
    
    gl_Position = gl_ProjectionMatrix * viewPosition;
}