#version 120

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D normals;

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform float frameTimeCounter;
uniform int worldTime;
uniform float rainStrength;
uniform mat4 gbufferModelViewInverse;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;

const float PI = 3.14159265359;

// ============================================================================
// UTILITY
// ============================================================================

vec3 saturation(vec3 color, float sat) {
    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    return mix(vec3(gray), color, sat);
}

// ============================================================================
// MOB EYE GLOW (Canlı göz parlaması - Enderman, Spider, etc)
// ============================================================================

vec3 getEyeGlow(vec2 coord, vec3 color, float lightLevel) {
    // Kırmızı gözler için (Enderman, Spider)
    if (color.r > 0.6 && color.g < 0.3 && color.b < 0.3 && lightLevel < 0.5) {
        float pulse = sin(frameTimeCounter * 2.0) * 0.3 + 0.7;
        return color + vec3(0.3, 0.05, 0.05) * pulse;
    }
    
    // Yeşil gözler (örümcek gözleri)
    if (color.g > 0.5 && color.r < 0.4 && color.b < 0.4) {
        float pulse = sin(frameTimeCounter * 2.5) * 0.2 + 0.8;
        return color + vec3(0.02, 0.25, 0.02) * pulse;
    }
    
    return color;
}

// ============================================================================
// MOB OUTLINE (Kenar çizgisi)
// ============================================================================

vec3 getMobOutline(vec3 color, vec3 normal, vec3 viewDir) {
    float rim = 1.0 - max(0.0, dot(normal, viewDir));
    rim = pow(rim, 2.0) * 0.3;
    
    // Geceleyin rim daha belirgin
    bool isNight = (worldTime >= 13000 && worldTime <= 23000);
    if (isNight) rim *= 1.5;
    
    return color + vec3(0.15, 0.1, 0.05) * rim;
}

// ============================================================================
// MAIN
// ============================================================================

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb;
    
    if (color.a < 0.1) discard;
    
    float skyLight = lmcoord.y;
    float blockLight = lmcoord.x;
    float totalLight = max(skyLight, blockLight);
    
    vec3 viewDir = normalize(-viewPos);
    vec3 worldNormal = normalize(normal);
    
    // Göz parlaması
    color.rgb = getEyeGlow(texcoord, color.rgb, totalLight);
    
    // Kenar çizgisi efekti
    color.rgb = getMobOutline(color.rgb, worldNormal, viewDir);
    
    // Lightmap uygula
    color.rgb *= lightmapColor;
    
    // Gündüz/gece renk tonlaması
    bool isDay = (worldTime >= 0 && worldTime <= 12000) || worldTime >= 23000;
    if (!isDay && totalLight < 0.3) {
        // Gece renkleri - mavimsi ton
        color.rgb = mix(color.rgb, vec3(0.45, 0.55, 0.75), 0.25);
    }
    
    // Yağmur etkisi
    if (rainStrength > 0.01) {
        color.rgb = saturation(color.rgb, 1.0 - rainStrength * 0.25);
        color.rgb *= mix(1.0, 0.75, rainStrength * 0.5);
    }
    
    // Gamma
    color.rgb = pow(color.rgb, vec3(0.88));
    
    gl_FragColor = color;
}