#version 120

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int worldTime;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;

// ============================================================================
// ENTITY ANIMATION (Canlı animasyonları)
// ============================================================================

vec3 getEntityAnimation(vec3 position, vec3 worldPosition, float entityId) {
    float time = frameTimeCounter;
    
    // Sallanan efekt (villager, zombie, etc)
    float bob = sin(time * 2.5) * 0.01;
    float sway = sin(time * 1.8) * 0.008;
    
    vec3 offset = vec3(sway, bob, 0.0);
    
    // Yükseklik faktörü - ayaklar daha az sallanır, baş daha çok
    float heightFactor = clamp(position.y - floor(position.y), 0.0, 1.0);
    offset *= heightFactor;
    
    return position + offset;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
    
    normal = normalize(gl_NormalMatrix * gl_Normal);
    
    vec4 position = gl_Vertex;
    vec4 viewPosition = gbufferModelView * position;
    
    worldPos = (gbufferModelViewInverse * viewPosition).xyz + cameraPosition;
    viewPos = viewPosition.xyz;
    
    // Hafif canlı animasyonu (isteğe bağlı)
    // position.xyz = getEntityAnimation(position.xyz, worldPos, mc_Entity.x);
    
    gl_Position = gl_ProjectionMatrix * viewPosition;
}