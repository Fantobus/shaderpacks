#version 130

#define VSH
#define NETHER

#include "/programs/gbuffers_hand.glsl"