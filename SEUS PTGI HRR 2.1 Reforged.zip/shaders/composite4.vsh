#version 330 compatibility

#include "/program/composite4.vsh.glsl"
