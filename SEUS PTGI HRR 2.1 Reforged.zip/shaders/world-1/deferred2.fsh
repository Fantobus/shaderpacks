#version 330 compatibility

#define DIM_NETHER 1
#include "/program/deferred2.fsh.glsl"
