#version 330 compatibility

#define DIM_NETHER 1
#include "/program/composite4.fsh.glsl"
