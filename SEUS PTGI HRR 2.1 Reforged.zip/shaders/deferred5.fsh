#version 330 compatibility

#include "/program/deferred5.fsh.glsl"
