#version 330 compatibility

#include "/program/deferred3.vsh.glsl"
