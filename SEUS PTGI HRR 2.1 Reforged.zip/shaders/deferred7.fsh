#version 330 compatibility

#include "/program/deferred7.fsh.glsl"
