#version 330 compatibility

#include "/program/deferred8.fsh.glsl"
