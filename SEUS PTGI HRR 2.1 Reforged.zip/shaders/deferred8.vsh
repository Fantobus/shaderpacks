#version 330 compatibility

#include "/program/deferred8.vsh.glsl"
