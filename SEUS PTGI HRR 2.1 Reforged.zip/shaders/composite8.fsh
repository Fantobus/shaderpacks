#version 330 compatibility

#include "/program/composite8.fsh.glsl"
