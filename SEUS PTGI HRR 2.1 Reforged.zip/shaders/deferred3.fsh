#version 330 compatibility

#include "/program/deferred3.fsh.glsl"
