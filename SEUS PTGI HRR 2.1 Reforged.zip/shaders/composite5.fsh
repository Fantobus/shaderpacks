#version 330 compatibility

#include "/program/composite5.fsh.glsl"
