#version 330 compatibility

#include "/program/gbuffers_beaconbeam.vsh.glsl"
