#version 330 compatibility

#include "/program/gbuffers_textured.fsh.glsl"
