#version 330 compatibility

#include "/program/gbuffers_terrain.vsh.glsl"
