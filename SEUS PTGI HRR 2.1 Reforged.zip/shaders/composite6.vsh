#version 330 compatibility

#include "/program/composite6.vsh.glsl"
