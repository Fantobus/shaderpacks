#version 330 compatibility

#include "/program/gbuffers_skybasic.fsh.glsl"
