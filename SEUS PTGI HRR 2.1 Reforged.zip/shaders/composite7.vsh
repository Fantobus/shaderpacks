#version 330 compatibility

#include "/program/composite7.vsh.glsl"
