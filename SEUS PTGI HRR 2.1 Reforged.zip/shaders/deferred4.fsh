#version 330 compatibility

#include "/program/deferred4.fsh.glsl"
