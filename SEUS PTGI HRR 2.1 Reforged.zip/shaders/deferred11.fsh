#version 330 compatibility

#include "/program/deferred11.fsh.glsl"
