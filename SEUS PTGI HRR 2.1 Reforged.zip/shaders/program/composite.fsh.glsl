



/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/





in vec4 texcoord;

in vec3 colorSunlight;
in vec3 colorSkylight;
in vec3 colorTorchlight;
in vec3 colorSkyUp;

in vec4 skySHR;
in vec4 skySHG;
in vec4 skySHB;

// ---- Nether / End: no overworld sky. DIM_END / DIM_NETHER come from the world1 / world-1 stubs. ----
#if defined(DIM_END) || defined(DIM_NETHER)
#define NO_SKY 1
#endif

in vec3 worldLightVector;
in vec3 worldSunVector;

in float timeMidnight;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/PhotonClouds.inc"

// Water reflections of the default SEUS clouds: cheap traced clouds (detail=false) + on-screen cloud layer.
// DISABLED by default for max FPS: water shows only the traced clouds. Uncomment the line below to also add the on-screen cloud layer (slightly more detail, slightly slower).
// #define REFLECT_SCREEN_CLOUD_LAYER


vec2 Texcoord;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








vec2 GetNearFragment(vec2 coord, float depth, out float minDepth)
{
	
	
	vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
	vec4 depthSamples;
	depthSamples.x = texture2D(depthtex1, coord + texel * vec2(1.0, 1.0)).x;
	depthSamples.y = texture2D(depthtex1, coord + texel * vec2(1.0, -1.0)).x;
	depthSamples.z = texture2D(depthtex1, coord + texel * vec2(-1.0, 1.0)).x;
	depthSamples.w = texture2D(depthtex1, coord + texel * vec2(-1.0, -1.0)).x;

	vec2 targetFragment = vec2(0.0, 0.0);

	if (depthSamples.x < depth)
		targetFragment = vec2(1.0, 1.0);
	if (depthSamples.y < depth)
		targetFragment = vec2(1.0, -1.0);
	if (depthSamples.z < depth)
		targetFragment = vec2(-1.0, 1.0);
	if (depthSamples.w < depth)
		targetFragment = vec2(-1.0, -1.0);


	minDepth = min(min(min(depthSamples.x, depthSamples.y), depthSamples.z), depthSamples.w);

	return coord + texel * targetFragment;
}






#include "/lib/Materials.inc"
#include "/lib/GBufferData.inc"

// Nether / End: zero every overworld sky/sun varying from here on. Defined AFTER the library includes so
// function parameters with the same names inside lib/*.inc are not touched.
#ifdef NO_SKY
#define colorSunlight vec3(0.0)
#define colorSkylight vec3(0.0)
#define colorSkyUp vec3(0.0)
#define skySHR vec4(0.0)
#define skySHG vec4(0.0)
#define skySHB vec4(0.0)
#endif




 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int y=v.x*v.y;
   return f(FloorToInt(floor(pow(float(y),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int y=v.x*v.y;
   return t(FloorToInt(floor(pow(float(y),.333333))));
 }
 vec3 v(vec2 v)
 {
   ivec2 s=ivec2(viewWidth,viewHeight);
   int x=s.x*s.y,y=f();
   ivec2 d=ivec2(v.x*s.x,v.y*s.y);
   float z=float(d.y/y),i=float(int(d.x+mod(s.x*z,y))/y);
   i+=floor(s.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(d.x+mod(s.x*z,y),y);
   m.y=mod(d.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 s(vec3 v)
 {
   ivec2 m=ivec2(viewWidth,viewHeight);
   int z=f();
   vec3 i=v.xzy*z;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 r;
   r.x=mod(i.x+x*z,m.x);
   float c=i.x+x*z;
   r.y=i.y+floor(c/m.x)*z;
   r+=.5;
   r/=m;
   return r;
 }
 vec3 d(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 s=ivec2(2048,2048);
   int x=s.x*s.y,y=t();
   ivec2 d=ivec2(i.x*s.x,i.y*s.y);
   float z=float(d.y/y),f=float(int(d.x+mod(s.x*z,y))/y);
   f+=floor(s.x*z/y);
   vec3 m=vec3(0.,0.,f);
   m.x=mod(d.x+mod(s.x*z,y),y);
   m.y=mod(d.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec2 m=vec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float x=i.z;
   vec2 f;
   f.x=mod(i.x+x*y,m.x);
   float c=i.x+x*y;
   f.y=i.y+floor(c/m.x)*y;
   f+=.5;
   f/=m;
   f.xy*=.5;
   return f;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 s(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 m(vec3 v)
 {
   int m=t();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 e(vec3 v)
 {
   int y=f();
   v*=1./y;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 x(vec3 v)
 {
   int m=f();
   v=v-vec3(.5);
   v*=m;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,i=previousCameraPosition.xyz+.5,y=floor(v-.0001),z=floor(i-.0001);
   return y-z;
 }
 vec3 n(vec3 v)
 {
   vec4 i=vec4(v,1.);
   i=shadowModelView*i;
   i=shadowProjection*i;
   i/=i.w;
   float x=sqrt(i.x*i.x+i.y*i.y),y=1.f-SHADOW_MAP_BIAS+x*SHADOW_MAP_BIAS;
   i.xy*=.95f/y;
   i.z=mix(i.z,.5,.8);
   i=i*.5f+.5f;
   i.xy*=.5;
   i.xy+=.5;
   return i.xyz;
 }
 vec3 d(vec3 v,vec3 i,vec2 d,vec2 y,vec4 f,vec4 s,inout float x,out vec2 m)
 {
   bool r=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   r=!r;
   if(s.x==8||s.x==9||s.x==79||s.x<1.||!r||s.x==20.||s.x==171.||min(abs(i.x),abs(i.z))>.2)
     x=1.;
   if(s.x==50.||s.x==52.||s.x==76.)
     {
       x=0.;
       if(i.y<.5)
         x=1.;
     }
   if(s.x==51||s.x==53)
     x=0.;
   if(s.x>255)
     x=0.;
   vec3 z,c;
   if(i.x>.5)
     z=vec3(0.,0.,-1.),c=vec3(0.,-1.,0.);
   else
      if(i.x<-.5)
       z=vec3(0.,0.,1.),c=vec3(0.,-1.,0.);
     else
        if(i.y>.5)
         z=vec3(1.,0.,0.),c=vec3(0.,0.,1.);
       else
          if(i.y<-.5)
           z=vec3(1.,0.,0.),c=vec3(0.,0.,-1.);
         else
            if(i.z>.5)
             z=vec3(1.,0.,0.),c=vec3(0.,-1.,0.);
           else
              if(i.z<-.5)
               z=vec3(-1.,0.,0.),c=vec3(0.,-1.,0.);
   m=clamp((d.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float h=.15,w=.15;
   if(s.x==10.||s.x==11.)
     {
       if(abs(i.y)<.01&&r||i.y>.99)
         h=.1,w=.1,x=0.;
       else
          x=1.;
     }
   if(s.x==51||s.x==53)
     h=.5,w=.1;
   if(s.x==76)
     h=.2,w=.2;
   if(s.x-255.+39.>=103.&&s.x-255.+39.<=113.)
     w=.025,h=.025;
   z=normalize(f.xyz);
   c=normalize(cross(z,i.xyz)*sign(f.w));
   vec3 n=v.xyz+mix(z*h,-z*h,vec3(m.x));
   n.xyz+=mix(c*h,-c*h,vec3(m.y));
   n.xyz-=i.xyz*w;
   return n;
 }struct SPcacsgCKo{vec3 GadGLQcpqX;vec3 GadGLQcpqXOrigin;vec3 vAdYwconYe;vec3 AZVxALDdtL;vec3 UekatYTTmj;vec3 OmcxSfXfkJ;};
 SPcacsgCKo p(Ray v)
 {
   SPcacsgCKo i;
   i.GadGLQcpqX=floor(v.origin);
   i.GadGLQcpqXOrigin=i.GadGLQcpqX;
   i.vAdYwconYe=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.AZVxALDdtL=sign(v.direction);
   i.UekatYTTmj=(sign(v.direction)*(i.GadGLQcpqX-v.origin)+sign(v.direction)*.5+.5)*i.vAdYwconYe;
   i.OmcxSfXfkJ=vec3(0.);
   return i;
 }
 void i(inout SPcacsgCKo v)
 {
   v.OmcxSfXfkJ=step(v.UekatYTTmj.xyz,v.UekatYTTmj.yzx)*step(v.UekatYTTmj.xyz,v.UekatYTTmj.zxy),v.UekatYTTmj+=v.OmcxSfXfkJ*v.vAdYwconYe,v.GadGLQcpqX+=v.OmcxSfXfkJ*v.AZVxALDdtL;
 }
 void d(in Ray v,in vec3 i[2],out float f,out float y)
 {
   float z,x,r,c;
   f=(i[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(i[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   z=(i[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   x=(i[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   r=(i[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   c=(i[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   f=max(max(f,z),r);
   y=min(min(y,x),c);
 }
 vec3 d(const vec3 v,const vec3 y,vec3 f)
 {
   const float x=1e-05;
   vec3 z=(y+v)*.5,i=(y-v)*.5,s=f-z,c=vec3(0.);
   c+=vec3(sign(s.x),0.,0.)*step(abs(abs(s.x)-i.x),x);
   c+=vec3(0.,sign(s.y),0.)*step(abs(abs(s.y)-i.y),x);
   c+=vec3(0.,0.,sign(s.z))*step(abs(abs(s.z)-i.z),x);
   return normalize(c);
 }
 bool e(const vec3 v,const vec3 i,Ray s,out vec2 f)
 {
   vec3 y=s.inv_direction*(v-s.origin),x=s.inv_direction*(i-s.origin),c=min(x,y),d=max(x,y);
   vec2 m=max(c.xx,c.yz);
   float z=max(m.x,m.y);
   m=min(d.xx,d.yz);
   float n=min(m.x,m.y);
   f.x=z;
   f.y=n;
   return n>max(z,0.);
 }
 bool d(const vec3 v,const vec3 i,Ray s,inout float y,inout vec3 x)
 {
   vec3 z=s.inv_direction*(v-1e-05-s.origin),c=s.inv_direction*(i+1e-05-s.origin),m=min(c,z),f=max(c,z);
   vec2 r=max(m.xx,m.yz);
   float t=max(r.x,r.y);
   r=min(f.xx,f.yz);
   float n=min(r.x,r.y);
   bool h=n>max(t,0.)&&max(t,0.)<y;
   if(h)
     x=d(v-1e-05,i+1e-05,s.origin+s.direction*t),y=t;
   return h;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=n(v);
   float f=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*f),2).x;
   c*=saturate(dot(i,y));
   {
     vec4 d=texture2DLod(shadowcolor1,s.xy-vec2(0.,.5),4);
     float m=abs(d.x*256.-(v.y+cameraPosition.y)),h=GetCausticsComposite(v,i,m),w=shadow2DLod(shadowtex0,vec3(s.xy-vec2(0.,.5),s.z+1e-06),4).x;
     c=mix(c,c*h,1.-w);
   }
   c=TintUnderwaterDepth(c);
   #ifdef CLOUD_SHADOW
   c*=CloudShadow(v,worldLightVector);
   #endif
   return c*(1.-rainStrength);
 }
 vec3 f(vec3 v,vec3 i,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 f=m(v);
   f+=1.;
   f-=Fract01(cameraPosition+.5);
   vec3 s=n(f+y*.99);
   float h=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*h),3).x;
   c*=saturate(dot(i,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*h),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   c=mix(c,c*r,vec3(1.-t));
   #endif
   return c*(1.-rainStrength);
 }
 vec3 i(vec3 v,vec3 i,vec3 y,vec3 z,int x)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 s=n(v);
   float f=.5;
   vec3 c=vec3(1.)*shadow2DLod(shadowtex0,vec3(s.xy,s.z-.0006*f),2).x;
   c*=saturate(dot(i,y));
   c=TintUnderwaterDepth(c);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float m=shadow2DLod(shadowtex0,vec3(s.xy-vec2(.5,0.),s.z-.0006*f),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(s.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   c=mix(c,c*r,vec3(1.-m));
   #endif
   return c*(1.-rainStrength);
 }struct CPrmwMXxJc{float pzBOsrqcFy;float ivaOqoXyFu;float OxTKjfMYEH;float avjkUoKnfB;vec3 PVAMAgODVh;};
 vec4 h(CPrmwMXxJc v)
 {
   vec4 i;
   v.PVAMAgODVh=max(vec3(0.),v.PVAMAgODVh);
   i.x=v.pzBOsrqcFy;
   v.PVAMAgODVh=pow(v.PVAMAgODVh,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.PVAMAgODVh.x,v.OxTKjfMYEH);
   i.z=PackTwo16BitTo32Bit(v.PVAMAgODVh.y,v.avjkUoKnfB);
   i.w=PackTwo16BitTo32Bit(v.PVAMAgODVh.z,v.ivaOqoXyFu/255.);
   return i;
 }
 CPrmwMXxJc r(vec4 v)
 {
   CPrmwMXxJc i;
   vec2 s=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),c=UnpackTwo16BitFrom32Bit(v.w);
   i.pzBOsrqcFy=v.x;
   i.OxTKjfMYEH=s.y;
   i.avjkUoKnfB=m.y;
   i.ivaOqoXyFu=c.y*255.;
   i.PVAMAgODVh=pow(vec3(s.x,m.x,c.x),vec3(8.));
   return i;
 }
 CPrmwMXxJc w(vec2 v)
 {
   vec2 z=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*z;
   return r(texture2DLod(colortex5,v,0));
 }
 float e(float v,float y)
 {
   float z=1.;
   #ifdef FULL_RT_REFLECTIONS
   z=clamp(pow(v,.125)+y,0.,1.);
   #else
   z=clamp(v*10.-7.,0.,1.);
   #endif
   return z;
 }
 bool d(vec3 v,float y,Ray i,bool z,inout float f,inout vec3 x)
 {
   bool m=false,c=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(z)
     return false;
   if(y>=67.)
     return false;
   c=d(v,v+vec3(1.,1.,1.),i,f,x);
   m=c;
   #else
   if(y<40.)
     return c=d(v,v+vec3(1.,1.,1.),i,f,x),c;
   if(y==40.||y==41.||y>=43.&&y<=54.)
     {
       float s=.5;
       if(y==41.)
         s=.9375;
       c=d(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),i,f,x);
       m=m||c;
     }
   if(y==42.||y>=55.&&y<=66.)
     c=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,x),m=m||c;
   if(y==43.||y==46.||y==47.||y==52.||y==53.||y==54.||y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
     {
       float s=.5;
       if(y==55.||y==58.||y==59.||y==64.||y==65.||y==66.)
         s=0.;
       c=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),i,f,x);
       m=m||c;
     }
   if(y==43.||y==45.||y==48.||y==51.||y==53.||y==54.||y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
     {
       float s=.5;
       if(y==55.||y==57.||y==60.||y==63.||y==65.||y==66.)
         s=0.;
       c=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),i,f,x);
       m=m||c;
     }
   if(y==44.||y==45.||y==49.||y==51.||y==52.||y==54.||y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
     {
       float s=.5;
       if(y==56.||y==57.||y==61.||y==63.||y==64.||y==66.)
         s=0.;
       c=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),i,f,x);
       m=m||c;
     }
   if(y==44.||y==46.||y==50.||y==51.||y==52.||y==53.||y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
     {
       float s=.5;
       if(y==56.||y==58.||y==62.||y==63.||y==64.||y==65.)
         s=0.;
       c=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),i,f,x);
       m=m||c;
     }
   if(y>=67.&&y<=82.)
     c=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,x),m=m||c;
   if(y==68.||y==69.||y==70.||y==72.||y==73.||y==74.||y==76.||y==77.||y==78.||y==80.||y==81.||y==82.)
     {
       float s=8.,h=8.;
       if(y==68.||y==70.||y==72.||y==74.||y==76.||y==78.||y==80.||y==82.)
         s=0.;
       if(y==69.||y==70.||y==73.||y==74.||y==77.||y==78.||y==81.||y==82.)
         h=16.;
       c=d(v+vec3(s,6.,7.)/16.,v+vec3(h,9.,9.)/16.,i,f,x);
       m=m||c;
       c=d(v+vec3(s,12.,7.)/16.,v+vec3(h,15.,9.)/16.,i,f,x);
       m=m||c;
     }
   if(y>=71.&&y<=82.)
     {
       float s=8.,h=8.;
       if(y>=71.&&y<=74.||y>=79.&&y<=82.)
         h=16.;
       if(y>=75.&&y<=82.)
         s=0.;
       c=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,h)/16.,i,f,x);
       m=m||c;
       c=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,h)/16.,i,f,x);
       m=m||c;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(y>=83.&&y<=86.)
     {
       vec3 s=vec3(0),h=vec3(0);
       if(y==83.)
         s=vec3(0,0,0),h=vec3(16,16,3);
       if(y==84.)
         s=vec3(0,0,13),h=vec3(16,16,16);
       if(y==86.)
         s=vec3(0,0,0),h=vec3(3,16,16);
       if(y==85.)
         s=vec3(13,0,0),h=vec3(16,16,16);
       c=d(v+s/16.,v+h/16.,i,f,x);
       m=m||c;
     }
   if(y>=87.&&y<=102.)
     {
       vec3 s=vec3(0.),r=vec3(1.);
       if(y>=87.&&y<=94.)
         {
           float h=0.;
           if(y>=91.&&y<=94.)
             h=13.;
           s=vec3(0.,h,0.)/16.;
           r=vec3(16.,h+3.,16.)/16.;
         }
       if(y>=95.&&y<=98.)
         {
           float h=13.;
           if(y==97.||y==98.)
             h=0.;
           s=vec3(0.,0.,h)/16.;
           r=vec3(16.,16.,h+3.)/16.;
         }
       if(y>=99.&&y<=102.)
         {
           float h=13.;
           if(y==99.||y==100.)
             h=0.;
           s=vec3(h,0.,0.)/16.;
           r=vec3(h+3.,16.,16.)/16.;
         }
       c=d(v+s,v+r,i,f,x);
       m=m||c;
     }
   if(y>=103.&&y<=113.)
     {
       vec3 s=vec3(0.),r=vec3(1.);
       if(y>=103.&&y<=110.)
         {
           float n=float(y)-float(103.)+1.;
           r.y=n*2./16.;
         }
       if(y==111.)
         r.y=.0625;
       if(y==112.)
         s=vec3(1.,0.,1.)/16.,r=vec3(15.,1.,15.)/16.;
       if(y==113.)
         s=vec3(1.,0.,1.)/16.,r=vec3(15.,.5,15.)/16.;
       c=d(v+s,v+r,i,f,x);
       m=m||c;
     }
   #endif
   #endif
   return m;
 }
 vec3 g(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight));
   y*=1./64.;
   const vec2 i[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(v.x<2./viewWidth||v.x>1.-2./viewWidth||v.y<2./viewHeight||v.y>1.-2./viewHeight)
     ;
   y=(floor(y*64.)+.5)/64.;
   vec3 c=texture2D(noisetex,y).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   c=mod(c+float(frameCounter%64)*s,vec3(1.));
   return c;
 }
 vec2 S(inout float v)
 {
   return fract(sin(vec2(v+=.1,v+=.1))*vec2(43758.5,22578.1));
 }
 vec3 c(vec2 v)
 {
   vec2 y=vec2(v.xy*vec2(viewWidth,viewHeight))/64.;
   const vec2 m[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   y+=m[int(mod(float(frameCounter),8.))]*.5;
   y=(floor(y*64.)+.5)/64.;
   vec3 c=texture2D(noisetex,y).xyz;
   return c;
 }
 vec3 S(vec3 v,inout float y,int x)
 {
   vec2 i=c(Texcoord.xy+vec2(y+=.1,y+=.1)).xy;
   i=fract(i+S(y)*.1);
   float s=6.28319*i.x,z=sqrt(i.y);
   vec3 m=normalize(cross(v,vec3(0.,1.,1.))),f=cross(v,m),h=m*cos(s)*z+f*sin(s)*z+v.xyz*sqrt(1.-i.y);
   return h;
 }
 vec3 S(vec3 v,vec3 y)
 {
   vec2 c=s(e(m(v)+y+1.));
   vec3 z=w(c).PVAMAgODVh;
   return z;
 }
 vec3 S()
 {
   vec2 y=s(v(Texcoord.xy)+d()/f());
   vec3 c=w(y).PVAMAgODVh;
   return c;
 }
 vec3 S(float v,float y,float f,vec3 i)
 {
   vec3 s;
   s.x=f*cos(v);
   s.y=f*sin(v);
   s.z=y;
   vec3 c=abs(i.y)<.999?vec3(0,0,1):vec3(1,0,0),x=normalize(cross(i,vec3(0.,1.,1.))),z=cross(x,i);
   return x*s.x+z*s.y+i*s.z;
 }
 vec3 c(vec2 v,float y,vec3 x)
 {
   float s=2*3.14159*v.x,z=sqrt((1-v.y)/(1+(y*y-1)*v.y)),i=sqrt(1-z*z);
   return S(s,z,i,x);
 }
 float G(float v)
 {
   return 2./(v*v+1e-07)-2.;
 }
 vec3 G(in vec2 v,in float y,in vec3 x)
 {
   float s=G(y),i=2*3.14159*v.x,z=pow(v.y,1.f/(s+1.f)),c=sqrt(1-z*z);
   return S(i,z,c,x);
 }
 float G(float v,float y)
 {
   return 1./(v*(1.-y)+y);
 }
 void c(inout vec3 v,in vec3 y)
 {
   vec3 x=normalize(y.xyz),i=v;
   float s=dot(i,x);
   i=normalize(v-x*saturate(s)*.5);
   v=i;
 }
 vec4 R(in vec2 v)
 {
   float y=GetDepth(v);
   vec4 i=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   i/=i.w;
   return i;
 }
 vec4 R(in vec2 v,in float y)
 {
   vec4 i=gbufferProjectionInverse*vec4(v.x*2.f-1.f,v.y*2.f-1.f,2.f*y-1.f,1.f);
   i/=i.w;
   return i;
 }
 void G(inout vec3 v,in vec3 y,in vec3 i,vec3 z,float x)
 {
   float c=length(y);
   c*=pow(eyeBrightnessSmooth.y/240.f,6.f);
   c*=rainStrength;
   float s=pow(exp(-c*1e-05),4.);
   s=max(s,.5);
   vec3 f=vec3(dot(colorSkyUp,vec3(1.)))*.05;
   v=mix(f,v,vec3(s));
 }
 bool ReflIsWater=false; // set in main(): the new flicker-stable SSR march is used for water and the other translucent surfaces (ice, glass, ...)
vec4 G(float v,float y,vec3 s,vec3 m,vec3 x,vec3 z,vec3 h,float r,float n,float w,float a,bool T)
 {
   float l=1.;
   #ifdef SUNLIGHT_LEAK_FIX
   if(isEyeInWater<1)
     l=saturate(n*100.);
   #endif
   v=max(v-.05,0.);
   y=0.;
   float R=v*v,o=fract(frameCounter*.0123456);
   vec3 O=c(Texcoord.xy).xyz*.99+.005,U=c(Texcoord.xy+.1).xyz,g=reflect(h,c(c(Texcoord.xy).xy*vec2(1.,.8),R,x)),H=normalize((gbufferModelView*vec4(g.xyz,0.)).xyz);
   if(dot(g,x)<0.)
     g=reflect(g,x);
   #ifdef REFLECTION_SCREEN_SPACE_TRACING
   {
     bool b=false;
     vec2 F=Texcoord.xy;
     vec3 D=m.xyz;
     float C=0.;
     if(ReflIsWater)
       {
     // ---------------------------------------------------------------------------------
     // Screen-space reflection march (flicker-stable version).
     //
     // The previous march took ~17 exponentially growing 3D steps (up to hundreds of blocks
     // apart) and silently skipped every sample that landed on sky. Whether a reflection was
     // found therefore depended on whether one of those few samples happened to land on a
     // tree/shore pixel or on the sky next to it, and any tiny per-frame change (TAA jitter,
     // wave normals) moved the samples and flipped the result: reflections popped in and out
     // frame to frame, mostly along silhouettes and the far edge of reflected objects.
     //
     // Now the ray is projected to the screen and sampled at EVENLY SPACED screen positions
     // (perspective-correct, so the ray depth is interpolated as 1/z). Every few pixels of the
     // ray's on-screen path get tested, so a surface can't be stepped over, and the hit is then
     // refined to pixel accuracy with a binary search. The hit/thickness test is the same one as
     // before, so REFLECTION_THICKNESS_THRESHOLD still behaves the same way.
     // SCREENSPACE_REFLECTION_INTENSITY (1-10) sets how many samples are used (14..32).
     // ---------------------------------------------------------------------------------
     const int ssrSteps=12+2*SCREENSPACE_REFLECTION_INTENSITY;
     const int refineSteps=5;

     // Ray in view space: from the surface point to the far plane (clipped at the camera plane).
     vec3 rayO=m.xyz;
     vec3 rayE=rayO+H.xyz*far;
     if(rayE.z>-near*2.)
       rayE=rayO+H.xyz*max((-near*2.-rayO.z)/max(H.z,1e-5),0.);
     vec2 p0=ProjectBack(rayO).xy;
     vec2 p1=ProjectBack(rayE).xy;
     float k0=1./max(-rayO.z,1e-4);
     float k1=1./max(-rayE.z,1e-4);
     vec2 dP=p1-p0;

     // Clip the on-screen path to the screen rectangle (keeps depth fetches inside the half-res buffer).
     vec2 uvMin=ScreenTexel*2.;
     vec2 uvMax=1.-ScreenTexel*2.;
     float sMax=1.;
     if(dP.x>1e-7)
       sMax=min(sMax,(uvMax.x-p0.x)/dP.x);
     else if(dP.x<-1e-7)
       sMax=min(sMax,(uvMin.x-p0.x)/dP.x);
     if(dP.y>1e-7)
       sMax=min(sMax,(uvMax.y-p0.y)/dP.y);
     else if(dP.y<-1e-7)
       sMax=min(sMax,(uvMin.y-p0.y)/dP.y);
     sMax=max(sMax,0.);
     float pathPx=length(dP*ScreenSize)*sMax; // on-screen length of the ray in pixels

     if(pathPx>4.)
       {
         // Contact fix: the ray used to skip its first 3 pixels. At the shoreline (where a bank meets the
         // water) the real hit lies inside those pixels, so the ray was already far behind the bank at the
         // first sample, never registered a hit and showed a thin white/sky line between the bank and its
         // reflection. Now the march starts half a pixel from the surface point (the water is not in
         // depthtex1, so the surface can't hit itself) and that first sample is tested as a contact hit.
         float s0=min(.5/pathPx,sMax);
         float ds=(sMax-s0)/float(ssrSteps);
         float prevS=0.;
         float prevRay=1./k0;
         float prevScene=1e6; // no previous surface sample yet
         float hitLo=0.,hitHi=0.;
         bool coarseHit=false;
         for(int N=0;N<=ssrSteps;N++)
           {
             float sT=s0+ds*float(N);
             float rayDepth=1./(k0+(k1-k0)*sT);
             float rayStepDepth=abs(rayDepth-prevRay); // how far the ray moved in depth since the last sample
             vec2 M=p0+dP*sT;
             float hitDepth=GetDepth(DownscaleTexcoord(M));
             // SSR must only hit real scene geometry; sky pixels are never a hit.
             if(hitDepth!=1.0)
               {
                 float sceneDepth=ExpToLinearDepth(hitDepth);
                 float depthDelta=rayDepth-sceneDepth;

                 // Same two tolerances as before. "generous" always applies, so continuous surfaces seen at
                 // a grazing angle (flat water reflecting terrain) are still found. "strict" (set by
                 // REFLECTION_THICKNESS_THRESHOLD) only applies when the scene depth jumped a lot since the
                 // previous sample - the sign that the ray skimmed past a silhouette edge of a thin or
                 // floating object, which is what causes stretched/ghost colours.
                 float generousThickness=max(.02,rayStepDepth*1.5);
                 float thicknessAmount=float(REFLECTION_THICKNESS_THRESHOLD);
                 float strictThickness=max(.004*thicknessAmount,rayStepDepth*.3*thicknessAmount);
                 float sceneJump=abs(sceneDepth-prevScene);
                 float maxThickness=sceneJump>rayStepDepth*2.?strictThickness:generousThickness;
                 // first sample = contact with the surface point: always use the generous tolerance, scaled to
                 // the ray's depth gain (grazing rays gain a lot of depth per pixel), so the bank connects.
                 if(N==0)
                   maxThickness=max(.02,rayStepDepth*2.5);

                 // Only accept a genuine front-to-back depth crossing.
                 if(depthDelta>0.&&depthDelta<maxThickness)
                   {
                     coarseHit=true;
                     hitLo=prevS;
                     hitHi=sT;
                     break;
                   }
                 prevScene=sceneDepth;
               }
             prevS=sT;
             prevRay=rayDepth;
           }
         if(coarseHit)
           {
             // Binary search between the last sample in front of the surface and the first one behind it.
             // Sky counts as "in front" (infinitely far), so the search always converges onto real geometry.
             float lo=hitLo,hi=hitHi;
             for(int R=0;R<refineSteps;R++)
               {
                 float mid=(lo+hi)*.5;
                 float midRay=1./(k0+(k1-k0)*mid);
                 float midDepth=GetDepth(DownscaleTexcoord(p0+dP*mid));
                 if(midDepth!=1.0&&midRay>ExpToLinearDepth(midDepth))
                   hi=mid;
                 else
                   lo=mid;
               }
             // 'hi' is always a verified sample behind a real surface, so it can never sit on a sky pixel.
             vec2 hitUV=p0+dP*hi;
             vec3 B=GetViewPositionNoJitter(hitUV,GetDepth(DownscaleTexcoord(hitUV))).xyz;
             b=true;
             F=hitUV;
             D=B.xyz;
             C=distance(B,m.xyz)*.4;
           }
       }
       }
     else
       {
     // SSR intensity option (1-10, default/max = 10): controls reach, not raw sample count.
     // Cheap hierarchical march: a handful of coarse probes with an EXPONENTIALLY growing step
     // size cover huge distances (a mountain, distant terrain) in very few texture fetches, then
     // a small fixed binary-search refine (independent of intensity) snaps to a pixel-accurate
     // hit. This reaches far more reliably than a long brute-force linear march while sampling
     // roughly the same or fewer texels than the original 16-step trace, so raising the intensity
     // barely (if at all) shows up in frame time - only the reach/quality goes up.
     const int coarseSteps=7+SCREENSPACE_REFLECTION_INTENSITY; // 8..17 coarse probes
     const int refineSteps=4; // fixed cheap refine, does not scale with intensity
     float ssrReach=1.+(float(SCREENSPACE_REFLECTION_INTENSITY)-1.)*.33333;
     float growth=1.35+(float(SCREENSPACE_REFLECTION_INTENSITY)-1.)*.035;
     float stepLen=.06/saturate(dot(-h,x)+.001)*ssrReach;
     vec3 X=m.xyz,prevX=X;
     bool coarseHit=false;
     float prevSceneDepth=1e6; // no previous surface sample yet
     for(int N=0;N<coarseSteps;N++)
       {
         prevX=X;
         X+=H.xyz*stepLen;
         stepLen*=growth;
         if(X.z>0.)
           break;
         vec2 M=ProjectBack(X).xy;
         if(M.x<0.||M.x>1.||M.y<0.||M.y>1.)
           break;
         // SSR must only hit real scene geometry. If the projected ray enters the sky,
         // do not treat the sky depth/background as a reflection hit. Otherwise looking
         // upward can switch the reflection between the screen-space sky sample and the
         // ray-traced sky, producing a visible colour/seam change in the water.
         float hitDepth=GetDepth(DownscaleTexcoord(M.xy));
         if(hitDepth==1.0)
           continue;
         vec3 B=GetViewPositionNoJitter(M.xy,hitDepth).xyz;

         // Use view-space Z for the SSR depth test, not distance-from-camera.
         // Comparing lengths can report a false hit when the reflection ray moves
         // sideways around a floating block: the ray can have a larger total length
         // than the background surface even though it has not crossed that surface
         // in depth. This is what causes stretched/ghost reflections beneath blocks
         // that have open air underneath them.
         float rayDepth=-X.z;
         float sceneDepth=-B.z;
         float depthDelta=rayDepth-sceneDepth;
         float rayStepDepth=abs(H.z)*(stepLen/growth);

         // Two tolerances. "generous" is the original, proven-safe amount and is always
         // available, so a continuous surface seen at a grazing angle (e.g. flat water
         // reflecting distant terrain) - where consecutive coarse steps naturally land on
         // a smoothly increasing scene depth - can still register a hit even with large
         // coarse steps. Without this, tightening REFLECTION_THICKNESS_THRESHOLD rejects
         // those perfectly valid grazing hits too, which shows up as horizontal banding/
         // missing stripes on flat water.
         // "strict" is gated by REFLECTION_THICKNESS_THRESHOLD and only kicks in when the
         // scene depth itself just jumped a lot versus the previous coarse step's scene
         // depth - that jump is the actual sign the ray skimmed past a silhouette edge
         // (a thin or floating object), which is what causes the stretched/ghost colour.
         float generousThickness=max(.02,rayStepDepth*1.5);
         float thicknessAmount=float(REFLECTION_THICKNESS_THRESHOLD);
         float strictThickness=max(.004*thicknessAmount,rayStepDepth*.3*thicknessAmount);
         float sceneJump=abs(sceneDepth-prevSceneDepth);
         float maxThickness=sceneJump>rayStepDepth*2.?strictThickness:generousThickness;

         // Only accept a genuine front-to-back depth crossing. A large depth jump
         // means the ray passed an occluder edge / open gap, so keep marching.
         if(depthDelta>0.&&depthDelta<maxThickness)
           {
             coarseHit=true;
             break;
           }
         prevSceneDepth=sceneDepth;
       }
     if(coarseHit)
       {
         vec3 lo=prevX,hi=X;
         for(int R=0;R<refineSteps;R++)
           {
             vec3 mid=(lo+hi)*.5;
             vec2 M=ProjectBack(mid).xy;
             vec3 B=GetViewPositionNoJitter(M.xy,GetDepth(DownscaleTexcoord(M.xy))).xyz;
             // Refine against the same view-space Z depth used by the coarse test.
             // Using vector length here can move the hit across an open gap around
             // floating geometry and recreate the stretched reflection artifact.
             if(mid.z<B.z)
               hi=mid;
             else
               lo=mid;
           }
         vec3 hitPos=(lo+hi)*.5;
         vec2 M=ProjectBack(hitPos).xy;
         vec3 B=GetViewPositionNoJitter(M.xy,GetDepth(DownscaleTexcoord(M.xy))).xyz;
         b=true;
         F=M.xy;
         D=B.xyz;
         C=distance(hitPos,m.xyz)*.4;
       }
       }
     // Do not reject valid long-distance SSR hits against the camera far-plane here.
     // The ray is already constrained to the screen and the hit is depth-tested above.
     // A hard `far` cutoff was causing distant visible terrain/objects to disappear
     // from reflections even though they were still available in the depth buffer.
     vec3 N=(gbufferModelViewInverse*vec4(D,0.)).xyz;
     if(b)
       {
         F.xy=floor(F.xy*vec2(viewWidth,viewHeight)+.5)/vec2(viewWidth,viewHeight);
         TemporalJitterProjPos01(F);
         vec2 M=F.xy*.5;
         M=clamp(M,vec2(ScreenTexel),HalfScreen-ScreenTexel*2.)+HalfScreen;
         vec3 E=pow(texture2DLod(colortex1,M,0).xyz,vec3(2.2)),u=E*100.;
         #ifndef NO_SKY
         LandAtmosphericScattering(u,D-m,H,g,worldSunVector,1.);
         #endif
         G(u,D,normalize(m.xyz),normalize(s.xyz),1.);
         #ifdef NO_SKY
         if(isEyeInWater==0)
           u*=1.2,DimensionFog(u,length(D),h),u/=1.2;
         #endif
         #ifdef IMPROVED_LAVA_FOG
         if(isEyeInWater==1)
           u*=1.2,UnderwaterFog(u,length(D),h,colorSkyUp,colorSunlight),u/=1.2;
         if(isEyeInWater==2)
           u*=1.2,UnderLavaFog(u,length(D),h),u/=1.2;
         #else
         if(isEyeInWater>0)
           u*=1.2,UnderwaterFog(u,length(D),h,colorSkyUp,colorSunlight),u/=1.2;
         #endif
         return vec4(u,saturate(C/4.));
       }
   }
   #endif
   const float P=2.4,u=P;
   int X=t(),D=f();
   vec3 M=s+x*(.01+r*.1)-h*(a*.2/(saturate(dot(z,-h))+1e-06)+.005)*(T?0.:1.);
   M+=Fract01(cameraPosition.xyz+.5);
   Ray F=MakeRay(f(M,X)*X-vec3(1.),g);
   vec3 L=vec3(1.),j=vec3(0.);
   float N=0.;
   SPcacsgCKo E=p(F);
   float C=far;
   vec3 B=vec3(1.);
   // Sky/cloud reflections come from ONE source: the on-screen sky (colortex1), which
   // already holds the real, fully lit clouds + sun + moon. skyScreenW is how much of the
   // reflected direction that screen sky covers (0 = off-screen, 1 = fully on-screen).
   // The ray-traced procedural sky (plain atmosphere, no GI clouds) only fills the rest,
   // so nothing is ever drawn twice.
   bool skyReached=false;
   float skyScreenW=0.;
   for(int Y=0;Y<1;Y++)
     {
       vec4 J=vec4(0.);
       vec3 A=vec3(0.);
       float I=.5;
       for(int k=0;k<REFLECTION_TRACE_LENGTH;k++)
         {
           A=E.GadGLQcpqX/float(X);
           vec2 V=d(A,X);
           J=texture2DLod(shadowcolor,V,0);
           N=J.w*255.;
           float q=1.-step(.5,abs(N-241.));
           vec3 W=J.xyz;
           float Q=dot(E.GadGLQcpqX+.5-F.origin,E.GadGLQcpqX+.5-F.origin);
           float K=0.;
           #ifdef REFLECTION_LIGHT_GLINTS
           // Fake specular sparkle for small light-emitting voxels seen along the ray. Left disabled
           // by default: at typical voxel resolution this pops as a hard-edged bright circle/blob
           // near light sources (e.g. campfires) in reflections instead of a smooth highlight.
           K=saturate(pow(saturate(dot(F.direction,normalize(E.GadGLQcpqX+.5-F.origin))),56.*Q)*5.-1.)*5.;
           #endif
           j+=W*q*I*.5*K;
           if(N<240.)
             {
               if(d(E.GadGLQcpqX,N,F,k==0,C,B))
                 {
                   break;
                 }
             }
           i(E);
           I=1.;
         }
       if(J.w*255.<1.f||J.w*255.>254.f)
         {
           vec3 k=SkyShading(F.direction,worldSunVector,rainStrength);
           vec3 skyAtmoRaw=k;
           #ifdef SUN_MOON_REFLECTIONS
           vec3 sunMoonAbsorb=AtmosphereAbsorption(F.direction,AtmosphereExtent);
           float sunCloudVis=1.;
           float moonCloudVisGI=1.;
           #if CLOUD_MODE == 3 || CLOUD_MODE == 4
           // Clouds in GI / Photon clouds: hide the sun/moon glow in the water wherever a cloud covers the
           // reflected direction, exactly like the screen-space sky reflection does.
           // Only evaluated near the sun/moon, where the glow is actually non-zero.
           if(abs(dot(F.direction,worldSunVector))>.95)
             {
               float skyCloudVis=CloudSkyVisibility(F.direction,worldLightVector,worldSunVector,colorSunlight,colorSkyUp,k,timeMidnight);
               sunCloudVis=skyCloudVis;
               moonCloudVisGI=skyCloudVis;
             }
           #elif defined(CLOUD_SHADOW)
           sunCloudVis=CloudShadow(s,worldSunVector);
           #endif
           k+=RenderSunDisc(F.direction,worldSunVector,colorSunlight)*sunMoonAbsorb*2000.*sunCloudVis;
           #ifdef PROCEDURAL_MOON
           float moonCloudVis=1.;
           #if CLOUD_MODE == 3 || CLOUD_MODE == 4
           moonCloudVis=moonCloudVisGI;
           #elif defined(CLOUD_SHADOW)
           moonCloudVis=CloudShadow(s,-worldSunVector);
           #endif
           k+=RenderMoonDisc(F.direction,-worldSunVector,colorSunlight)*sunMoonAbsorb*2000.*moonCloudVis;
           #endif
           #endif
           k=DoNightEyeAtNight(k*12.,timeMidnight)*.083333;
           #if CLOUD_MODE < 3 && defined(CLOUDS_IN_GI)
           // Default / no-cloud profiles: SEUS GFME method. The clouds are drawn onto the traced sky in the
           // reflected direction, so they are always there (also when looking straight down) instead of
           // being read from the on-screen sky.
           // detail=false. The detail=true path runs the extra cloud noise
           // octaves for every water pixel and was the main FPS cost; the on-screen cloud layer is
           // added back cheaply below (REFLECT_SCREEN_CLOUD_LAYER), so the look is kept.
           {
             vec3 skyAtmo=DoNightEyeAtNight(skyAtmoRaw*12.,timeMidnight)*.083333;
             CloudPlane(k,-F.direction,worldLightVector,worldSunVector,colorSunlight,colorSkyUp,skyAtmo,timeMidnight,false);
           }
           #endif
           #ifdef WATER_REFLECTION_SKY_LEAK_FIX
           k*=l; // Suppress the fake overworld sky/atmosphere (and sun/moon glare) in reflections when there is no real sky above (Nether, caves, indoors) - fixes water reflecting a bright sky that shouldn't be there.
           #endif
           #ifdef NO_SKY
           vec3 V=vec3(0.);
           #else
           vec3 V=k*L;
           #endif
           skyReached=true;
           // How much of this reflection direction is visible in the on-screen sky?
           #if CLOUD_MODE >= 3
           {
             vec3 skyViewPos=m.xyz+H*1000.;
             vec3 skyProj=ProjectBack(skyViewPos);
             if(skyViewPos.z<0.&&skyProj.x>ScreenTexel.x&&skyProj.x<1.-ScreenTexel.x&&skyProj.y>ScreenTexel.y&&skyProj.y<1.-ScreenTexel.y&&GetDepth(skyProj.xy)==1.0)
               {
                 vec2 skyEdge=skyProj.xy*2.-1.;
                 skyScreenW=1.-max(smoothstep(.8,1.,abs(skyEdge.x)),smoothstep(.8,1.,abs(skyEdge.y)));
               }
           }
           // No CloudPlane() (Clouds in GI) here on purpose: clouds in reflections come from
           // the screen-space sky only. The traced sky (incl. its sun/moon disc) is faded out
           // exactly as far as the screen sky fades in.
           V*=1.-skyScreenW;
           #endif
           V=TintUnderwaterDepth(V);
           j+=V*.1;
           C=1000.;
           break;
         }
       vec3 k=mod(F.origin+F.direction*C,vec3(1.))-.5;
       float V=log2(C*.4*v*TEXTURE_RESOLUTION);
       vec2 q=vec2(0.);
       q+=vec2(k.z*-B.x,-k.y)*abs(B.x);
       q+=vec2(k.x,k.z*B.y)*abs(B.y);
       q+=vec2(k.x*B.z,-k.y)*abs(B.z);
       vec3 W=(F.origin+F.direction*C)/float(X);
       vec2 Q=textureSize(colortex0,0);
       vec4 K=texture2DLod(shadowcolor1,d(A,X),0);
       vec2 Z=K.xy;
       Z=(floor(Z*Q/TEXTURE_RESOLUTION)+.5)/(Q/TEXTURE_RESOLUTION);
       vec2 ab=Z+q.xy*(TEXTURE_RESOLUTION/Q);
       vec3 ac=pow(texture2DLod(colortex0,ab,V).xyz,vec3(2.2));
       ac*=mix(vec3(1.),J.xyz/(K.w+1e-05),vec3(K.z));
       if(N<240.)
         {
           vec3 ad=saturate(J.xyz);
           L*=ac;
         }
       if(abs(N-31.)<.1)
         j+=.09*L*GI_LIGHT_BLOCK_INTENSITY;
       {
         vec3 ae=vec3(0.),af=vec3(0.);
         if(abs(B.x)>.5)
           ae=vec3(0.,1.,0.),af=vec3(0.,0.,1.);
         if(abs(B.y)>.5)
           ae=vec3(1.,0.,0.),af=vec3(0.,0.,1.);
         if(abs(B.z)>.5)
           ae=vec3(1.,0.,0.),af=vec3(0.,1.,0.);
         ae*=1.;
         af*=1.;
         vec3 ag=S(A,B),ah=ag,ai=saturate(ag*100000.),aj=S(A+ae/float(X),B);
         ah+=aj;
         ai+=saturate(aj*100000.);
         vec3 ak=S(A-ae/float(X),B);
         ah+=ak;
         ai+=saturate(ak*100000.);
         vec3 al=S(A+af/float(X),B);
         ah+=al;
         ai+=saturate(al*100000.);
         vec3 am=S(A-af/float(X),B);
         ah+=am;
         ai+=saturate(am*100000.);
         ah/=ai+vec3(.0001);
         j+=ah*u*L;
       }
       vec3 an=e(M+F.direction*C-1.,worldLightVector,B,g,X)*L*P*colorSunlight*l;
       if(isEyeInWater>0)
         ;
       j+=an;
     }
   vec3 k=m.xyz+H*C,V=(gbufferModelViewInverse*vec4(k.xyz,0.)).xyz;
   {
     vec3 J=ProjectBack(k);
     if(J.x>ScreenTexel.x&&J.x<1.-ScreenTexel.x&&J.y>ScreenTexel.y&&J.y<1.-ScreenTexel.y&&k.z<0.)
       {
         vec2 A=J.xy*2.-1.;
         float Q=1.-max(smoothstep(.5,1.,abs(A.x)),smoothstep(.5,1.,abs(A.y)));
         vec2 K=J.xy*.5+HalfScreen.xy;
         // Sky reflections: when the trace escaped to the sky, the visible on-screen sky
         // (colortex1: atmosphere + clouds + sun + moon) is reflected directly below and the
         // traced procedural sky is faded out by the same weight, so there is one source only.
         float fallbackDepth=GetDepth(J.xy);
         vec3 screenSky=pow(texture2DLod(colortex1,K,0).xyz,vec3(2.2))*100.;
         if(fallbackDepth!=1.0)
         {
           vec3 I=GetViewPositionNoJitter(J.xy,fallbackDepth).xyz;
           if(length(I-k)<.03*length(I))
             j=mix(j.xyz,screenSky,vec3(Q));
         }
         #if CLOUD_MODE < 3 && defined(CLOUDS_IN_GI) && defined(REFLECT_SCREEN_CLOUD_LAYER)
         else if(skyReached&&skyScreenW<=0.)
         {
           // Keep ONLY the cloud layer of the on-screen sky (screen sky minus
           // the plain procedural atmosphere for this reflection direction). Pure atmosphere is never
           // copied from screen space, so there is no camera-angle sky-colour seam.
           vec3 pureSky=SkyShading(normalize(V),worldSunVector,rainStrength)*.1;
           vec3 cloudLayer=max(screenSky-pureSky,vec3(0.));
           float cloudMask=saturate((dot(cloudLayer,vec3(.333333))-.002)*25.);
           j+=cloudLayer*cloudMask*Q;
         }
         #endif
         else if(skyReached&&skyScreenW>0.)
         {
           // Reflect the visible sky (atmosphere + clouds + sun + moon) DIRECTLY from the
           // screen buffer. It is a straight replacement, not "screen minus procedural sky":
           // the old difference approach clamped everything darker than the blue sky to zero,
           // so the grey/white/dark underside of a cloud came out as plain blue and the cloud
           // looked cut off. colortex1 is written with a 0.001 scale, so the *100 above equals
           // the 0.1 scale used by the ray-traced sky. Same night-eye/leak/underwater handling
           // as the traced sky so both sources match where they cross-fade.
           vec3 screenSkyRefl=DoNightEyeAtNight(screenSky*120.,timeMidnight)*.083333*.1;
           #ifdef WATER_REFLECTION_SKY_LEAK_FIX
           screenSkyRefl*=l; // no sky in caves/indoors/Nether
           #endif
           #ifndef NO_SKY
           j+=TintUnderwaterDepth(screenSkyRefl*L)*skyScreenW;
           #endif
         }
       }
   }
   #ifndef NO_SKY
   if(C<1000.)
     LandAtmosphericScattering(j,k-m,H,g,worldSunVector,1.);
   #else
   if(isEyeInWater==0)
     j*=1.2,DimensionFog(j,length(V),h),j/=1.2;
   #endif
   #ifdef IMPROVED_LAVA_FOG
   if(isEyeInWater==1)
     j*=1.2,UnderwaterFog(j,length(V),h,colorSkyUp,colorSunlight),j/=1.2;
   if(isEyeInWater==2)
     j*=1.2,UnderLavaFog(j,length(V),h),j/=1.2;
   #else
   if(isEyeInWater>0)
     j*=1.2,UnderwaterFog(j,length(V),h,colorSkyUp,colorSunlight),j/=1.2;
   #endif
   C*=saturate(dot(-h,x))*2.;
   return vec4(j,saturate(C/4.));
 }
 vec4 l(float v)
 {
   float y=v*v,s=y*v;
   vec4 i;
   i.x=-s+3*y-3*v+1;
   i.y=3*s-6*y+4;
   i.z=-3*s+3*y+3*v+1;
   i.w=s;
   return i/6.f;
 }
 vec4 g(in sampler2D v,in vec2 i)
 {
   vec2 y=vec2(viewWidth,viewHeight);
   i*=y;
   i-=.5;
   float s=fract(i.x),c=fract(i.y);
   i.x-=s;
   i.y-=c;
   vec4 m=l(s),x=l(c),f=vec4(i.x-.5,i.x+1.5,i.y-.5,i.y+1.5),z=vec4(m.x+m.y,m.z+m.w,x.x+x.y,x.z+x.w),d=f+vec4(m.y,m.w,x.y,x.w)/z,h=texture2DLod(v,vec2(d.x,d.z)/y,0),a=texture2DLod(v,vec2(d.y,d.z)/y,0),r=texture2DLod(v,vec2(d.x,d.w)/y,0),t=texture2DLod(v,vec2(d.y,d.w)/y,0);
   float n=z.x/(z.x+z.y),w=z.z/(z.z+z.w);
   return mix(mix(t,r,n),mix(a,h,n),w);
 }
 bool h(vec3 v,vec3 y)
 {
   vec3 s=normalize(cross(dFdx(v),dFdy(v))),x=normalize(y-v),c=normalize(x);
   return distance(v,y)<.05;
 }
 vec3 a(vec2 v)
 {
   vec2 y=vec2(viewWidth,viewHeight),c=1./y,s=v*y,i=floor(s-.5)+.5,x=s-i,z=x*x,f=x*z;
   float m=.5;
   vec2 d=-m*f+2.*m*z-m*x,a=(2.-m)*f-(3.-m)*z+1.,h=-(2.-m)*f+(3.-2.*m)*z+m*x,r=m*f-m*z,n=a+h,F=c*(i+h/n);
   vec3 t=texture2DLod(colortex4,vec2(F.x,F.y),0).xyz;
   vec2 k=c*(i-1.),B=c*(i+2.);
   vec4 w=vec4(texture2DLod(colortex4,vec2(F.x,k.y),0).xyz,1.)*(n.x*d.y)+vec4(texture2DLod(colortex4,vec2(k.x,F.y),0).xyz,1.)*(d.x*n.y)+vec4(t,1.)*(n.x*n.y)+vec4(texture2DLod(colortex4,vec2(B.x,F.y),0).xyz,1.)*(r.x*n.y)+vec4(texture2DLod(colortex4,vec2(F.x,B.y),0).xyz,1.)*(n.x*r.y);
   return max(vec3(0.),w.xyz*(1./w.w));
 }
// One refraction sample: returns raw linear scene colour in rgb and the water path length in a
// (fog is applied once by the caller, after the samples have been cross-faded).
vec4 RefrFetch(vec2 tc,vec2 off,vec3 mp,bool wat,out float wv)
{
  vec2 j=clamp(tc+off,vec2(ScreenTexel),HalfScreen-ScreenTexel*2.);
  float X=ExpToLinearDepth(MergeLodSolidDepth(j,texture2DLod(depthtex1,j,0).x)),T=ExpToLinearDepth(MergeLodWaterDepth(j,texture2DLod(depthtex0,j,0).x));
  // soft validity: 1 when the sample lies behind the water surface, fading to 0 otherwise
  wv=smoothstep(0.,.1,X-T);
  vec3 col=pow(texture2DLod(colortex1,j.xy+HalfScreen,0).xyz,vec3(2.2));
  #ifdef CHROMATIC_ABERRATION
  if(wat&&dot(off,off)>0.)
    {
      float CA_amount=CHROMATIC_ABERRATION_STRENGTH*0.35;
      #ifdef CLOUD_SHADOW
      CA_amount*=CloudShadow(mp,worldLightVector);
      #endif
      if(CA_amount>0.0001)
        {
          vec2 jR=clamp(tc+off*(1.0+CA_amount),vec2(ScreenTexel),HalfScreen-ScreenTexel*2.);
          vec2 jB=clamp(tc+off*(1.0-CA_amount),vec2(ScreenTexel),HalfScreen-ScreenTexel*2.);
          col.x=pow(texture2DLod(colortex1,jR.xy+HalfScreen,0).x,2.2);
          col.z=pow(texture2DLod(colortex1,jB.xy+HalfScreen,0).z,2.2);
        }
    }
  #endif
  // path length along the view ray = (depth difference) * (ray length / view-space depth);
  // the ray/depth ratio comes straight from the projection (no matrix reconstruction, no extra fetch)
  vec2 rn=(j/DOWNSCALE_FACTOR)*2.-1.;
  rn/=vec2(gbufferProjection[0].x,gbufferProjection[1].y);
  float gg=wat?(X-T)*sqrt(1.+dot(rn,rn)):0.;
  return vec4(col,gg);
}
#if defined(IS_IRIS) && MC_VERSION >= 260000
// Iris (MC 26.1+): translucent entities such as the player are drawn after the deferred lighting
// pass (gbuffers_entities_translucent), so they never got lit. Light them here with the same
// sky / torch / sun terms the deferred pass uses for distant surfaces; the sun is shadowed with the shadow map.
// Returns radiance in the same units as the deferred output before its *0.001 scale.
// Sun/moon shadow for the translucent-entity path: same shadow-map projection, distortion and bias as the
// deferred pass (CalculateSunlightVisibility), with a small fixed PCF kernel. worldPos is camera-relative.
float TranslucentEntitySunShadow(vec3 worldPos, vec3 worldNormal)
{
	const float shadowRes = 4096.0;
	vec3 sn = normalize((shadowModelView * vec4(worldNormal, 0.0)).xyz) * vec3(1.0, 1.0, -1.0);
	vec4 sp = shadowProjection * (shadowModelView * vec4(worldPos, 1.0));
	sp /= sp.w;
	float dist = sqrt(sp.x * sp.x + sp.y * sp.y);
	float distortFactor = (1.0 - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;
	sp.xyz += sn * 0.002 * distortFactor;
	sp.xy *= 0.95 / distortFactor;
	sp.z = mix(sp.z, 0.5, 0.8);
	sp = sp * 0.5 + 0.5;
	sp.xy *= 0.5;
	sp.xy += 0.5;

	float bias = 0.00022 * dist + 0.0004;
	float spread = 1.2 / shadowRes;
	float shadow = 0.0;
	for (int i = -1; i <= 1; i++)
		for (int j = -1; j <= 1; j++)
			shadow += shadow2DLod(shadowtex0, vec3(sp.xy + vec2(i, j) * spread, sp.z - bias), 0.0).x;
	return shadow / 9.0;
}

vec3 TranslucentEntityLighting(vec3 albedo, vec3 worldPos, vec3 worldNormal, vec2 mcLightmap)
{
#ifdef NO_SKY
	// Nether / End: there is no sun, sky or SH light here (those varying are zeroed above), and solid
	// surfaces are lit ONLY by the voxel GI that deferred12 reads from colortex7 (G()*10*albedo).
	// The overworld formula below falls back to the raw lightmap torch term (up to 5x near lava), which is
	// far brighter than the GI-lit terrain around the entity and blew players/mobs out to white.
	// Use the same GI term as the solid path instead. The GI texel is the one at this pixel (the surface
	// behind the entity); the quadrant layout matches deferred12's G(): GI lives at +HalfScreen.y.
	vec3 gi = texture2DLod(colortex7, Texcoord.xy + vec2(0.0, HalfScreen.y), 0).xyz;
	vec3 r = gi * 10.0 * albedo;
	// Small lightmap floor so an entity in front of a void / unlit background is not pitch black.
	r += mcLightmap.x * colorTorchlight * albedo * 0.025 * 3.7 * 0.1;
	return r;
#else
	float skyLm = mcLightmap.y;
	vec3 r = FromSH(skySHR, skySHG, skySHB, worldNormal) * pow(skyLm, 0.5) * albedo * 4.5;
	r += mcLightmap.x * colorTorchlight * albedo * 0.025 * 3.7;
	r += normalize(albedo + 0.0001) * length(albedo) * colorSunlight * 0.13 * skyLm * albedo * 5.0;
	float sunVis = TranslucentEntitySunShadow(worldPos, worldNormal) * saturate(skyLm * 100.0);
	r += albedo * saturate(dot(worldNormal, worldLightVector)) * 24.0 * (1.0 - sqrt(wetness)) * colorSunlight * sunVis;
	// Voxel GI fix (player/mob skins black indoors): the lightmap above only knows vanilla light levels at the entity's own
	// block, which reach 0 a few blocks from a lamp, while solid surfaces are lit by the ray-traced GI (deferred12: G()*10*albedo)
	// with far more range plus coloured/bounced light. Use that same GI term (sampled at the surface behind the entity) wherever
	// there is little sky light, i.e. indoors and in caves. max() instead of + so nothing is double counted; outdoors
	// (skyLm ~ 1) giWeight is 0 and the formula above is unchanged.
	vec3 gi = texture2DLod(colortex7, Texcoord.xy + vec2(0.0, HalfScreen.y), 0).xyz;
	float giWeight = 1.0 - saturate(skyLm * 2.0);
	r = max(r, gi * 10.0 * albedo * giWeight);
	return r;
#endif
}
#endif
 void main()
 {
   Texcoord=texcoord.xy;
   if(texcoord.x<HalfScreen.x||texcoord.y<HalfScreen.y)
     gl_FragData[0]=texture2DLod(colortex0,Texcoord.xy,0),gl_FragData[1]=texture2DLod(colortex1,Texcoord.xy,0),gl_FragData[2]=texture2DLod(colortex7,Texcoord.xy,0);
   else
     {
       Texcoord=texcoord.xy-HalfScreen;
       GBufferData v=GetGBufferData(Texcoord.xy);
       GBufferDataTransparent s=GetGBufferDataTransparent(Texcoord.xy);
       MaterialMask y=CalculateMasks(v.materialID,Texcoord.xy),i=CalculateMasks(s.materialID,Texcoord.xy);
       #if defined(IS_IRIS) && MC_VERSION >= 260000
       // Iris 26+: banner pattern layers (and other coplanar translucent block entities) are drawn after the solid base at EXACTLY the same depth.
       // A strict < rejected them, so only the white base showed. Accept equal depth for the translucent-entity material.
       bool c=s.depth<v.depth||(abs(float(MAT_ID_TRANSLUCENT_ENTITY)-s.materialID*255.)<.4&&s.depth<=v.depth);
       #else
       bool c=s.depth<v.depth;
       #endif
       if(c)
         v.depth=s.depth,v.normal=s.normal,v.smoothness=s.smoothness,v.metalness=0.,v.mcLightmap=s.mcLightmap,i.sky=0.;
       bool x=abs(111.-s.materialID*255.)<.4&&c;
       #if defined(IS_IRIS) && MC_VERSION >= 260000
       bool transEnt=abs(float(MAT_ID_TRANSLUCENT_ENTITY)-s.materialID*255.)<.4&&c;
       #else
       const bool transEnt=false;
       #endif
       vec4 f=GetViewPosition(Texcoord.xy,v.depth),m=gbufferModelViewInverse*vec4(f.xyz,1.),d=gbufferModelViewInverse*vec4(f.xyz,0.);
       vec3 z=normalize(f.xyz),h=normalize(d.xyz),n=normalize((gbufferModelViewInverse*vec4(v.normal,0.)).xyz),r=normalize((gbufferModelViewInverse*vec4(v.geoNormal,0.)).xyz);
       float a=length(f.xyz);
       vec4 w=vec4(0.);
       float t=e(v.smoothness,v.metalness);
       if(t>.0001&&i.sky<.5)
         {
           // Flicker-stable SSR march for every translucent surface (water, ice, glass, stained glass, slime, portal), not only water.
           ReflIsWater=c&&(i.water>.5||i.ice>.5||i.stainedGlass>.5||i.portal>.5);
           w=G(1.-v.smoothness,v.metalness,m.xyz,f.xyz,n.xyz,r,h.xyz,y.leaves,v.mcLightmap.y,ExpToLinearDepth(v.depth),v.parallaxOffset,c);
         }
       vec4 F=texture2DLod(colortex1,Texcoord.xy+HalfScreen,0);
       vec3 k=F.xyz;
       k.xyz=pow(k.xyz,vec3(2.2));
       if(x)
         {
           #ifdef IMPROVED_PARTICLE_BLENDING
           k.xyz=mix(k.xyz,sqrt(k.xyz*length(s.albedo.xyz+.1))*s.albedo.xyz*.1,s.albedo.w);
           #else
           k.xyz*=pow(s.albedo.xyz,vec3(1.))*10.;
           #endif
         }
       #if defined(IS_IRIS) && MC_VERSION >= 260000
       if(transEnt)
         k.xyz=mix(k.xyz,TranslucentEntityLighting(TransformInputColor(s.albedo.xyz),m.xyz,n,v.mcLightmap)*.001,s.albedo.w);
       #endif
       if(c&&!x&&!transEnt)
         {
           vec3 J=GetViewPosition(Texcoord.xy,MergeLodSolidDepth(Texcoord.xy,texture2DLod(depthtex1,Texcoord.xy,0).x)).xyz;
           float p=length(J.xyz),g=p-a;
           vec3 B=s.normal-s.geoNormal*1.05;
           float L=saturate(g*.5)*.5;
           vec2 refrOff=B.xy/(a+1.5)*L;
           {
             // Fade the base refraction out smoothly near the screen border instead of clamping
             // the sample to the last pixel row/column (which smears into stretched streaks).
             vec2 refrUV=(Texcoord.xy+refrOff)/HalfScreen;
             vec2 refrEdge=mix(refrUV,1.-refrUV,step(0.,refrOff));
             vec2 refrFade=smoothstep(vec2(0.),vec2(.05),refrEdge);
             refrOff*=refrFade;
           }
           bool refrWater=i.water>.5;
           float wvR=1.,wvS=1.;
           vec4 refrR=RefrFetch(Texcoord.xy,refrOff,m.xyz,refrWater,wvR);
           if(wvR<.999)
             {
               // only fetch the unrefracted view where the refracted sample is not fully valid
               float wv0=1.;
               vec4 refrR0=RefrFetch(Texcoord.xy,vec2(0.),m.xyz,refrWater,wv0);
               refrR=mix(refrR0,refrR,wvR);
             }
           #ifdef WATER_SNELL_BEND
           if(refrWater&&isEyeInWater<1)
             {
               // Snell's law illusion: bend the view ray entering the water (n=1.333) and shift the
               // sample to where the bent ray would land. Only moves the sampling position, so no
               // new reflections or duplicated geometry are created. Where the bend cannot be
               // applied (screen border, depth edges, camera tilt) it cross-fades (opacity) back
               // to the normal refracted water instead of cutting or blurring.
               float snStr=WATER_SNELL_BEND_STRENGTH*smoothstep(0.,.6,g);
               vec3 snV=z,snN=normalize(mix(s.geoNormal,s.normal,.5));
               if(dot(snN,snV)>0.) snN=-snN;
               vec3 snR=refract(snV,snN,1./1.333);
               if(snStr>.004&&dot(snR,snR)>.0001)
                 {
                   float snD=clamp(g,0.,12.);
                   vec3 snP0=f.xyz+snV*snD,snP1=f.xyz+snR*snD;
                   float snFront=smoothstep(.0,.3,-max(snP0.z,snP1.z)-.05);
                   // screen shift of the bent vs straight ray; the projection offset terms cancel,
                   // so only the focal scale and the perspective divide are needed
                   vec2 snShift=.5*vec2(gbufferProjection[0].x,gbufferProjection[1].y)
                               *(snP1.xy/max(-snP1.z,.05)-snP0.xy/max(-snP0.z,.05))*DOWNSCALE_FACTOR;
                   snShift*=snStr;
                   snShift*=min(1.,.12/max(length(snShift),1e-5));
                   vec2 snUV=(Texcoord.xy+refrOff+snShift)/HalfScreen;
                   vec2 snEdge=mix(snUV,1.-snUV,step(0.,snShift));
                   vec2 snB=smoothstep(vec2(0.),vec2(.05,.14),snEdge);
                   float wS=snFront*snB.x*snB.y;
                   // skip the extra sample when the bend is negligible or fully faded out
                   if(wS>.003&&dot(snShift,snShift)>2.5e-7)
                     {
                       vec4 refrS=RefrFetch(Texcoord.xy,refrOff+snShift,m.xyz,refrWater,wvS);
                       refrR=mix(refrR,refrS,wS*wvS);
                     }
                 }
             }
           #endif
           k.xyz=refrR.xyz;
           if(refrWater&&isEyeInWater<1)
             k.xyz*=100.,UnderwaterFog(k.xyz,refrR.w,h,colorSkyUp,colorSunlight),k.xyz*=.01;
           if(i.stainedGlass>.5||i.portal>.5)
             {
               vec3 V=normalize(s.albedo.xyz+.0001)*pow(length(s.albedo.xyz),.5);
               k.xyz*=mix(vec3(1.),V,vec3(pow(s.albedo.w,.2)));
               k.xyz*=mix(vec3(1.),V,vec3(pow(s.albedo.w,.2)));
             }
           #ifdef NETHER_PORTAL_GLOW
           // Nether portal glows by itself: add its own (swirling) texture colour on top. k is in the .001 scale (see transEnt above).
           if(i.portal>.5)
             k.xyz+=s.albedo.xyz*max(s.albedo.w,.5)*.001*GI_LIGHT_BLOCK_INTENSITY*NETHER_PORTAL_GLOW_BRIGHTNESS;
           #endif
         }
       k.xyz=pow(k.xyz,vec3(1./2.2));
       gl_FragData[0]=texture2DLod(colortex0,Texcoord.xy,0);
       gl_FragData[1]=vec4(k.xyz,v.smoothness);
       gl_FragData[2]=max(vec4(0.),w*vec4(vec3(.1),1.));
     }
 };




/* DRAWBUFFERS:017 */
