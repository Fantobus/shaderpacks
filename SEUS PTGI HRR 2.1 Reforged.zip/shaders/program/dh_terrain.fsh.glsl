
// Distant Horizons LOD terrain - fragment stage
in vec4 color;
in vec3 worldPos;
in vec4 lodViewPos;
in vec3 viewNormal;
in vec2 blockLight;
in vec4 preDownscaleProjPos;
flat in int materialID;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"

void main() {
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
	}

	// LOD terrain only draws beyond the vanilla render distance
	vec3 viewWorldPos = worldPos - cameraPosition;
	if (max(dot(viewWorldPos.xz, viewWorldPos.xz), viewWorldPos.y * viewWorldPos.y) < (far - 16.0) * (far - 16.0)) {
		discard;
	}

	GBufferData gbuffer;

	vec4 albedo = color;
	// LOD vertex colors have no texture detail, so break them up with the same per-texel noise as the shadow/GI path
	ivec3 pixelPos = ivec3(floor(worldPos * 16.0 + 1e-3));
	ivec2 texel = (pixelPos.xz + 17 * pixelPos.y) & 63;
	float noise = texelFetch(noisetex, texel, 0).r;
	albedo.rgb = pow(albedo.rgb, vec3(noise * 0.3 + 0.85));

	vec3 worldNormal = mat3(gbufferModelViewInverse) * viewNormal;

	float wetnessModulator = 1.0;
	wetnessModulator *= saturate(worldNormal.y * 10.5 + 0.7);
	wetnessModulator *= saturate(abs(2.0 - float(materialID)));
	wetnessModulator *= clamp(blockLight.y * 1.05 - 0.7, 0.0, 0.3) / 0.3;
	wetnessModulator *= saturate(wetness * 1.1 - 0.1);

	float smoothness = 0.0;
	#ifdef FORCE_WET_EFFECT
		smoothness = mix(smoothness, 1.0, saturate(wetnessModulator * max(1.0 - float(isEyeInWater), 0.0)));
	#endif

	albedo.rgb = pow(albedo.rgb, vec3(1.0 + wetnessModulator * 0.1));

	#ifdef WET_CAVE_EFFECT
		float caveDamp = 1.0;
		caveDamp *= pow((1.0 - blockLight.y), 2.0);
		caveDamp *= pow((1.0 - blockLight.x), 1.0);
		smoothness = mix(smoothness, 1.0, 0.9 * caveDamp);
	#endif

	gbuffer.albedo = albedo;
	gbuffer.depth = 0.0;
	gbuffer.normal = viewNormal;
	gbuffer.mcLightmap = blockLight;
	gbuffer.smoothness = smoothness;
	gbuffer.metalness = 0.0;
	gbuffer.materialID = (float(materialID) + 0.1) / 255.0;
	gbuffer.emissive = 0.0;
	gbuffer.geoNormal = viewNormal;
	gbuffer.totalTexGrad = 0.0;
	gbuffer.parallaxOffset = 0.0;

	// Motion vectors for TAA. Built with the *vanilla* projection pair on purpose: it has the same x/y mapping as the
	// LOD projection, matches the vanilla-equivalent LOD depth the passes reconstruct from, and does not depend on
	// dhPreviousProjection (which not every Iris build provides - an unset matrix gives NaN motion and corrupts TAA history).
	{
		vec4 projPos = gbufferProjection * vec4(lodViewPos.xyz, 1.0);
		projPos /= projPos.w;
		projPos = projPos * 0.5 + 0.5;

		vec3 worldPosPrev = (gbufferModelViewInverse * vec4(lodViewPos.xyz, 1.0)).xyz + cameraPosition - previousCameraPosition;
		vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		vec3 motion = projPos.xyz - projPosPrev.xyz;
		if (any(isnan(motion)) || any(isinf(motion))) motion = vec3(0.0);
		gbuffer.motion = motion;
	}

	vec4 frag0, frag1, frag2, frag3;
	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	gl_FragData[3] = frag3;
}

/* RENDERTARGETS: 0,1,2,8 */
