

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"

out vec4 texcoord;


void main() 
{
	gl_Position = ftransform();
	texcoord = gl_MultiTexCoord0;

	// CropQuadForDownscale(gl_Position, texcoord);
}
