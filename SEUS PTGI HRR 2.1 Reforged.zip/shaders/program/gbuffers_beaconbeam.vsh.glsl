
/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

// Dedicated beacon beam program. Reforged previously had no gbuffers_beaconbeam
// file, so beacon beams fell back to gbuffers_textured - a program built for
// terrain, which samples the resource pack's specular/normal PBR maps using the
// beam's own texcoords. Those maps don't have matching data for the beam texture,
// which is what produced the corrupted/glitched-looking beam. This program (plus
// its fragment shader) exists to render beams correctly instead. See
// BEACON_BEAM_TEXTURE_FIX in lib/Uniforms.inc for the on/off toggle.


#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"


attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;
attribute vec3 at_velocity;



out vec4 color;
out vec4 texcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec3 viewPos;
out vec3 velocity;
out vec4 preDownscaleProjPos;

out vec3 worldNormal;

out vec2 blockLight;

out float materialIDs;






void main() {

	color = gl_Color;

	texcoord = gl_MultiTexCoord0;
	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;

	blockLight.x = clamp((lmcoord.x * 33.05f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);
	blockLight.y = clamp((lmcoord.y * 33.75f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);

	worldNormal = gl_Normal;

	
	vec4 localWorldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

	worldPosition = localWorldPos.xyz + cameraPosition.xyz;
	viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

	#ifdef BEACON_BEAM_TEXTURE_FIX
	// Beacon beams are static world geometry, not moving entities, so there is no
	// real per-vertex motion to report here. Leaving this at zero makes the
	// fragment shader always take its camera-only reprojection branch, which is
	// the correct one for something that doesn't move on its own.
	velocity = vec3(0.0);
	#else
	// Original path doesn't use this varying at all (see the .fsh), but it's
	// left assigned/harmless either way.
	velocity = vec3(0.0);
	#endif

	//Gather materials
	materialIDs = 1.0f;

	#ifdef BEACON_BEAM_TEXTURE_FIX
	vec4 vp = gl_ModelViewMatrix * gl_Vertex;

	gl_Position = gl_ProjectionMatrix * vp;
	#else
	// Original path: reforged had no gbuffers_beaconbeam file, so beacon beams
	// fell back to gbuffers_textured, whose vertex shader reconstructs the
	// clip-space position from world position through gbufferModelView instead
	// of transforming gl_Vertex through gl_ModelViewMatrix directly. Matching
	// that formula here (instead of the one above) reproduces reforged's
	// original beacon beam transform exactly.
	gl_Position = gl_ProjectionMatrix * gbufferModelView * localWorldPos;
	#endif

	FinalVertexTransformTAA(gl_Position, preDownscaleProjPos);


}
