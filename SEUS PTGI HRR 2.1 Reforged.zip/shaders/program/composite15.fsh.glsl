#extension GL_ARB_gpu_shader5 : enable

/*
 Water ripples, (deferred5 wave simulation + composite8
 water-presence field).

 This replaces the old composite15 pass, which only ran a second FXAA pass when
 FINAL_FXAA > 1 - an option value that does not exist (FINAL_FXAA is [0 1]) - so
 it never did anything.

 It maintains two camera-centred fields, +/-24 blocks around the player, 512x512:

   colortex15  r,g  wave height now / last frame (damped wave equation, Verlet)
               b    "there is water here" splat (read back from the screen)
               a    water surface height, camera-relative
   colortex14  row 0   history of the last 48 positions of the body (the wake path)
               rest    this frame's analytic Kelvin-wake slope (xy)

 gbuffers_water reads both and tilts the water normal with them (lib/WakeField.inc).
 The pass runs at the end of the frame, so the normals use last frame's field,
 re-anchored to the current camera.
*/

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/WakeField.inc"
#include "/lib/Footprints.inc"

in vec4 texcoord;

// Player body. Iris provides the player's eye position, so third person just works there.
// OptiFine has no such uniform and cameraPosition is the CAMERA, which in third person (F5) floats
// ~4 blocks away from the player. The camera is always aimed at the player's eye, so the eye lies on the
// centre view ray: the player's own model is tagged 0.7 in colortex8.a (gbuffers_entities, entity.properties),
// and when that tag is found at the screen centre the eye is that far along the centre ray. In first
// person the centre pixel is never the player model and the camera is the body (exact).
#ifdef IS_IRIS
uniform vec3 eyePosition;
uniform bool is_sneaking;
// xyz = player eye (world, camera-relative origin = cameraPosition), w: 1 found / 0.5 water covers the centre / 0 not the player
vec4 WakeFindPlayerEye() { return vec4(eyePosition, 1.0); }
bool wakeSneaking() { return is_sneaking; }
#else
vec4 WakeFindPlayerEye()
{
    float centreWater = 0.0;
    ivec2 tsz = textureSize(depthtex0, 0);
    // FIRST PERSON = the hand/arm is drawn. In third person it never is. Without this check, switching from
    // third back to first person while looking at water left the screen centre reading "water" (0.5), which
    // made the code below keep reusing the remembered third-person camera distance: the body was placed that
    // far along the view ray, so a ripple spawned at the point you look at and followed the camera.
    // depthtex1 contains the hand, depthtex2 does not - they differ where the hand is. Probed on both sides of
    // the screen (main hand can be set to the left). With the hand hidden (F1) this falls back to the old behaviour.
    {
        const vec2 handProbes[6] = vec2[6](vec2(0.82, 0.08), vec2(0.88, 0.16), vec2(0.76, 0.05),
                                           vec2(0.18, 0.08), vec2(0.12, 0.16), vec2(0.24, 0.05));
        for (int hi = 0; hi < 6; hi++)
        {
            ivec2 hp = ivec2(DownscaleTexcoord(handProbes[hi]) * vec2(tsz));
            if (texelFetch(depthtex2, hp, 0).x - texelFetch(depthtex1, hp, 0).x > 0.01)
                return vec4(cameraPosition, -1.0); // -1 = the hand is drawn: certainly first person
        }
    }
    // a small cross of probes: the head covers the centre, but a thin gap/nameplate must not lose it
    const vec2 probes[5] = vec2[5](vec2(0.0), vec2(0.012, 0.0), vec2(-0.012, 0.0), vec2(0.0, 0.02), vec2(0.0, -0.02));
    for (int i = 0; i < 5; i++)
    {
        vec2 uv = vec2(0.5) + probes[i];
        ivec2 ip = ivec2(DownscaleTexcoord(uv) * vec2(tsz));
        float tag = texelFetch(colortex8, ip, 0).a;
        if (i == 0 && abs(tag - 0.5) < 0.15) centreWater = 0.5;
        if (abs(tag - 0.7) > 0.04) continue;
        float d = texelFetch(depthtex0, ip, 0).x;
        if (d > 0.9999) continue;
        vec3 vp = GetViewPositionNoJitter(uv, d).xyz;
        float dist = length(vp);
        if (dist > 6.5 || dist < 0.3) continue; // third person never goes further than ~4 blocks
        // the centre ray enters the head ~0.3 before the eye point; view space looks down -z
        vec3 eyeV = vec3(0.0, 0.0, vp.z - 0.3);
        return vec4(cameraPosition + (gbufferModelViewInverse * vec4(eyeV, 0.0)).xyz, 1.0);
    }
    return vec4(cameraPosition, centreWater);
}
bool wakeSneaking() { return false; }
#endif
uniform float eyeAltitude;

// Screen position of a camera-relative world point; (-1,-1) when it is off screen.
vec2 WakeProbeUv(vec3 probeFeet)
{
    vec4 clip = gbufferProjection * (gbufferModelView * vec4(probeFeet, 1.0));
    if (clip.w <= 0.0) return vec2(-1.0);
    vec2 uv = (clip.xy / clip.w) * 0.5 + 0.5;
    return clamp(uv, 0.0, 1.0) == uv ? uv : vec2(-1.0);
}

// Field state (height, prev height) from the previous frame; calm (0)
// outside the field.
vec2 wakeRG(vec2 uv) {
    if (clamp(uv, 0.0, 1.0) != uv) return vec2(0.0);
    return texture(colortex15, uv).rg;
}

// 9-tap optimized Catmull-Rom (Jimenez) — sharp resampling for the
// per-frame scroll. This is the fix for the smear/tear: bilinear acts
// as a low-pass filter, and re-applying it every frame while moving
// erased the wake and left directional streaks.
vec4 wakeCR(vec2 uv) {
    vec2 samplePos = uv * WAKE_RES;
    vec2 texPos1   = floor(samplePos - 0.5) + 0.5;
    vec2 f  = samplePos - texPos1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 tc0  = (texPos1 - 1.0)       / WAKE_RES;
    vec2 tc12 = (texPos1 + w2 / w12)  / WAKE_RES;
    vec2 tc3  = (texPos1 + 2.0)       / WAKE_RES;
    return
        texture(colortex15, vec2(tc0.x,  tc0.y )) * (w0.x  * w0.y ) +
        texture(colortex15, vec2(tc12.x, tc0.y )) * (w12.x * w0.y ) +
        texture(colortex15, vec2(tc3.x,  tc0.y )) * (w3.x  * w0.y ) +
        texture(colortex15, vec2(tc0.x,  tc12.y)) * (w0.x  * w12.y) +
        texture(colortex15, vec2(tc12.x, tc12.y)) * (w12.x * w12.y) +
        texture(colortex15, vec2(tc3.x,  tc12.y)) * (w3.x  * w12.y) +
        texture(colortex15, vec2(tc0.x,  tc3.y )) * (w0.x  * w3.y ) +
        texture(colortex15, vec2(tc12.x, tc3.y )) * (w12.x * w3.y ) +
        texture(colortex15, vec2(tc3.x,  tc3.y )) * (w3.x  * w3.y );
}

#if FOOTPRINTS == 1
// Footprint register (row 1 of colortex14, see lib/Footprints.inc). Slot i after this frame's shift:
// a fresh print enters at slot 0 and everything else moves one slot along; every print ages by dt and is
// re-expressed against the current 256-block anchor.
vec4 FootEntry(int i, bool pushF, vec4 newPrint, vec2 rebase, float dt)
{
    if (pushF && i == 0) return newPrint;
    vec4 e = texelFetch(colortex14, ivec2(pushF ? i - 1 : i, 1), 0);
    if (e.z > 0.5) {
        e.xy += rebase;
        e.w = min(e.w + dt, 100000.0);
    }
    return e;
}
#endif

void main()
{
    vec2 tc = texcoord.xy;
#if WATER_WAKE == 1 || FOOTPRINTS == 1
    const float texel = 1.0 / WAKE_RES;
    const float dx    = 2.0 * WAKE_HALF / WAKE_RES; // 0.125 blocks
    float dt = clamp(frameTime, 1e-3, 0.05);

    // Scroll: this texel's world point, located in last frame's buffer.
    vec3 camMove = cameraPosition - previousCameraPosition;

    // ---- where the BODY is, and how fast IT is moving ----------------
    // Sanity guard: if this build of Iris does not supply wakeEyePos it
    // reads as the origin, which would be thousands of blocks away. The
    // third-person camera never exceeds ~4 blocks, so anything past 8
    // means the uniform is not real and we fall back to first-person
    // behaviour (offset zero) rather than injecting the wake into the
    // middle of nowhere.
    vec4 wakeFind = WakeFindPlayerEye();
    // Last frame's camera->eye offset in VIEW space (xyz) + confidence (w), kept in colortex14 texel (WAKE_RES-3, 0).
    // Iris and OptiFine both use it for the discontinuity guards below; only OptiFine uses it to find the body.
    vec4 wakePrevView = texelFetch(colortex14, ivec2(int(WAKE_RES) - 3, 0), 0);
    bool  wakeBodyUnknown = false; // OptiFine: third person, body position not known this frame
    float wakeConfNow = 1.0;       // confidence of the remembered camera->eye offset (>0.5 = usable)
    vec3 wakeEye = wakeFind.xyz;
    bool  wakeUsedMemory = false;  // OptiFine: the body was placed from the remembered camera->eye offset
    float memBack = 0.0; // OptiFine third person: camera-to-eye distance, remembered in colortex14 texel (WAKE_RES-1, 0)
#ifndef IS_IRIS
    if (wakeFind.w > 0.75)
    {
        memBack = length(wakeEye - cameraPosition);
    }
    else if (wakeFind.w > -0.5 && wakePrevView.w > 0.5 && length(wakePrevView.xyz) > 1.0)
    {
        // Third person (the hand is not drawn and last frame the camera was detached from the player) but the
        // player model cannot be seen at the screen centre: water drawn over it (w = 0.5), the camera crossing
        // or under the surface, bubbles, terrain... Iris never has this problem, eyePosition is always exact.
        // Here the camera is rigidly attached to the player, so the camera->eye offset in VIEW space is the
        // same as last frame: reuse it, as long as the player's real eye height (eyeAltitude, player-anchored)
        // agrees.
        vec3 guess = cameraPosition + mat3(gbufferModelViewInverse) * wakePrevView.xyz;
        if (abs(eyeAltitude - guess.y) < 0.75)
        {
            wakeEye = guess;
            wakeUsedMemory = true;
            memBack = length(wakePrevView.xyz);
        }
        else
        {
            // Third person, but where the body is cannot be established this frame. Taking the camera for the
            // body is what made ripples appear on the surface whenever the camera dipped under the water or came
            // back out: the camera swings around the player while tilting, and that was read as swimming.
            // Safe failure instead: no body motion and no new ripples this frame.
            wakeBodyUnknown = true;
        }
        // the remembered offset ages while the player is not actually seen, so a stale one cannot live forever
        // (F1, hand hidden, looks like third person to this code)
        wakeConfNow = wakePrevView.w - (wakeFind.w > 0.25 ? 0.0 : dt / 16.0);
    }
    // anything else at the centre (ground, sky, mob) is not the player: first person, memory cleared
#endif
    vec3 eyeOff = wakeEye - cameraPosition;
    bool eyeOk  = length(eyeOff) < 8.0;
    vec2  bodyOff  = eyeOk ? eyeOff.xz : vec2(0.0);
    // VERTICAL offset comes from eyeAltitude, not from wakeEyePos. When
    // wakeEyePos is unavailable the old fallback was 0, so in third
    // person the water surface was still measured against the CAMERA —
    // several blocks up — and the leg gate below rejected everything.
    // That is the "physics stop in F5 when the camera is high" case; it
    // survived the earlier fix because that fix depended on the very
    // uniform that was missing.
    //
    // STILL BROKEN IN F5, because eyeAltitude is not player-anchored in
    // every build - on some it tracks the CAMERA, and then this whole
    // expression collapses to zero. The water then measures several
    // blocks below the supposed "body", the leg gate rejects it, and the
    // physics die in proportion to how far back the camera sits. Which is
    // exactly the reported symptom: fine in first person, gone in third,
    // worse the further out the camera is.
    //
    // wakeEyePos is the reliable player-anchored source and it is
    // ALREADY trusted for the horizontal offset two lines up, guarded by
    // eyeOk. Trusting it horizontally but not vertically was the
    // inconsistency. eyeAltitude stays as the fallback for builds that
    // genuinely do not supply wakeEyePos - where eyeOk is false, the
    // camera is the body anyway and both agree.
    float bodyOffY = eyeOk ? eyeOff.y : (eyeAltitude - cameraPosition.y);

    // The camera's velocity is NOT the player's in third person: orbit
    // the view while standing still and the camera sweeps sideways at
    // speed, which would trail a wake off a stationary swimmer. Rebuild
    // last frame's eye position from last frame's camera orientation —
    // the camera sits a fixed distance back along its own forward axis,
    // so the previous offset is that same distance along the PREVIOUS
    // forward. What is left is the body's own motion.
    vec3 eyeMove = camMove;
    // IRIS CROUCH FIX: Iris always supplies eyePosition, so eyeOk is also true in first person, where
    // the eye is NOT a distance 'back' along the camera's forward axis - when crouching the camera
    // eases down while the eye position is exact, so eyeOff is a small mostly-vertical offset.
    // Rebuilding the previous eye along the previous forward axis then turns every head rotation
    // and every crouch step into fake horizontal body speed, which drove the V wake. The rebuild
    // only makes sense in third person (camera several blocks behind the eye); in first person
    // the camera motion is the body motion.
    float eyeBack = length(eyeOff);
    if (eyeOk && eyeBack > 1.0) {
        float back = eyeBack;
        // Camera forward in WORLD space is the negated third ROW of the
        // view matrix's rotation. I had written mat3(M)[2], which in GLSL
        // is the third COLUMN — a completely different vector. That put
        // prevEye somewhere arbitrary, so eyeMove (and with it the wake's
        // heading and speed) was garbage. In first person the eyeOk guard
        // skips this branch entirely, which is why it only ever showed up
        // in F5 — as the wake freaking out.
        vec3 fwdPrev = -normalize(vec3(gbufferPreviousModelView[0][2],
                                       gbufferPreviousModelView[1][2],
                                       gbufferPreviousModelView[2][2]));
        // IRIS THIRD-PERSON CROUCH FIX: the line above assumes the eye lies exactly on the camera's
        // forward axis. Crouching breaks that on Iris (the eye position and the eased camera pivot
        // differ by a vertical offset), so even a motionless crouching player got a constant fake
        // velocity of (eyeOff - fwd*|eyeOff|)/dt - the V wake. Carry the offset in VIEW space
        // instead: the camera is rigidly attached to the player, so this offset is the same in last
        // frame's view, whatever its direction. Exact for any offset, and identical to before when
        // the eye is on the forward axis.
        vec3 eyeView = mat3(gbufferModelView) * eyeOff;
        vec3 prevOffW = transpose(mat3(gbufferPreviousModelView)) * eyeView;
        vec3 prevEye = previousCameraPosition + prevOffW;
        eyeMove = wakeEye - prevEye;
        // Backstop: your body cannot outrun the camera by a wide margin
        // in a single frame. If the reconstruction ever disagrees that
        // badly again, fall back to the camera's own motion rather than
        // driving the wake with nonsense.
        if (length(eyeMove) > length(camMove) * 3.0 + 0.5) eyeMove = camMove;
    }
    // DISCONTINUITY GUARD (OptiFine and Iris). The eye itself never jumps when the view changes, but the camera does
    // and the reconstruction of last frame's eye from the rigid view-space offset breaks for that frame. The camera jumps ~4 blocks in a single frame when the
    // view changes (and the eye estimate can pop when the player model appears or disappears behind water);
    // that jump was read as the player moving at huge speed, a dive splash/wake right under the point you look
    // at. The camera is rigid with the player, so the camera->eye offset in view space must not change from
    // frame to frame: if it does, this frame's motion is unknown and treated as zero.
    vec3 wakeViewNow = eyeOk ? mat3(gbufferModelView) * eyeOff : vec3(0.0);
    if (wakeBodyUnknown || (wakePrevView.w > 0.5 && length(wakeViewNow - wakePrevView.xyz) > 0.6))
        eyeMove = vec3(0.0);
    // keep remembering the real offset while the body cannot be seen this frame
    if (wakeBodyUnknown) wakeViewNow = wakePrevView.xyz;
    // CAMERA TELEPORT (switching to the FRONT third-person view moves the camera from behind the player to in
    // front of him, ~8 blocks in a single frame; a teleport does the same). No player moves that far in one
    // frame, and when the reconstruction above disagrees, the backstop falls back to the raw camera motion -
    // which is exactly that jump, i.e. a fake speed of hundreds of blocks per second and a splash/wake.
    if (length(camMove) > 2.5)
        eyeMove = vec3(0.0);
    vec2 prevUv  = tc + camMove.xz / (2.0 * WAKE_HALF);

#if FOOTPRINTS == 1
    // ================= FOOTPRINTS ======================================
    // Same body as the ripples: eyeMove / bodyOff / wakeEye already carry every third-person fix above
    // (Iris eyePosition, OptiFine screen-centre player tag + remembered camera offset, the view-change and
    // camera-teleport guards, the crouch fix). A print is only ever laid when the body position is KNOWN:
    // on OptiFine in third person, a frame where the player model cannot be found would otherwise place the
    // boot where the camera is, several blocks away.
    vec4 footOut = vec4(0.0);
    bool isFootPx = false;
    {
        const float STRIDE = 0.55;   // blocks between footfalls
        ivec2 fpx = ivec2(gl_FragCoord.xy);
        isFootPx = (fpx.y == 1 && fpx.x <= FOOT_LEN + FOOT_CHUNKS);
        if (isFootPx) {
            vec2 anchorNow = floor(cameraPosition.xz / 256.0) * 256.0;
            vec4 anchorOld = texelFetch(colortex14, ivec2(FOOT_LEN + FOOT_CHUNKS, 1), 0);
            vec2 rebase = anchorOld.xy - anchorNow;

#ifdef IS_IRIS
            bool bodyKnown = true;
#else
            bool bodyKnown = wakeFind.w > 0.75 || wakeFind.w < -0.5 || wakeUsedMemory
                          || abs(cameraPosition.y - eyeAltitude) < 0.15; // hand hidden (F1), eye-level camera
#endif
            bodyKnown = bodyKnown && !wakeBodyUnknown && eyeOk;

            vec2 hereW = bodyOff + cameraPosition.xz - anchorNow;
            vec4 newest = texelFetch(colortex14, ivec2(0, 1), 0);
            float movedF = newest.z > 0.5 ? distance(hereW, newest.xy + rebase) : 1e3;
            float spd = length(eyeMove.xz) / dt;
            // Walking: steady eye height (a jump or a fall is not a step), a believable speed, and not a
            // frame the guards above zeroed (view change, camera teleport -> eyeMove == 0 -> spd == 0).
            bool pushF = bodyKnown && abs(eyeMove.y) < 0.03 && spd > 0.3 && spd < 14.0 && movedF > STRIDE;

            // Feet height: eye minus the eye height, which is lower while crouching.
            float feetY = wakeEye.y - (wakeSneaking() ? 1.27 : 1.62);
            // Left foot, right foot: step out perpendicular to the direction of travel and alternate.
            // The parity comes from position, one stride apart flips it, so it needs no extra channel.
            vec2 fwdF = length(eyeMove.xz) > 1e-5 ? normalize(eyeMove.xz) : vec2(1.0, 0.0);
            vec2 perpF = vec2(-fwdF.y, fwdF.x);
            float par = mod(floor(dot(hereW, vec2(1.0)) / STRIDE), 2.0);
            vec2 stepW = hereW + perpF * (par < 0.5 ? -1.0 : 1.0) * (FOOTPRINT_SHAPE == 1 ? 0.125 : 0.11);
            float headIdx = clamp(floor(fract(atan(fwdF.y, fwdF.x) / 6.2831853 + 1.0) * 64.0), 0.0, 63.0);
            vec4 newPrint = vec4(stepW, floor((feetY + 128.0) * 16.0) * 64.0 + headIdx, 0.0);

            if (fpx.x < FOOT_LEN) {
                footOut = FootEntry(fpx.x, pushF, newPrint, rebase, dt);
            } else if (fpx.x < FOOT_LEN + FOOT_CHUNKS) {
                // bounding box of this chunk of prints
                int c = fpx.x - FOOT_LEN;
                vec4 bb = vec4(1e9, 1e9, -1e9, -1e9);
                for (int k = 0; k < FOOT_CHUNK; k++) {
                    vec4 e = FootEntry(c * FOOT_CHUNK + k, pushF, newPrint, rebase, dt);
                    if (e.z < 0.5) break;
                    bb = vec4(min(bb.xy, e.xy), max(bb.zw, e.xy));
                }
                footOut = bb;
            } else {
                footOut = vec4(anchorNow, 0.0, 0.0);
            }
        }
    }
#if WATER_WAKE == 0
    {
        // ripples off: only the footprint register (and the OptiFine body memory it relies on) is kept
        ivec2 opx = ivec2(gl_FragCoord.xy);
        vec4 o = isFootPx ? footOut : vec4(0.0);
#ifndef IS_IRIS
        if (opx == ivec2(int(WAKE_RES) - 1, 0)) o = vec4(memBack, memBack > 0.0 ? 1.0 : 0.0, 0.0, 0.0);
#endif
        if (opx == ivec2(int(WAKE_RES) - 3, 0)) o = vec4(wakeViewNow, wakeConfNow);
        gl_FragData[0] = o;
        gl_FragData[1] = vec4(0.0);
        return;
    }
#endif
#endif

    // Previous state — Catmull-Rom when the 4×4 footprint fits, guarded
    // bilinear at the border (new area scrolls in calm).
    vec4 prev;
    vec2 inset = min(prevUv, 1.0 - prevUv);
    if (min(inset.x, inset.y) > 2.5 * texel) {
        prev   = wakeCR(prevUv);

        // ---- NEIGHBOURHOOD CLAMP: THE BEAM -------------------------
        // Catmull-Rom is the right filter for this - it resamples the
        // field as the camera moves without the blur bilinear would add.
        // But it is a SHARPENING filter: two of its four taps carry
        // negative weight, so it overshoots at any edge, and the result
        // can land outside the range of the texels it read.
        //
        // Normally harmless. Here it is not, because this is a FEEDBACK
        // loop - the field is resampled from itself every frame. An
        // overshoot becomes part of the next frame's input, gets
        // overshot again, and compounds. It compounds along the axis the
        // camera is moving, which is why the artefact is a straight
        // ridge that runs the way you swam, why its width changes with
        // direction (the sub-texel phase differs), and why the ripples
        // along it are evenly spaced (it is the filter's own ringing
        // frequency, not a wave).
        //
        // Someone saw part of this already and clamped .b to 0..1 - but
        // that is the splat channel, and the ringing lives in the wave
        // HEIGHT. The height has no fixed range to clamp to, so instead
        // it is clamped to the range of the texels actually sampled:
        // sharpening is allowed, inventing values is not. This is the
        // same neighbourhood clamp TAA uses, for the same reason.
        vec2 tpx = vec2(texel);
        vec4 c0 = texture(colortex15, prevUv);
        vec4 c1 = texture(colortex15, prevUv + vec2( tpx.x, 0.0));
        vec4 c2 = texture(colortex15, prevUv + vec2(-tpx.x, 0.0));
        vec4 c3 = texture(colortex15, prevUv + vec2(0.0,  tpx.y));
        vec4 c4 = texture(colortex15, prevUv + vec2(0.0, -tpx.y));
        vec4 lo = min(min(min(c0, c1), min(c2, c3)), c4);
        vec4 hi = max(max(max(c0, c1), max(c2, c3)), c4);
        prev = clamp(prev, lo, hi);

        prev.b = clamp(prev.b, 0.0, 1.0); // splat stays in its own range
    } else {
        prev = clamp(prevUv, 0.0, 1.0) == prevUv
             ? texture(colortex15, prevUv) : vec4(0.0);
    }
    // The stored water-surface height is camera-relative: age it as the
    // camera climbs/falls so "flying above water" stays detectable even
    // while the spot is off-screen.
    prev.a -= camMove.y;

    float itemCover = 0.0;  // soft 0..1: how much of a dropped item covers this texel (hit fraction)
    float mobCover  = 0.0;  // soft 0..1: how much of a mob covers this texel (hit fraction)
    float mobHits = 0.0, itemHits = 0.0;
    bool  coverObserved = false; // false: this texel is off screen / not checked, so its coverage is unknown, not zero
    // ---- WATER PRESENCE: what the screen actually shows at this spot -----
    // Each texel of the field projects
    // itself onto the screen and reads what is really drawn there, so the
    // sim knows (a) the water you are wading in and (b) where the shore is,
    // and absorbs waves that reach land. Reforged keeps no material flag
    // after the composites, so gbuffers_water / the entity passes tag
    // colortex8.a instead: 0.5 = water, 0.85 = entity, 1.0 = anything solid.
    {
        vec2  relP      = (tc - 0.5) * 2.0 * WAKE_HALF;
        float prevSplat = prev.b;
        float splatNew  = prevSplat * 0.995;   // slow decay while unseen
        float surfNew   = prev.a;

        // The probe height is "about 1.2 below the BODY's eye", measured from the camera. It used to be a
        // fixed -1.2 below the camera, which is only right in first person. In third person (and especially
        // looking straight down from above you) the water is several blocks below the camera, so every probe
        // landed on the wrong screen pixel, got rejected, the splat was never refreshed, decayed, and the
        // wave field was absorbed as "land" - the ripples vanished all at once.
        float probeY = bodyOffY - 1.2;

        // WHERE IS THE WATER SURFACE? The probe has to sit ON the surface to read the right pixel: for a
        // distant texel at a grazing view angle, a probe 0.5 block off the surface lands several blocks
        // away on screen and is rejected, so far water was never refreshed, decayed to "land" and
        // absorbed every ripple (mobs and items out there vanished). So try several heights: this
        // texel's own last surface, the surface under the player, then a spread around the body.
        vec4 refS = texture(colortex15, vec2(0.5) + (camMove.xz + bodyOff) / (2.0 * WAKE_HALF));
        float refY = refS.a - camMove.y;
        ivec2 tsz = textureSize(depthtex0, 0);
        for (int k = 0; k < 6; k++)
        {
            float py = probeY;
            if (k == 0)      py = (prev.b > 0.3) ? prev.a : probeY;
            else if (k == 1) py = (refS.b > 0.3) ? refY : probeY - 0.5;
            else if (k == 2) py = probeY;
            else if (k == 3) py = probeY - 0.5;
            else if (k == 4) py = probeY - 1.0;
            else             py = probeY - 2.0;

            vec2 puv = WakeProbeUv(vec3(relP.x, py, relP.y));
            if (puv.x < 0.0) continue;
            ivec2 ip = ivec2(DownscaleTexcoord(puv) * vec2(tsz));
            float dP = texelFetch(depthtex0, ip, 0).x;
            if (dP >= 0.99999) continue;
            vec4 vp = GetViewPositionNoJitter(puv, dP);
            vec3 seenFeet = (gbufferModelViewInverse * vec4(vp.xyz, 1.0)).xyz;
            // Only trust the reading if we are seeing this spot, at about this height. The tolerance
            // grows with range: depth is coarser far away.
            float rng = length(vec3(relP.x, py, relP.y));
            if (length(seenFeet.xz - relP) > 0.6 + 0.04 * rng || abs(seenFeet.y - py) > 0.5 + 0.02 * rng) continue;

            float tag = texelFetch(colortex8, ip, 0).a;
            if (abs(tag - 0.5) < 0.15)       // water
            {
                splatNew = 1.0;
                surfNew  = seenFeet.y;
                break;
            }
            else if (tag > 0.95)             // solid ground / wall
            {
                splatNew = 0.0;
                break;
            }
            else                             // mob, hand, particle: it tells us
            {                                // nothing about the water below it
                splatNew = prevSplat;
                break;
            }
        }
        prev.b = splatNew;
        prev.a = surfNew;

#if WATER_WAKE_MOBS == 1 || WATER_WAKE_ITEMS == 1
        // MOBS AND DROPPED ITEMS: the same screen read-back, one more question. Is a mob (colortex8.a
        // = 0.85) or a dropped item (0.77) at this texel, just above the water? Mobs are not in any
        // uniform, so the screen is the only place to find them. The player is 0.7 and is skipped here
        // (its own wake is the body simulation).
        if (splatNew > 0.5 && length(relP - bodyOff) > 1.1)
        {
            for (int mi = 0; mi < 3; mi++)
            {
                vec3 mp = vec3(relP.x, surfNew + (mi == 0 ? 0.25 : (mi == 1 ? 0.8 : 0.08)), relP.y);
                vec2 muv = WakeProbeUv(mp);
                if (muv.x < 0.0) continue;
                coverObserved = true;
                ivec2 mtsz = textureSize(depthtex0, 0);
                ivec2 mip0 = ivec2(DownscaleTexcoord(muv) * vec2(mtsz));
                // Far away a mob or item is only a few pixels wide and depth is coarser, so a single
                // exact pixel misses it from frame to frame (it flickers and the waves cancel out).
                // Look at a small cross of pixels and let the distance tolerance grow with range.
                float mdist = length(mp);
                float tolMob  = 0.55 + 0.035 * mdist;
                float tolItem = 0.28 + 0.03  * mdist;
                for (int ti = 0; ti < 5; ti++)
                {
                    ivec2 mip = mip0 + (ti == 1 ? ivec2(1, 0) : (ti == 2 ? ivec2(-1, 0) : (ti == 3 ? ivec2(0, 1) : (ti == 4 ? ivec2(0, -1) : ivec2(0)))));
                    float mtag = texelFetch(colortex8, mip, 0).a;
                    bool isItem = abs(mtag - 0.77) < 0.025;
                    bool isMob  = abs(mtag - 0.85) < 0.04;
#if WATER_WAKE_MOBS == 0
                    isMob = false;
#endif
#if WATER_WAKE_ITEMS == 0
                    isItem = false;
#endif
                    if (!isItem && !isMob) continue;
                    float md = texelFetch(depthtex0, mip, 0).x;
                    if (md >= 0.99999) continue;
                    vec3 mseen = (gbufferModelViewInverse * vec4(GetViewPositionNoJitter(muv, md).xyz, 1.0)).xyz;
                    float mdd = distance(mseen, mp);
                    if (isItem) { if (mi == 2 && mdd < tolItem) itemHits += 1.0; }
                    else if (mi < 2 && mdd < tolMob) mobHits += 1.0;
                }
            }
            // A soft hit FRACTION, not a 0/1: the screen buffers are TAA-jittered, so the outline of a
            // perfectly still boat/mob/item flips a few of these probes on and off every frame. A
            // fraction lets the deadband filter further down tell that shimmer from real movement.
            mobCover  = clamp(mobHits  / 6.0, 0.0, 1.0);
            itemCover = clamp(itemHits / 3.0, 0.0, 1.0);
        }
#endif
    }

    // Damped wave equation (Verlet), dt-invariant. Wave speed 1.2 m/s —
    // well below casual swimming (~2.2 m/s): swim speed / wave speed
    // sets the V's angle (arcsin(c/v)), so casual swimming draws a
    // readable ~66° V, sprint-swimming ~25°, boats a razor wake. At
    // 2.0 m/s the casual V was 130° wide — an invisible blunt arc.
    const float WAVE_SPEED = 1.2; // m/s
    float cfl = WAVE_SPEED * dt / dx;
    float c2  = min(cfl * cfl, 0.45);

    vec2 rgC = wakeRG(prevUv); // bilinear center, consistent with neighbors
    vec2 nL = wakeRG(prevUv - vec2(texel, 0.0));
    vec2 nR = wakeRG(prevUv + vec2(texel, 0.0));
    vec2 nD = wakeRG(prevUv - vec2(0.0, texel));
    vec2 nU = wakeRG(prevUv + vec2(0.0, texel));
    // Diagonal neighbours — needed for a ROUND wavefront (see below).
    vec2 nLD = wakeRG(prevUv + vec2(-texel, -texel));
    vec2 nRD = wakeRG(prevUv + vec2( texel, -texel));
    vec2 nLU = wakeRG(prevUv + vec2(-texel,  texel));
    vec2 nRU = wakeRG(prevUv + vec2( texel,  texel));

    // TAA-style neighborhood clamp on the Catmull-Rom resample: CR's
    // negative lobes AMPLIFY texel-frequency content a little every
    // frame while the camera moves — that sustained the fingerprint-
    // moiré swirls across the whole field. Clamped to the local
    // min/max (now incl. diagonals), CR keeps its sharpness but can't ring.
    vec2 rgMin = min(min(min(min(nL, nR), min(nU, nD)),
                         min(min(nLD, nRD), min(nLU, nRU))), rgC);
    vec2 rgMax = max(max(max(max(nL, nR), max(nU, nD)),
                         max(max(nLD, nRD), max(nLU, nRU))), rgC);
    prev.rg = clamp(prev.rg, rgMin, rgMax);

    // ISOTROPIC 9-point Laplacian. The old 5-point stencil (axes only)
    // let waves travel faster along X/Z than diagonally, so an expanding
    // ripple turned into a DIAMOND/square — the "cube-shaped ripple".
    // Weighting the diagonals in (0.25 corners, 0.5 edges, -3 center)
    // makes propagation direction-independent → genuinely round rings.
    float lap = 0.5  * (nL.x + nR.x + nU.x + nD.x)
              + 0.25 * (nLD.x + nRD.x + nLU.x + nRU.x)
              - 3.0  * rgC.x;
    // ---- THE SMOOTHING MUST BE AS ROUND AS THE LAPLACIAN ----------
    // The Laplacian above deliberately uses all EIGHT neighbours - the
    // comment where the diagonals are fetched says they exist "for a
    // ROUND wavefront". The viscosity blend below then averaged only the
    // four AXIS neighbours, throwing that away.
    //
    // A four-point average is a directional filter. Applied every frame
    // to a field that feeds back into itself, it smooths across the grid
    // axes harder than along the diagonals, so anything persistent picks
    // up the grid's orientation - and how strongly depends on which way
    // the disturbance is travelling relative to those axes. That is a
    // straight ridge whose width changes with your direction of travel.
    //
    // Same eight-neighbour weights as the Laplacian, normalised by their
    // sum (4*0.5 + 4*0.25 = 3). The wave equation and the damping now
    // agree about what "nearby" means.
    float hAvg = (0.5  * (nL.x + nR.x + nU.x + nD.x)
                + 0.25 * (nLD.x + nRD.x + nLU.x + nRU.x)) / 3.0;

    // 0.32 (~3.1 s time constant), was 0.45 (~2.2 s). Now that the
    // Kelvin wake is GENERATED near the hull and then carried by this
    // field rather than redrawn every frame, the damping is what decides
    // how far a trail reaches: at 2.2 s a boat's wake was down to 26% by
    // the time it was 24 blocks astern, which is not a trail, it is a
    // smudge. A real wake outlives that by a wide margin. Splash rings
    // linger slightly longer too, which is if anything more pond-like.
    float damp = exp(-0.32 * dt);
    float h = (2.0 * prev.r - prev.g + c2 * lap) * damp;

    // AMPLITUDE-AWARE viscosity: the reason ripples read as too subtle.
    // A flat strong pull (6.0) flattened splash/rain rings along with
    // the moiré. But the moiré lives on CALM water (tiny near-zero
    // residuals), while real ripples are far taller — so gate the pull
    // by local wave energy: calm water still gets the full 6.0 smoothing
    // (moiré killed), active ripples get a light 1.5 (they stay crisp
    // and noticeable). The Catmull-Rom clamp above is the actual moiré
    // fix now, so this can favour the ripples safely.
    float act = smoothstep(0.008, 0.045, abs(h));
    // Left at 6.0. I halved this to reduce how fast the smoothing
    // stamps grid orientation into the field, then could not measure a
    // real improvement - my isotropy test compared runs with different
    // total spread, which is not a like-for-like comparison. Reverted
    // rather than shipped on a number I do not trust. Lowering it also
    // risks the calm-water ringing this term exists to damp.
    float visc = 1.0 - exp(-mix(6.0, 1.5, act) * dt);
    h = mix(h, hAvg, visc);

    // colortex14 carries two unrelated things: row 0 is the path history,
    // every other row is this frame's wake slope. They are written
    // together at the very end of main() because the wake is not computed
    // until much further down.
    vec4 pathOut  = vec4(0.0);
    bool isPathPx = false;
    vec2 kelvGrad = vec2(0.0);

    // Body velocity, not camera velocity.
    // Crouching/standing up only changes the eye height; that is not swimming or wading motion.
    if (wakeSneaking()) eyeMove.y = 0.0;
    vec3 vel = eyeMove / dt;
    float speed     = length(vel);
    float downSpeed = max(-vel.y, 0.0);

    // Water at the player? Swimming counts directly; wading/boating
    // reads the splat — sampled at the player AND ~2 blocks around, not
    // just the exact center texel: that texel is only refreshed when you
    // look at your own feet, so swimming while watching the horizon
    // decayed it and silently killed the wake.
    // One ring at ±2 blocks: while swimming toward the horizon the
    // water right under you is off-screen, but the surface just ahead
    // is visible and keeps the splat alive.
    const vec2 taps[5] = vec2[5](vec2(0.0),
        vec2(0.0625, 0.0), vec2(-0.0625, 0.0),
        vec2(0.0, 0.0625), vec2(0.0, -0.0625));
    // Sample the splat under the BODY, not under the camera.
    vec2 ctr = vec2(0.5) + (camMove.xz + bodyOff) / (2.0 * WAKE_HALF);
    float splat = 0.0;
    float surfY = -10.0; // "no water seen" — fails the leg-height check
    for (int i = 0; i < 5; i++) {
        vec4 s = texture(colortex15, ctr + taps[i]);
        // ...and measure its height against the BODY's eye. This is what
        // silently killed every water effect in third person: surfY was
        // relative to the CAMERA, which in F5 floats a few blocks up and
        // back, so the surface read around -3 or -4 and failed the leg
        // gate below. inWater went to zero, injection stopped dead, and
        // the waves already in the field just carried on and faded —
        // "it stops making new ones in F5".
        if (s.b > splat) { splat = s.b; surfY = s.a - camMove.y - bodyOffY; }
    }
    // TIGHT leg gate: the surface must sit between your chest and just
    // under your feet (feet = -1.62). Standing on a block BESIDE water
    // (surface ≈ -1.7 or lower) no longer churns the water next to you;
    // wading, boats (~-1.0) and surface swimming (~-0.35) all pass.
    // The lower bound is "just above your feet", so it depends on how tall
    // you currently are: 1.62 standing, ~1.27 crouched. With the standing
    // value hardcoded, crouching lifted the whole gate 0.35 blocks and a
    // surface sitting exactly at your feet — standing on a block level
    // with the water — slipped inside it and started churning the water
    // you were stood beside.
    float feetGate = wakeSneaking() ? -1.23 : -1.58;
    bool atLegs = surfY > feetGate && surfY < -0.05;
    // splat ≥ 0.55 = water (the upper range encodes sky exposure for
    // rain ripples) — normalize so roofed pools splash at full size.
    // The CAMERA being underwater (isEyeInWater) says nothing about how deep the BODY is: deep underwater
    // the surface is far above you, yet this used to force "in water" on, so the push and splash were
    // drawn on the surface right above you and followed you around. Decide from the body instead:
    //   body's eye under the surface -> swimming: counts only while you are near the surface (fades
    //                                   out between 0.8 and 1.6 blocks deep)
    //   otherwise                    -> the wading / standing-in-water leg gate.
    float inWater;
    if (isEyeInWater == 1 && surfY >= -0.05)
        inWater = splat > 0.05 ? 1.0 - smoothstep(0.8, 1.6, surfY) : 0.0;
    else
        inWater = atLegs ? smoothstep(0.25, 0.55, splat) : 0.0;
    if (wakeBodyUnknown) inWater = 0.0; // OptiFine: no known body, nothing to churn the water

    // MOVED UP, ahead of the path history. It used to be computed 100
    // lines further down, which meant the path recorded samples whether
    // or not you were in water: walking to a lake quietly filled all 48
    // slots, and the instant you touched the surface a complete 36-block
    // trail was already sitting there waiting to be drawn. That is the
    // "it spawns in instantly, even at the ends" - the wake was never
    // being emitted at all, it was being REVEALED.
    // ================= PATH HISTORY ==================================
    // A wake has to remember where you have BEEN. The simulation cannot
    // hold that: at boat speed this field scrolls ~1 texel per frame, so
    // a 24-block trail must survive ~180 resamples plus viscosity, and
    // about 1% of the structure is left. That is why the wake never grew
    // — the far end was being smoothed out as fast as it was laid down.
    //
    // So the last 48 positions of the body are kept here instead, as a
    // shift register in row 0 of colortex14: texel 0 is the newest, and
    // each frame every texel copies the one to its left. A new sample is
    // pushed only after the body has moved PATH_SPACING blocks, so the
    // path is evenly spaced in DISTANCE rather than in frames, and its
    // length does not change with framerate.
    //
    // Positions are stored camera-relative and scrolled by camMove each
    // frame, exactly like the sim field — absolute world coordinates
    // would blow out the float precision far from spawn.
    const float PATH_SPACING = 0.75;   // blocks between samples
    const int   PATH_LEN     = 48;     // 48 * 0.75 = 36 blocks of memory
    {
        ivec2 px = ivec2(gl_FragCoord.xy);
        vec4 newest = texelFetch(colortex14, ivec2(0, 0), 0);
        // .xy = position (camera-relative), .z = heading angle, .w = life
        vec2 bodyNow = bodyOff;                       // body, camera-relative
        vec2 headV   = eyeMove.xz;
        float moved  = distance(bodyNow, newest.xy - camMove.xz);
        // Gated on water. Nothing is recorded while you are on land, so
        // entering the water starts an empty track and the wedge has to
        // grow from your entry point the way it should.
        //
        // Deliberately NOT clearing the buffer when you leave the water:
        // the samples are world-anchored and age normally, so a wake you
        // swam is left behind in the lake and decays there while you walk
        // up the bank - which is exactly what real water does.
        bool push    = moved > PATH_SPACING && length(headV) > 1e-4
                    && inWater > 0.05;

        isPathPx = (px.y == 0 && px.x < PATH_LEN);
        vec4 outPath = vec4(0.0);
        if (isPathPx) {
            // .z WAS the heading angle and nothing ever read it. It now
            // carries the SPEED the body had when it passed this point,
            // and .w a true AGE in seconds rather than a decaying "life".
            // Those two are what let the wake be rebuilt from the state
            // at EMISSION time instead of from the state right now, which
            // is the whole fix (see the reconstruction further down).
            // An all-zero texel is unfilled, so .z < 1e-3 marks invalid.
            float spdNew = length(headV) / max(dt, 1e-4);
            if (push) {
                outPath = (px.x == 0)
                    // Lightly low-passed against the previous sample: one
                    // frame of displacement is noisy, and pushes are only
                    // about five frames apart at boat speed.
                    ? vec4(bodyNow,
                           max(mix(newest.z > 1e-3 ? newest.z : spdNew, spdNew, 0.45), 0.05),
                           0.0)
                    : texelFetch(colortex14, ivec2(px.x - 1, 0), 0);
            } else {
                outPath = texelFetch(colortex14, px, 0);
            }
            if (!(push && px.x == 0)) {
                outPath.xy -= camMove.xz;             // keep camera-relative
                outPath.w  += dt;                     // AGE, in seconds
            }
        }
        pathOut = outPath;
    }

    // A WAKE OUTLIVES THE MOTION THAT MADE IT, so neither of the two
    // gates below can be a plain "am I moving right now" test any more.
    // The Kelvin reconstruction lives inside both of them, and with
    // `speed > 0.25` here and `hspeed > 0.4` further down, the entire
    // trail was being discarded on the first frame you stopped - no
    // matter what the reconstruction itself decided. That outer pair is
    // the real reason the wake vanished the instant you let go.
    //
    // They now also open when the path buffer still holds a wake worth
    // drawing. Everything inside that genuinely needs motion (the push
    // injection) is separately scaled by `drive`, which falls to zero on
    // its own, so nothing gets stamped into the water while you drift.
    vec4 pAlive = texelFetch(colortex14, ivec2(0, 0), 0);
    bool wakeAlive = pAlive.z > 1e-3 && pAlive.w < 14.0;

    // ---- GENERATE AND DRAW ARE NOW SEPARATE -----------------------
    // This was reverted once. The split worked, but the beam artefact -
    // rare only because the wake used to stop existing the moment you
    // left the water - then showed up almost constantly, and making a
    // visible artefact permanent to win back a trail at the shoreline
    // was a bad deal. It stayed reverted until the beam was understood.
    //
    // The beam is understood and fixed (see the endpoint rejection in
    // the reconstruction below), and confirmed gone in game. So:
    //
    //   GENERATE - in the water, actually moving.
    //   DRAW     - whenever a live trail exists, wherever you are.
    //
    // Without this the `* inWater` removal further down does nothing:
    // that stopped the AMPLITUDE collapsing when you jump, but this gate
    // still threw the whole trail away one level up. Both halves are
    // needed, and only one of them was ever in.
    if ((inWater > 0.05 && speed > 0.25) || wakeAlive) {
        // Field is camera-centred (that is what keeps it on screen), so
        // offset to the BODY before working out where the water is being
        // disturbed. In first person bodyOff is zero and nothing changes.
        vec2 rel = (tc - 0.5) * 2.0 * WAKE_HALF - bodyOff;
        float inj = dt * 60.0; // constant impulse per SECOND, not per frame

#if WATER_WAKE_SPLASH == 1
        // Splash ring when you drop into water. ONE clean round crater
        // that rings outward — the old version added four "crown"
        // satellites at fixed corner offsets, and four points in a
        // square is exactly what read as a SQUARE ripple. Gone.
        // Threshold 1.5 (was 4.0) so even a small hop into water
        // registers; the leg gate above already excludes crouching on
        // land beside water, and a modest fall easily clears 1.5 m/s.
        float dive = max(downSpeed - 1.5, 0.0);
        float diveAmp = min(dive * dive, 60.0) * 0.06
                      * WATER_WAKE_STRENGTH * inWater * inj;
        vec2 relD = rel - clamp(vel.xz * 0.10, vec2(-0.8), vec2(0.8));
        h -= diveAmp * exp(-dot(relD, relD) * 1.6);
#endif

#if WATER_WAKE_KELVIN == 1 || WATER_WAKE_PUSH == 1
        vec2 horiz = vel.xz;
        float hspeed = length(horiz);
        if (hspeed > 0.4 || wakeAlive) {
            // Guarded: this gate now opens at zero speed, and horiz/hspeed
            // was a 0/0 there. The fallback direction is never used for
            // anything visible, because every term it feeds is scaled by
            // `drive`, which is zero whenever hspeed is.
            vec2 fwd = hspeed > 1e-4 ? horiz / hspeed : vec2(1.0, 0.0);
            float s = dot(rel, -fwd);                // blocks BEHIND the body
            float q = dot(rel, vec2(-fwd.y, fwd.x)); // lateral offset
            float A = clamp(0.16 * speed, 0.20, 0.55) * WATER_WAKE_STRENGTH;

#if WATER_WAKE_PUSH == 1
            // ---- CONTACT POINT, and nothing else --------------------
            // The wave equation above is a real one: finite wave speed,
            // isotropic Laplacian. Feed it a moving point disturbance
            // and it generates the whole picture by itself — every spot
            // the body just occupied keeps radiating a circular wavelet
            // (Huygens), those wavelets expand and overlap into the
            // trail behind, and where you advance toward waves you made
            // a moment ago their crests bunch up in front of you. With
            // wave speed 1.2 m/s against a 2.2 m/s swim you also outrun
            // them, so the pile-up collapses onto a cone of half-angle
            // asin(c/v). All of that is physics the sim already knows.
            //
            // The old code hand-placed a bow bump 0.75 blocks ahead and
            // shed arcs on a 10 Hz timer. That is telling the simulation
            // the ANSWER instead of the CAUSE, and the two then disagree
            // — which is exactly what read as janky and rigid. Gone.
            // What is injected now is only what a body actually does:
            // it pushes water down where it stands, that volume has to
            // go somewhere, and it piles into a bead around the contact.
            // 0.40, was 0.62 — a tighter body. At 0.62 the displacement
            // ring was wide enough to read as its own circle sitting in
            // front of the wake rather than as the start of it.
            float bodyR = 0.40;
            float dC    = length(rel);
            float dip   = exp(-(dC * dC) / (bodyR * bodyR));
            float bead  = exp(-pow((dC - bodyR * 1.35) / (bodyR * 0.55), 2.0));

            // ...and the bead is opened out ASTERN into the wake's wedge
            // so the two are one shape. Water shoved aside at the bow has
            // to go somewhere, and where it goes is along the cusp lines
            // — so the ring is pulled backwards into them instead of
            // closing behind the body as a separate circle. `sPush` is
            // distance astern, `qPush` lateral, both from the CURRENT
            // heading, which is right this close to the hull.
            float sPush = dot(rel, -fwd);
            float qPush = dot(rel, vec2(-fwd.y, fwd.x));
            float armPush = exp(-pow((abs(qPush) - max(sPush, 0.0) * 0.35355)
                                     / (bodyR * 0.85), 2.0))
                          * smoothstep(0.0, 0.5, sPush)
                          * exp(-max(sPush, 0.0) * 0.55);
            bead = max(bead, armPush * 0.85);
            // The leading face does more work than the trailing one, so
            // the bead is fuller ahead — a displacement asymmetry, not a
            // drawn-on bow wave.
            float lead  = 0.5 + 0.5 * dot(normalize(rel + vec2(1e-4)), fwd);
            // Energy handed to the surface scales with how fast you move.
            float drive = smoothstep(0.15, 1.4, hspeed);
            // The dive splash self-zeroes out of water (it carries an
            // explicit `* inWater`), but the push does not - it keys off
            // speed alone. With the gate above now opening on land, that
            // would let running along the bank stamp a bow wave into the
            // lake beside you. Generation stays in the water.
            drive *= smoothstep(0.02, 0.20, inWater);
#if WATER_WAKE_KELVIN == 1
            // Both systems describe the same event, and left alone they
            // fight: the sim turns this impulse into a NON-dispersive
            // Mach cone at asin(c/v) — 33 deg at swim speed — while the
            // Kelvin pattern below is dispersive and fixed at 19.47 deg.
            // Two overlapping Vs at different angles, one stamping over
            // the other every frame. With Kelvin handling the far field,
            // the push keeps only its near-field job: the contact
            // disturbance itself. Its energy is cut so the cone it sheds
            // sits under the Kelvin pattern instead of arguing with it.
            drive *= 0.55;
            // AND SOFTER STILL WHEN SWIMMING. This is the term that
            // actually injects into the wave sim, so it is what was
            // shoving the surface around and setting the water jittering
            // near a swimmer. A boat hull displaces real volume and keeps
            // its full strength; a swimmer now disturbs less than half as
            // much water, which is much closer to the truth anyway.
            drive *= mix(0.42, 1.0, smoothstep(3.0, 6.5, hspeed));
#endif
            h += A * inj * drive * (0.26 * bead * mix(0.65, 1.35, lead)
                                  - 0.15 * dip);

            // ---- CAPILLARY RIPPLES ---------------------------------
            // Restored by surface TENSION rather than gravity: tight,
            // fast, and dead within a body length. They are stamped
            // analytically instead of injected, for two reasons. Their
            // true scale (under ~2 cm) is far below this field's 0.125
            // block texels, and capillary dispersion runs BACKWARDS —
            // shorter waves travel faster — which a sim with one fixed
            // wave speed cannot reproduce at any resolution.
            float cap = sin(6.2831853 * dC / 0.38 - frameTimeCounter * 9.0)
                      * exp(-dC / 0.45) * drive;
            h += A * inj * 0.055 * cap;
#endif

#if WATER_WAKE_KELVIN == 1
            // ---- KELVIN WAKE, EVALUATED AGAINST THE PATH ------------
            // Everything is measured from the nearest remembered
            // POSITION rather than from where the boat is now. That one
            // change is what makes it a wake instead of a decal:
            //
            //  * it EMITS — a stretch of water only carries wake once a
            //    path sample exists near it, so the trail extends as you
            //    travel instead of appearing whole,
            //  * it CURVES — each sample carries the heading it was laid
            //    down with, so turning bends the trail behind you and
            //    leaves the old part where it was,
            //  * it FADES — distance along the path is age, and each
            //    sample's own life decays, so the far end loses strength
            //    and finally goes.
            //
            // The sim is no longer asked to carry any of this. It could
            // not: ~1% of the structure survived 3 seconds of scrolling.
            // The path is walked as a POLYLINE, not as a set of points.
            //
            // Picking the nearest stored SAMPLE made `s` piecewise
            // constant: as the boat advanced, a given patch of water
            // suddenly switched from sample i to i+1 and its distance-
            // along-path jumped by a whole spacing, taking the wave phase
            // with it. Every texel crossing a sample boundary flicked.
            // That is the jitter, and it was in the search rather than in
            // the wave maths.
            //
            // Projecting onto the SEGMENTS instead gives a continuous
            // distance and a continuous lateral offset. Two more things
            // matter for smoothness: the walk starts at where the body is
            // RIGHT NOW rather than at the newest stored sample (which
            // lags by up to one spacing between pushes, and that lag
            // sawtoothed), and it accumulates TRUE arc length rather than
            // counting samples, so an unevenly spaced path stays smooth.
            vec2 texCam = (tc - 0.5) * 2.0 * WAKE_HALF;
            // kelvGrad is declared at function scope; filled in below.
            // NO CURRENT-SPEED GATE. This used to read
            //     if (prev.b > 0.5 && hspeed > 0.4)
            // which tests how fast you are moving RIGHT NOW and, on
            // failing, deleted the entire 36-block trail in one frame.
            // A wake is not something you are doing; it is something the
            // water is still doing because of what you did. So the only
            // condition left is that there is water here.
            if (prev.b > 0.5) {
                float bestD2 = 1e9, bestS = 0.0, bestQ = 0.0;
                float bestAge = 0.0, bestSpd = 0.0;
                bool  found  = false;
                vec2  bestDir = vec2(1.0, 0.0);   // segment dir, points BACKWARD
                // HEAD OF THE POLYLINE. While moving it is the body
                // itself at age zero, so the apex stays pinned under you.
                // As you slow it slides back onto the newest stored
                // sample and inherits ITS age - otherwise a stopped
                // swimmer would sit on one eternally-fresh point of wake
                // while the rest of the trail aged away behind them.
                vec4 p0 = texelFetch(colortex14, ivec2(0, 0), 0);
                float headB  = (p0.z > 1e-3) ? 1.0 - smoothstep(0.0, 1.2, hspeed) : 0.0;
                vec2  prevP  = mix(bodyOff, p0.xy, headB);
                float prevAge = mix(0.0, p0.w, headB);
                float prevSpd = (p0.z > 1e-3) ? p0.z : hspeed;
                float arc    = 0.0;
                for (int i = 0; i < PATH_LEN; i++) {
                    vec4 pt = texelFetch(colortex14, ivec2(i, 0), 0);
                    if (pt.z < 1e-3) break;              // unfilled slot
                    if (pt.w > 14.0) break;              // long dead
                    vec2  seg  = pt.xy - prevP;
                    float segL = length(seg);
                    // ---- THE BEAM ---------------------------------
                    // Samples are pushed every PATH_SPACING blocks, so a
                    // genuine segment is never much longer than that.
                    // A HUGE one means the two ends came from different
                    // swims: you left one pond, walked off, and waded
                    // into another, and sample 0 is under you now while
                    // sample 1 is still sitting in the water you left.
                    // The polyline joined them into one enormous straight
                    // segment and the wedge got drawn all the way down
                    // it - a long beam of disturbed water arriving the
                    // instant you touch the surface and reacting to
                    // nothing, because nothing ever swam along it.
                    //
                    // Ending the track here is right rather than merely
                    // safe: everything past this break belongs to an
                    // older excursion somewhere else.
                    if (segL > PATH_SPACING * 4.0) break;
                    if (segL > 1e-4) {
                        vec2  dir = seg / segL;          // points BACKWARD along the path
                        // ---- THE SECOND BEAM --------------------------
                        // The over-long-segment break above catches a
                        // trail JOINED across two swims. It cannot catch
                        // this one, which needs no bad data at all.
                        //
                        // Past either END of the polyline every texel
                        // projects onto the same endpoint, so bestS - the
                        // arc length - PINS at a constant while bestQ
                        // still varies sideways. The wake pattern is a
                        // function of exactly those two, so past the end
                        // it stops depending on how far out you are and
                        // becomes translation-invariant along the path:
                        // dead straight, unchanging, running to the
                        // horizon. That is the beam, and it is emitted by
                        // a perfectly healthy trail.
                        //
                        // Simulated it: a straight 16-block path put a
                        // solid slab across every texel beyond its end,
                        // and rejecting off-segment projections removed
                        // ~1050 of them while costing at most 6 texels of
                        // real wake, all of them at the head where there
                        // is no wake yet anyway.
                        //
                        // The tolerance bridges corners - a texel outside
                        // a bend can miss both segments - and 0.45 against
                        // 0.75 spacing leaves neighbouring segments
                        // overlapping, so a curved wake stays solid.
                        float tRaw = dot(texCam - prevP, dir);
                        if (tRaw > -0.45 && tRaw < segL + 0.45) {
                        float t   = clamp(tRaw, 0.0, segL);
                        vec2  cp  = prevP + dir * t;
                        vec2  d   = texCam - cp;
                        float d2  = dot(d, d);
                        if (d2 < bestD2) {
                            bestD2   = d2;
                            bestS    = arc + t;                       // true arc length
                            bestQ    = dot(d, vec2(-dir.y, dir.x));   // signed lateral
                            bestDir  = dir;
                            // Emission state, interpolated along the
                            // segment so nothing steps between samples.
                            bestAge  = mix(prevAge, pt.w, t / segL);
                            bestSpd  = mix(prevSpd, pt.z, t / segL);
                            found    = true;
                        }
                        }   // end off-segment rejection
                        // arc advances whether or not this segment was
                        // usable, or every rejection would shorten the
                        // measured path and shift the whole pattern.
                        arc += segL;
                    }
                    prevP = pt.xy;
                    prevAge = pt.w;
                    prevSpd = pt.z;
                }

                float sK = max(bestS, 0.0);
                float q2 = bestQ;
                const float TANK = 0.35355;              // tan(19.47 deg)
                float edge = abs(q2) / max(sK * TANK, 1e-3);

                if (found && edge < 1.65) {
                    // EVERYTHING below keys off the state at EMISSION -
                    // bestSpd and bestAge - and never off speed/hspeed.
                    // Using the current speed meant a single global
                    // multiplier scaled the whole trail at once, so every
                    // wobble of the throttle pulsed all 36 blocks of wake
                    // together. That is the "it goes out and in" flicker,
                    // and it is why the far end lit up at the same instant
                    // as the near end: they were never independent.
                    float boaty = smoothstep(3.0, 6.5, bestSpd);
                    // Wake wavelength is set by the speed that MADE it,
                    // and it LENGTHENS with age: viscous damping goes as
                    // k^2, so the short steep ripples die first and the
                    // long swell outlives them. An old wake is not just a
                    // fainter wake, it is a smoother, longer one.
                    float lam0 = clamp(0.30 * bestSpd * bestSpd, 1.8, 13.0)
                               * (1.0 + bestAge * 0.16);
                    float Kw   = 6.2831853 / lam0;

                    // ---- ANALYTIC GRADIENT, NOT A HEIGHT --------
                    // The wake is no longer written into the wave field.
                    // Doing that meant the simulation immediately began
                    // propagating it at 1.2 m/s, damping it, smoothing it
                    // and resampling it as the field scrolled — and then
                    // the next frame re-pinned it. Whatever the pin did
                    // not cover drifted and beat against what it did.
                    // That fight is the jitter, and it cannot be tuned
                    // out: the pattern is world-anchored and the sim
                    // insists on moving it.
                    //
                    // It is now evaluated fresh every frame and parked in
                    // the unused rows of the path buffer, which nothing
                    // propagates. The SLOPE is accumulated directly
                    // (each term differentiates to a sine) rather than a
                    // height, so composite1 gets an exact normal instead
                    // of differencing a stored field.
                    float eta = 0.0, wsum = 0.0;
                    float dS = 0.0, dQ = 0.0;
                    float sgnQ = q2 < 0.0 ? -1.0 : 1.0;
                    for (int i = 0; i < 24; i++) {
                        float th = (float(i) + 0.5) / 24.0 * 1.3614;   // 0..78 deg
                        float ct = cos(th), st = sin(th);
                        float amp = exp(-pow((th - 0.6154) / 0.3840, 2.0)); // peak 35.26 deg
                        float kk  = Kw / (ct * ct);
                        float phi = kk * (abs(q2) * st - sK * ct);
                        eta  += amp * cos(phi);
                        float sp = amp * sin(phi) * kk;
                        dS   += sp * ct;                 // d/ds
                        dQ   -= sp * st * sgnQ;          // d/dq
                        wsum += amp;
                    }
                    float iw = 1.0 / max(wsum, 1e-4);
                    eta *= iw; dS *= iw; dQ *= iw;

                    float wedge   = 1.0 - smoothstep(1.00, mix(1.30, 1.16, boaty), edge);
                    // The CUSP LINE - the bright crease riding the 19.47
                    // deg boundary - is the feature the eye actually reads
                    // as "a wake spreading outward". It was weaker than
                    // the wedge fill it sits on, so the shape came across
                    // as a soft band rather than as two arms. Raised, and
                    // widened slightly, so the arms draw the eye.
                    float caustic = exp(-pow((edge - 1.0) / mix(0.17, 0.12, boaty), 2.0)) * 1.35;
                    float envK    = wedge * 0.38 + caustic;

                    // ---- HOW A WAKE APPEARS, AND HOW IT DIES ------
                    // Appears: the water needs a moment to organise after
                    // the hull passes, so a freshly-laid stretch of track
                    // ramps in over ~0.3 s rather than switching on. And
                    // because age is stored PER SAMPLE, the wedge grows
                    // backwards from the point where you started moving,
                    // instead of the whole V existing from frame one.
                    //
                    // Dies: stopping ends the EMISSION, not the waves.
                    // What has already been radiated keeps travelling and
                    // fades over several seconds - a real ship wake
                    // outlives the ship by minutes. So the trail is now
                    // left behind in the water and decays in place,
                    // oldest (farthest) first, instead of being deleted
                    // the instant you let go of the stick.
                    float rise  = smoothstep(0.0, 0.30, bestAge);
                    float decay = exp(-bestAge / 6.5);
                    // Geometric spreading along the arms, plus a soft end
                    // to the trail - the old hard sK < 34 cut left a
                    // straight edge ruled across the water.
                    // ---- LETTING THE V ACTUALLY READ AS A V --------
                    // The wedge geometry was always correct - tan(19.47
                    // deg) is right there in TANK - but three separate
                    // distance falloffs stacked on top of it: this
                    // spreading term, the age decay, and the end fade.
                    // A Kelvin wedge is WIDEST where it is OLDEST, so
                    // everything that dims with distance dims exactly the
                    // part that carries the spread. What survived was the
                    // narrow section near the hull, which is why it read
                    // as a straight line with only a hint of splay.
                    //
                    // 0.10 (was 0.22) and a fade pushed from 26-38 out to
                    // 40-56 blocks. Geometric spreading is real, so it is
                    // loosened rather than removed - the arms just have to
                    // outlive the point where they have separated enough
                    // to be seen as arms.
                    float spread = inversesqrt(1.0 + sK * 0.10)
                                 * (1.0 - smoothstep(40.0, 56.0, sK));
                    // The body has to have been MOVING to emit anything.
                    float emit = smoothstep(0.45, 2.2, bestSpd);
                    // Swimming is far gentler than a boat: a swimmer
                    // displaces a small fraction of the water a hull does,
                    // and at the old 0.45 floor the swim wake was strong
                    // enough to shove the surface around and set the whole
                    // area jittering.
                    // 0.72 restores the boat amplitude measured off the
                    // build William approved (0.214 at 6 blocks in the
                    // established cruise) after the new spreading and age
                    // terms were folded in. The 0.12 swim end is the
                    // deliberate part: a swimmer moves a fraction of the
                    // water a hull does, and the wake is now 45% of what
                    // it was at swim speed and unchanged at boat speed.
                    float ampK = 0.72 * WATER_WAKE_STRENGTH * mix(0.12, 1.00, boaty)
                               * emit * envK * rise * decay * spread
                               * clamp(sK / 1.5, 0.0, 1.0);
                    // `* inWater` REMOVED, and it was the whole bug.
                    //
                    // inWater asks whether the PLAYER is in water right
                    // now. Jump - which lifts you clear of the surface for
                    // a moment, as vanilla does - and it drops to zero, so
                    // the entire trail vanished mid-frame and snapped back
                    // when you landed. Leave the water and the whole wake
                    // blinked out at the shoreline; wade back in and it
                    // returned complete.
                    //
                    // A wake is water that is still moving because of what
                    // you did. Whether you happen to be standing in it now
                    // has nothing to do with whether it exists. Age and
                    // emission speed already govern that, and this term
                    // was overriding both.

                    // slope in the path's local frame -> world XZ
                    vec2 fwdPath = -bestDir;             // direction of travel
                    vec2 perpPath = vec2(-fwdPath.y, fwdPath.x);
                    kelvGrad = (dS * ampK) * (-fwdPath) + (dQ * ampK) * perpPath;
                }
            }
#endif
        }
#endif
    }


    // NOTE: rain ripples are NO LONGER injected into this coarse sim
    // (that read as a blobby indent). They're now crisp per-fragment
    // procedural rings — lmn_rainRippleSlope in lib/wave.glsl — applied
    // to the water AND wet-land normals. This field handles only the
    // splash/wake now.

// CAMERA CHANGES MUST BE SILENT. Whether a probe hits a mob depends on the viewing position (the hull
// hides its own far side, silhouettes shift, probes land on other pixels), so turning, walking, flying
// up/down, jumping or switching between first and third person changed the measured coverage and that read
// as the mob moving. While the view is changing - and for ~0.4 s after, while the screen buffers settle -
// the stored coverage still follows the measurement but is not allowed to push the water. The countdown
// lives in colortex14 texel (WAKE_RES-2, 0).
    float quietTimer = 0.0;
    {
        vec3 fwdNowV  = -normalize(vec3(gbufferModelView[0][2], gbufferModelView[1][2], gbufferModelView[2][2]));
        vec3 fwdPrevV = -normalize(vec3(gbufferPreviousModelView[0][2], gbufferPreviousModelView[1][2], gbufferPreviousModelView[2][2]));
        float viewChange = length(fwdNowV - fwdPrevV) + 0.3 * length(camMove);
        float prevQuiet = texelFetch(colortex14, ivec2(int(WAKE_RES) - 2, 0), 0).r;
        quietTimer = viewChange > 0.0015 ? 1.0 : max(prevQuiet - dt / 0.4, 0.0);
    }
    float coverQuiet = 1.0 - smoothstep(0.0, 0.25, quietTimer);

#if WATER_WAKE_MOBS == 1 || WATER_WAKE_ITEMS == 1
    {
        // Last frame's coverage lives in colortex14.ba (free outside the path row). Something moving
        // through water presses the surface down at its leading edge and lets it rise behind it:
        // inject the CHANGE in coverage, so standing mobs are calm and moving ones leave a wake.
        //
        // STANDING STILL MUST BE SILENT. The coverage is read back from the TAA-jittered screen, so the
        // outline of a stationary boat, mob or floating item shimmers by a probe or two every single
        // frame. Injecting that raw frame-to-frame change stamped a push into the water every frame,
        // and the boat sat in an endless stream of rings. The stored value is now a BACKLASH ("play")
        // filter of the measured coverage: it only moves once the measurement has left a +/-BAND window
        // around it, so shimmer inside the window changes nothing and injects nothing, while a mob that
        // really enters, leaves or travels pushes the value (and so the water) exactly as before. Only
        // the part of a swing outside the window passes through, so the push is divided by (1 - BAND)
        // to keep real wakes at their old strength.
        const float COVER_BAND = 0.5;
        vec2 prevMI = (prevUv.y > 3.0 / WAKE_RES) ? texture(colortex14, prevUv).ba : vec2(0.0);
        // Off screen (or not looked at) means "unknown", not "gone": looking away from a boat must not
        // read as the boat leaving and then returning, which would push the water twice.
        vec2 rawMI  = coverObserved ? vec2(mobCover, itemCover) : prevMI;
        vec2 newMI  = clamp(prevMI, rawMI - COVER_BAND, rawMI + COVER_BAND);
        mobCover  = newMI.x;
        itemCover = newMI.y;
        const float coverGain = 1.0 / (1.0 - COVER_BAND);
        h -= 0.9 * coverGain * coverQuiet * (mobCover - prevMI.x) * WATER_WAKE_STRENGTH;
        // Dropped items: smaller footprint, so a stronger push per texel. One landing in water makes a
        // small splash; one resting on the surface now stays calm instead of ringing forever.
        h -= 1.4 * coverGain * coverQuiet * (itemCover - prevMI.y) * WATER_WAKE_STRENGTH;
    }
#endif

    // Waves need water under them — absorb where the splat says land,
    // so arcs reaching a shore or wall die there instead of passing
    // through. dt-scaled. smoothstep: ANY water (0.55+) fully escapes
    // absorption — the sky-exposure encoding must not make roofed
    // pools eat their own waves.
    h *= pow(mix(0.85, 1.0, smoothstep(0.25, 0.55, prev.b)), dt * 60.0);
    h = clamp(h, -0.9, 0.9);

    // colortex14: path history in row 0, the Kelvin slope everywhere else.
    // colortex15: the field itself.
    vec4 out0 = isPathPx ? pathOut : vec4(kelvGrad, mobCover, itemCover);
#ifndef IS_IRIS
    if (ivec2(gl_FragCoord.xy) == ivec2(int(WAKE_RES) - 1, 0))
        out0 = vec4(memBack, memBack > 0.0 ? 1.0 : 0.0, 0.0, 0.0);
#endif
    if (ivec2(gl_FragCoord.xy) == ivec2(int(WAKE_RES) - 3, 0))
        out0 = vec4(wakeViewNow, wakeConfNow);
    if (ivec2(gl_FragCoord.xy) == ivec2(int(WAKE_RES) - 2, 0))
        out0 = vec4(quietTimer, 0.0, 0.0, 0.0);
#if FOOTPRINTS == 1
    if (isFootPx) out0 = footOut;
#endif
    gl_FragData[0] = out0;
    gl_FragData[1] = vec4(h, prev.r, prev.b, prev.a);
#else
    gl_FragData[0] = vec4(0.0);
    gl_FragData[1] = vec4(0.0);
#endif
}

/* RENDERTARGETS: 14,15 */
