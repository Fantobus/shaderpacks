
/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

// See gbuffers_beaconbeam.vsh and BEACON_BEAM_TEXTURE_FIX in lib/Uniforms.inc
// for background on why this file exists.


in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec3 velocity;
in vec4 preDownscaleProjPos;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;


#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"
#include "/lib/Materials.inc"


void main()
{
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	float lodOffset = 0.0;

	vec4 albedo = texture2D(texture, texcoord.st, lodOffset);
	albedo *= color;

	vec2 mcLightmap = blockLight;

	#ifdef BEACON_BEAM_TEXTURE_FIX

	// Fixed path: the beam texture has no matching entry in the resource pack's
	// specular/normal PBR atlas, so we don't sample those maps at all here - we
	// just treat the beam as a flat, fully emissive surface. This is what actually
	// gets rid of the glitched/corrupted look, since that corruption came from
	// reading specular/normal data that never corresponded to the beam texture in
	// the first place.
	if (albedo.a < 0.99) {
		discard;
	}

	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	vec3 viewNormal = N;
	float smoothness = 0.0;
	float metallic = 0.0;
	float emissiveOut = 1.0;

	GBufferData gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = viewNormal.xyz;
	gbuffer.mcLightmap = mcLightmap;
	gbuffer.smoothness = smoothness;
	gbuffer.metalness = metallic;
	gbuffer.materialID = (MAT_ID_DYNAMIC_ENTITY + 0.1) / 255.0;
	gbuffer.emissive = emissiveOut;
	gbuffer.geoNormal = N.xyz;
	gbuffer.totalTexGrad = length(fwidth(texcoord.st)) * (256.0 / 8.0);


	vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	{
		// Beacon beams don't move on their own (velocity is always zero, see
		// gbuffers_beaconbeam.vsh), so this always takes the camera-reprojection
		// branch - same formula gbuffers_entities.fsh uses for its static case.
		vec4 projPosPrev;

		if (dot(velocity.xyz, velocity.xyz) > 1e-8) {
			vec3 viewPosPrev = viewPos.xyz - velocity.xyz;
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev, 1.0);
		} else {
			vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
			vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		}

		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		gbuffer.motion = (projPos.xyz - projPosPrev.xyz);
	}


	vec4 frag0, frag1, frag2, frag3;

	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	gl_FragData[3] = frag3;

	#else

	// Original path, restored verbatim from reforged's gbuffers_textured.fsh -
	// this is exactly what ran for beacon beams before this fix file existed,
	// since reforged had no gbuffers_beaconbeam and Iris/OptiFine fell back to
	// gbuffers_textured automatically. It samples the specular/normal PBR maps
	// with the beam's own texcoords, which don't correspond to real PBR data for
	// the beam texture - that mismatch is what caused the corrupted/glitched
	// look. Restoring this (rather than just a similar-looking approximation)
	// is what makes turning the fix off reproduce the original exactly.

	if (albedo.a < 0.2)
	{
		discard;
	}



	float wetnessModulator = 1.0;

	vec3 rainNormal = vec3(0.0, 0.0, 0.0);
	#ifdef RAIN_SPLASH_EFFECT
	rainNormal = GetRainSplashNormal(worldPosition, worldNormal, wetnessModulator);
	#endif

	wetnessModulator *= saturate(worldNormal.y * 10.5 + 0.7);
	wetnessModulator *= saturate(abs(2.0 - materialIDs));
	wetnessModulator *= clamp(blockLight.y * 1.05 - 0.7, 0.0, 0.3) / 0.3;
	wetnessModulator *= saturate(wetness * 1.1 - 0.1);



	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);




	vec4 specTex = texture2D(specular, texcoord.st, lodOffset);
		 #ifdef SPEC_SMOOTHNESS_AS_ROUGHNESS
	specTex.SPEC_CHANNEL_SMOOTHNESS = 1.0 - specTex.SPEC_CHANNEL_SMOOTHNESS;
	#endif
	specTex.SPEC_CHANNEL_SMOOTHNESS = specTex.SPEC_CHANNEL_SMOOTHNESS * 0.992; 								// Fix weird specular issue
	vec4 normalTex = texture2D(normals, texcoord.st, lodOffset) * 2.0 - 1.0;

	float normalMapStrength = NORMAL_MAP_STRENGTH;
	#ifdef FORCE_WET_EFFECT
	normalMapStrength = mix(NORMAL_MAP_STRENGTH, 0.1, wetnessModulator * wetnessModulator * wetnessModulator * wetnessModulator);
	#endif

	vec3 viewNormal = tbn * normalize(normalTex.xyz * vec3(normalMapStrength, normalMapStrength, 1.0) + rainNormal * wetnessModulator);


	// Get specular data from specular texture
	float smoothness = specTex.SPEC_CHANNEL_SMOOTHNESS;
	float metallic = specTex.SPEC_CHANNEL_METALNESS;
	float emissive = specTex.SPEC_CHANNEL_EMISSIVE; // note: GBufferDataTransparent has no emissive field, so this doesn't reach output

	#ifdef FORCE_WET_EFFECT
	smoothness = mix(smoothness, 1.0, saturate(wetnessModulator * 1.0 * saturate(1.0 - metallic)));
	#endif

	// Darker albedo when wet
	albedo.rgb = pow(albedo.rgb, vec3(1.0 + wetnessModulator * (1.0 - metallic) * 0.3));




	// Fix impossible normal angles
	vec3 viewDir = -normalize(viewPos.xyz);
	vec3 relfectDir = reflect(-viewDir, viewNormal);
	// make outright impossible
	viewNormal.xyz = normalize(viewNormal.xyz + (N / (pow(saturate(dot(viewNormal, viewDir)) + 0.001, 0.5)) * 1.0));




	GBufferDataTransparent gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = viewNormal.xyz;
	gbuffer.geoNormal = N.xyz;
	gbuffer.materialID = (111.0 + 0.1) / 255.0;
	gbuffer.smoothness = 0.0;
	gbuffer.mcLightmap = mcLightmap;

	vec4 frag1, frag2;
	OutputGBufferDataTransparent(gbuffer, frag1, frag2);

	gl_FragData[0] = frag1;
	gl_FragData[1] = frag2;

	#endif
}

#ifdef BEACON_BEAM_TEXTURE_FIX
/* RENDERTARGETS: 0,1,2,8 */
#else
/* DRAWBUFFERS:12 */
#endif
