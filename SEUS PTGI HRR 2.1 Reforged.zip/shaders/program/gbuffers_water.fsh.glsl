




in vec3 normal;
in vec3 globalNormal;
in vec3 tangent;
in vec3 binormal;
in vec3 viewVector;
in vec4 viewPos;
in vec3 worldNormal;
in vec4 preDownscaleProjPos;

in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec4 vertexPos;
in float distance;

in float isWater;
in float isIce;
in float isStainedGlass;
in float isSlime;
in float isPortal;

in vec2 blockLight;


#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"


#include "/lib/GBufferData.inc"
#include "/lib/PhysicsOcean.inc"
#include "/lib/WakeField.inc"
#include "/lib/CustomRain.inc"

#ifdef PHYSICS_OCEAN
	in vec3 physics_localPosition;
	in float physics_localWaviness;
#endif



vec4 cubic(float x)
{
    float x2 = x * x;
    float x3 = x2 * x;
    vec4 w;
    w.x =   -x3 + 3*x2 - 3*x + 1;
    w.y =  3*x3 - 6*x2       + 4;
    w.z = -3*x3 + 3*x2 + 3*x + 1;
    w.w =  x3;
    return w / 6.f;
}

vec4 BicubicTexture(in sampler2D tex, in vec2 coord)
{
	int resolution = 64;

	coord *= resolution;

	float fx = fract(coord.x);
    float fy = fract(coord.y);
    coord.x -= fx;
    coord.y -= fy;

    vec4 xcubic = cubic(fx);
    vec4 ycubic = cubic(fy);

    vec4 c = vec4(coord.x - 0.5, coord.x + 1.5, coord.y - 0.5, coord.y + 1.5);
    vec4 s = vec4(xcubic.x + xcubic.y, xcubic.z + xcubic.w, ycubic.x + ycubic.y, ycubic.z + ycubic.w);
    vec4 offset = c + vec4(xcubic.y, xcubic.w, ycubic.y, ycubic.w) / s;

    vec4 sample0 = texture2D(tex, vec2(offset.x, offset.z) / resolution);
    vec4 sample1 = texture2D(tex, vec2(offset.y, offset.z) / resolution);
    vec4 sample2 = texture2D(tex, vec2(offset.x, offset.w) / resolution);
    vec4 sample3 = texture2D(tex, vec2(offset.y, offset.w) / resolution);

    float sx = s.x / (s.x + s.y);
    float sy = s.z / (s.z + s.w);

    return mix( mix(sample3, sample2, sx), mix(sample1, sample0, sx), sy);
}

vec4 textureSmooth(in sampler2D tex, in vec2 coord)
{
	vec2 res = vec2(64.0f, 64.0f);

	coord *= res;
	coord += 0.5f;

	vec2 whole = floor(coord);
	vec2 part  = fract(coord);

	part.x = part.x * part.x * (3.0f - 2.0f * part.x);
	part.y = part.y * part.y * (3.0f - 2.0f * part.y);
	// part.x = 1.0f - (cos(part.x * 3.1415f) * 0.5f + 0.5f);
	// part.y = 1.0f - (cos(part.y * 3.1415f) * 0.5f + 0.5f);

	coord = whole + part;

	coord -= 0.5f;
	coord /= res;

	return texture2D(tex, coord);
}

float AlmostIdentity(in float x, in float m, in float n)
{
	if (x > m) return x;

	float a = 2.0f * n - m;
	float b = 2.0f * m - 3.0f * n;
	float t = x / m;

	return (a * t + b) * t * t + n;
}

// ------------------------------------------------------------------
// Water wave height, wave texture sampling and wave speed, ported
// from Photon (include/surface/water_normal.glsl: gerstner_wave(),
// water_waves_setup() and get_water_height()). The layered-noise
// FBM height function below replaces the old hand-tuned noise stack
// but keeps the same GetWaves(position, scale) signature so
// GetWavesNormal() and GetWaterParallaxCoord() don't need to change.
// ------------------------------------------------------------------

// Photon's gerstner_wave(): a single sine-based Gerstner wave, offset
// by a noise value so it doesn't look perfectly regular.
float PhotonGerstnerWave(vec2 coord, vec2 waveDir, float t, float noise, float wavelength)
{
	const float g = 9.8f;

	float k = (2.0f * 3.14159265f) / wavelength; // tau / wavelength
	float w = sqrt(g * k);

	float x = w * t - k * (dot(waveDir, coord) + noise);

	float s = sin(x) * 0.5f + 0.5f;
	return s * s;
}

#if CLOUD_MODE >= 3
// Photon water waves. Active when the Profile (Cloud Mode) is Photon or Bliss.
float GetWaves(vec3 position, in float scale) {
	// --- Wave speed ---
	// Photon splits still/flowing water speed; SEUS's water gbuffer has
	// no flow direction available here, so PHOTON_WATER_SPEED plays the
	// role of Photon's PHOTON_WATER_SPEED_STILL, still respecting isIce.
	float speed = 0.5f * PHOTON_WATER_SPEED;
	speed = mix(speed, 0.0f, isIce);

	float t = speed * WATER_TIME;

	const float waveAngle = 30.0f * 0.0174532925f; // 30 degrees, in radians
	vec2 waveDir = vec2(cos(waveAngle), sin(waveAngle));

	// Golden-angle rotation applied to the wave direction each octave,
	// so the layered waves don't all point the
	// same way and end up looking axis-aligned/repetitive.
	const float goldenAngle = 2.39996323f; // radians
	mat2 waveRot = mat2(cos(goldenAngle), sin(goldenAngle), -sin(goldenAngle), cos(goldenAngle));

	vec2 coord = position.xz * scale;

	// --- Wave height FBM parameters ---
	const float waveFrequency = 0.7f * PHOTON_WATER_FREQUENCY;
	const float persistence   = 0.5f;
	const float lacunarity    = 1.7f;

	// --- Wave texture: the noisetex lookups that perturb each wave layer ---
	const float noiseFrequency = 0.007f;
	const float noiseStrength  = 2.0f;

#ifdef PHOTON_WATER_HEIGHT_VARIATION
	const float heightVariationFrequency   = 0.001f;
	const float minHeight                  = 0.4f;
	const float heightVariationScale       = 2.0f;
	const float heightVariationOffset      = -0.5f;
	const float heightVariationScrollSpeed = 0.1f;

	float heightVariationNoise = textureSmooth(noisetex, (coord + vec2(0.0f, heightVariationScrollSpeed * t)) * heightVariationFrequency).x;
#endif

	// Reciprocal of the sum of amplitudes of all octaves (geometric series
	// with initial value 1 and common ratio `persistence`), so the result
	// stays normalized regardless of PHOTON_WATER_ITERATIONS.
	float amplitudeNorm = (1.0f - persistence) / (1.0f - pow(persistence, float(PHOTON_WATER_ITERATIONS)));

	vec2 noiseCoord = (coord + vec2(0.0f, 0.25f * t)) * noiseFrequency;

	float height = 0.0f;
	float waveLength = 1.0f;
	float amplitude = 1.0f;
	float frequency = waveFrequency;

	for (int i = 0; i < PHOTON_WATER_ITERATIONS; ++i) {
		float waveNoise = textureSmooth(noisetex, noiseCoord).x * noiseStrength;

		height += PhotonGerstnerWave(coord * frequency, waveDir, t, waveNoise, waveLength) * amplitude;

		amplitude  *= persistence;
		frequency  *= lacunarity;
		waveLength *= 1.5f;

		waveDir    *= waveRot;
		noiseCoord *= 2.5f;
	}

#ifdef PHOTON_WATER_HEIGHT_VARIATION
	height *= max(minHeight, heightVariationNoise * heightVariationScale + heightVariationOffset);
#endif

	height *= amplitudeNorm;

	// Keep SEUS's existing distance-based anti-aliasing/fade term.
	height /= 1.0 + dot(fwidth(position), vec3(10.0));

	return height;
}

#else
// Original SEUS PTGI HRR 2.1 Reforged water waves.
float GetWaves(vec3 position, in float scale) {
  float speed = 0.9f;

  speed = mix(speed, 0.0f, isIce);

  vec2 p = position.xz / 5.0f;


  p.xy -= position.y / 10.0f;

  p.x = -p.x;

  p.x += (WATER_TIME / 40.0f) * speed;
  p.y -= (WATER_TIME / 40.0f) * speed;

  float weight = 1.0f;
  float weights = weight;

  float allwaves = 0.0f;

  float wave = textureSmooth(noisetex, (p * vec2(2.0f, 1.2f))  + vec2(0.0f,  p.x * 2.1f) ).x; 			p /= 2.1f; 	/*p *= pow(2.0f, 1.0f);*/ 	p.y -= (WATER_TIME / 20.0f) * speed; p.x -= (WATER_TIME / 30.0f) * speed;
  allwaves += wave * 0.5;

  weight = 2.1f;
  weights += weight;
      wave = textureSmooth(noisetex, (p * vec2(2.0f, 1.4f))  + vec2(0.0f,  -p.x * 2.1f) ).x;	p /= 1.5f;/*p *= pow(2.0f, 2.0f);*/ 	p.x += (WATER_TIME / 20.0f) * speed;
      wave *= weight;
  allwaves += wave;

  weight = 17.25f;
  weights += weight;
      wave = (textureSmooth(noisetex, (p * vec2(1.0f, 0.75f))  + vec2(0.0f,  p.x * 1.1f) ).x);		p /= 1.5f; 	p.x -= (WATER_TIME / 55.0f) * speed;
      wave *= weight;
  allwaves += wave;

  weight = 15.25f;
  weights += weight;
      wave = (textureSmooth(noisetex, (p * vec2(1.0f, 0.75f))  + vec2(0.0f,  -p.x * 1.7f) ).x);		p /= 1.9f; 	p.x += (WATER_TIME / 155.0f) * speed;
      wave *= weight;
  allwaves += wave;

  weight = 29.25f;
  weights += weight;
      wave = abs(textureSmooth(noisetex, (p * vec2(1.0f, 0.8f))  + vec2(0.0f,  -p.x * 1.7f) ).x * 2.0f - 1.0f);		p /= 2.0f; 	p.x += (WATER_TIME / 155.0f) * speed;
      wave = 1.0f - AlmostIdentity(wave, 0.2f, 0.1f);
      wave *= weight;
  allwaves += wave;

  weight = 15.25f;
  weights += weight;
      wave = abs(textureSmooth(noisetex, (p * vec2(1.0f, 0.8f))  + vec2(0.0f,  p.x * 1.7f) ).x * 2.0f - 1.0f);
      wave = 1.0f - AlmostIdentity(wave, 0.2f, 0.1f);
      wave *= weight;
  allwaves += wave;

  // allwaves += pow(textureSmooth(noisetex, position.xz * 0.1).x, 19.0) * 150.1;

  allwaves /= weights;


  allwaves /= 1.0 + dot(fwidth(position), vec3(10.0));

  return allwaves;
}

#endif

vec3 GetWaterParallaxCoord(in vec3 position, in vec3 viewVector)
{
	vec3 parallaxCoord = position.xyz;

	#if CLOUD_MODE >= 3
	vec3 stepSize = vec3(0.6f * PHOTON_WATER_HEIGHT, 0.6f * PHOTON_WATER_HEIGHT, 1.0f) * 0.5;
#else
	vec3 stepSize = vec3(0.6f * WATER_WAVE_HEIGHT, 0.6f * WATER_WAVE_HEIGHT, 1.0f) * 0.5;
#endif

	float waveHeight = GetWaves(position, 1.0f);

		vec3 pCoord = vec3(0.0f, 0.0f, 1.0f);

		vec3 step = viewVector * stepSize;
		float distAngleWeight = ((distance * 0.2f) * (2.1f - viewVector.z)) / 2.0f;
		distAngleWeight = 1.0f;
		step *= distAngleWeight;

		float sampleHeight = waveHeight;

		for (int i = 0; sampleHeight < pCoord.z && i < 60; ++i)
		{
			pCoord.xy = mix(pCoord.xy, pCoord.xy + step.xy, clamp((pCoord.z - sampleHeight) / (stepSize.z * 0.2f * distAngleWeight / (-viewVector.z + 0.05f)), 0.0f, 1.0f));
			pCoord.z += step.z;
			//pCoord += step;
			sampleHeight = GetWaves(position + vec3(pCoord.x, 0.0f, pCoord.y), 1.0f);
		}

	parallaxCoord = position.xyz + vec3(pCoord.x, 0.0f, pCoord.y);

	return parallaxCoord;
}

vec3 GetWavesNormal(vec3 position, in float scale, in mat3 tbnMatrix) {

	vec4 modelView = (gl_ModelViewMatrix * vertexPos);

	vec3 viewVector = normalize(tbnMatrix * modelView.xyz);

		 viewVector = normalize(viewVector);


	#ifdef WATER_PARALLAX
	position = GetWaterParallaxCoord(position, viewVector);
	#endif


	const float sampleDistance = 4.0f;

	position -= vec3(0.005f, 0.0f, 0.005f) * sampleDistance;

	float wavesCenter = GetWaves(position, scale);
	float wavesLeft = GetWaves(position + vec3(0.01f * sampleDistance, 0.0f, 0.0f), scale);
	float wavesUp   = GetWaves(position + vec3(0.0f, 0.0f, 0.01f * sampleDistance), scale);

	vec3 wavesNormal;
		 wavesNormal.r = wavesCenter - wavesLeft;
		 wavesNormal.g = wavesCenter - wavesUp;

#if CLOUD_MODE >= 3


		 wavesNormal.r *= 20.0f * PHOTON_WATER_HEIGHT / sampleDistance;


		 wavesNormal.g *= 20.0f * PHOTON_WATER_HEIGHT / sampleDistance;
#else


		 wavesNormal.r *= 20.0f * WATER_WAVE_HEIGHT / sampleDistance;


		 wavesNormal.g *= 20.0f * WATER_WAVE_HEIGHT / sampleDistance;
#endif


	//wavesNormal.rg *= saturate(1.0 - length(position.xyz - cameraPosition.xyz) / 20.0);


		//  wavesNormal.b = sqrt(1.0f - wavesNormal.r * wavesNormal.r - wavesNormal.g * wavesNormal.g);
     wavesNormal.b = 1.0;
		 wavesNormal.rgb = normalize(wavesNormal.rgb);


		 //float upAmount = dot(fwidth(position.xyz), vec3(1.0));
		 //float upAmount = 1.0 - saturate(dot(-viewVector, wavesNormal));
		 //upAmount = upAmount / (upAmount + 1.0);

		 //wavesNormal = normalize(wavesNormal + vec3(0.0, -1.0, 0.0) * upAmount * 1.0);



	return wavesNormal.rgb;
}




vec3 GetRainAnimationTex(sampler2D tex, vec2 uv, float wet)
{
	//float frame = mod(floor(float(frameCounter) * 1.0), 60.0);
	// frame = 0.0;

	float frame = mod(floor(RAIN_TIME * 60.0), 60.0);
	vec2 coord = vec2(uv.x, mod(uv.y / 60.0, 1.0) - frame / 60.0);

	vec3 n = texture2D(tex, coord).rgb * 2.0 - 1.0;
	n.y *= -1.0;

	n.xy = pow(abs(n.xy) * 1.0, vec2(2.0 - wet * wet * wet * 1.2)) * sign(n.xy);
	// n.xy = pow(abs(n.xy) * 1.0, vec2(1.0)) * sign(n.xy);

	return n;
}

vec3 BilateralRainTex(sampler2D tex, vec2 uv, float wet)
{
	vec3 n = GetRainAnimationTex(tex, uv.xy, wet);
	vec3 nR = GetRainAnimationTex(tex, uv.xy + vec2(1.0, 0.0) / 128.0, wet);
	vec3 nU = GetRainAnimationTex(tex, uv.xy + vec2(0.0, 1.0) / 128.0, wet);
	vec3 nUR = GetRainAnimationTex(tex, uv.xy + vec2(1.0, 1.0) / 128.0, wet);

	vec2 fractCoord = fract(uv.xy * 128.0);

	vec3 lerpX = mix(n, nR, fractCoord.x);
	vec3 lerpX2 = mix(nU, nUR, fractCoord.x);
	vec3 lerpY = mix(lerpX, lerpX2, fractCoord.y);

	return lerpY;
}

vec3 GetRainNormal(in vec3 pos, float wet)
{
	if (rainStrength < 0.01)
	{
		return vec3(0.0, 0.0, 1.0);
	}


	pos.xyz *= 0.5;


	#ifdef RAIN_SPLASH_BILATERAL
	vec3 n1 = BilateralRainTex(gaux2, pos.xz, wet);
	// vec3 n2 = BilateralRainTex(gaux2, pos.xz, wet);
	// vec3 n3 = BilateralRainTex(colortex6, pos.xz, wet);
	#else
	vec3 n1 = GetRainAnimationTex(gaux2, pos.xz, wet);
	// vec3 n2 = GetRainAnimationTex(gaux2, pos.xz, wet);
	// vec3 n3 = GetRainAnimationTex(colortex6, pos.xz, wet);
	#endif

	pos.x -= RAIN_TIME * 1.5;
	float downfall = texture2D(noisetex, pos.xz * 0.0025).x;
	downfall = saturate(downfall * 1.5 - 0.25);


	vec3 n = n1 * 2.0;
	// n += n2 * saturate(downfall * 2.0) * 2.0;
	// n += n3 * saturate(downfall * 2.0 - 1.0) * 2.0;
	// n = n3 * 3.0;

	n *= 0.2;

	float lod = dot(abs(fwidth(pos.xyz)), vec3(20.0));
	n.xy *= 1.0 / (1.0 + lod);

	n.xy /= wet + 0.1;
	// n.x = downfall;

	wet = saturate(wet * 1.0 + downfall * (1.0 - wet) * 0.5);
	// wet = downfall * 0.2 + 0.8;

	n.xy *= rainStrength;

	vec3 rainFlowNormal = vec3(0.0, 0.0, 1.0);
	// rainFlowNormal.xy = vec2(Get3DNoise(flowPos.xyz) * 2.0 - 1.0, Get3DNoise(flowPos.xyz + 2.0) * 2.0 - 1.0) * 0.05;
	// flowPos.xz *= 4.0;
	// rainFlowNormal.xy += vec2(Get3DNoise(flowPos.xyz) * 2.0 - 1.0, Get3DNoise(flowPos.xyz + 2.0) * 2.0 - 1.0) * 0.035;
	// rainFlowNormal = normalize(rainFlowNormal);

	// n = mix(rainFlowNormal, n, saturate(worldNormal.y));

	n = mix(vec3(0, 0, 1), n, clamp(blockLight.y * 1.05 - 0.9, 0.0, 0.1) / 0.1);

	return n;
}

vec3 SlimeJiggleNormal(vec3 texNormal, vec3 worldPosition)
{
	vec3 p = worldPosition.xyz * 0.7;
	float a = 0.05;

	texNormal.x += simplex3d(p 		 + FRAME_TIME * 0.5) * a;
	texNormal.y += simplex3d(p + 2.0 + FRAME_TIME * 0.5) * a;

	texNormal = normalize(texNormal);

	return texNormal;
}

void main() {
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	#ifdef PHYSICS_OCEAN
		WavePixelData physics_waveData = physics_wavePixel(physics_localPosition.xz, physics_localWaviness, physics_iterationsNormal, physics_gameTime);
	#endif
	vec4 tex = texture2D(texture, texcoord.st);
		 //tex.a = 0.85f;

	vec4 transparentAlbedo = tex;

	float zero = 1.0f;
	float transx = 0.0f;
	float transy = 0.0f;
	//float isWater = 0.0f;

	float texblock = 0.0625f;




	if (isWater > 0.5 || isIce > 0.5) 
	{
		tex = vec4(0.0, 0.0, 0.0f, 0.2);
	}

	//store lightmap in auxilliary texture. r = torch light. g = lightning. b = sky light.

	vec4 lightmap = vec4(0.0f, 0.0f, 0.0f, 1.0f);
	lightmap.r = clamp((lmcoord.s * 33.05f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);
	lightmap.b = clamp((lmcoord.t * 33.05f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);

	//lightmap.b = pow(lightmap.b, 1.0f);
	//lightmap.r = pow(lightmap.r, 3.0f);







	float matID = 1.0f;

	if (isWater > 0.5f)
	{
		matID = 6.0f;
	}

	if (isIce > 0.5)
	{
		matID = 8;
	}

	if (isStainedGlass > 0.5 || isSlime > 0.5)
	{
		matID = 7.0;
	}

	if (isPortal > 0.5)
	{
		matID = 41.0; // MAT_ID_PORTAL: tinted like stained glass in composite.fsh + glows
	}


	matID += 0.1f;

  // gl_FragData[0] = vec4(tex.rgb, 0.2);

	mat3 tbnMatrix = mat3 (tangent.x, binormal.x, normal.x,
							tangent.y, binormal.y, normal.y,
					     	tangent.z, binormal.z, normal.z);




	#ifdef PHYSICS_OCEAN
		// Physics Mod supplies the wave normal (object space, y up) -> view space.
		#ifndef PHYSICS_OCEAN_V2
			physics_waveData.normal.xz *= 0.5;
		#endif
		vec3 physicsNormal = normalize(mat3(gbufferModelView) * physics_waveData.normal);
		physicsNormal = dot(physicsNormal, viewPos.xyz) > 0.0 ? -physicsNormal : physicsNormal;
		vec3 wavesNormal = physicsNormal;
	#else
	vec3 wavesNormal = GetWavesNormal(worldPosition, 1.0f, tbnMatrix);
	#endif
	//vec3 wavesNormal = vec3(0.0f, 0.0f, 1.0f);
	// Old RippleAnimation-texture rain ripples on water: only used when the rain ripples (RAIN_RIPPLE_WATER) are off.
	#if defined(RAIN_SPLASH_EFFECT) && !defined(RAIN_RIPPLE_WATER)
		wavesNormal = normalize(wavesNormal + GetRainNormal(worldPosition.xyz, 1.0) * 1.0 * vec3(1.0, 1.0, 0.0));
	#endif

	#ifdef PHYSICS_OCEAN
		vec3 waterNormal = wavesNormal; // already in view space
	#else
	vec3 waterNormal = wavesNormal * tbnMatrix;
	#endif
	vec3 texNormal = texture2D(normals, texcoord.st).rgb * 2.0f - 1.0f;
		 texNormal = texNormal * tbnMatrix;


	waterNormal = mix(waterNormal, texNormal, isIce + isStainedGlass + isSlime);

	waterNormal = mix(waterNormal, SlimeJiggleNormal(texNormal, worldPosition.xyz), isSlime);

	#ifdef RAIN_RIPPLE_WATER
	// Rain ripples on the water surface (lib/CustomRain.inc). World space slope -> view space.
	if (isWater > 0.5)
	{
		waterNormal += mat3(gbufferModelView) * rainRippleWater(worldPosition.xyz, worldNormal, lightmap.b);
	}
	#endif

	#if WATER_WAKE == 1 && !defined(PHYSICS_OCEAN)
	// Water ripples: the simulated wave field around the player tilts the surface normal.
	// Only real water takes it - ice, stained glass and slime keep their own normals.
	if (isWater > 0.5)
	{
		vec3 wakeFeetPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
		vec2 wakeSlope = WakeSlope(wakeFeetPos.xz);
		waterNormal += mat3(gbufferModelView) * vec3(wakeSlope.x, 0.0, wakeSlope.y);
	}
	#endif



	#ifndef PHYSICS_OCEAN
	// Fix impossible normal angles
	vec3 viewDir = normalize(-viewPos.xyz);
	waterNormal.xyz = normalize(waterNormal.xyz + 
		(normal / (saturate(dot(normal, viewDir)) + 0.001)) * 0.2);
	#endif



	GBufferDataTransparent gbuffer;

	gbuffer.albedo = tex;
	gbuffer.normal = waterNormal.xyz;
	#ifdef PHYSICS_OCEAN
		gbuffer.geoNormal = wavesNormal.xyz; // the flat mesh normal is meaningless on displaced waves
	#else
	gbuffer.geoNormal = normal.xyz;
	#endif
	gbuffer.materialID = matID / 255.0;
	// gbuffer.smoothness = 1.0 / (1.0 + dot(fwidth(worldPosition.xyz), vec3(0.1)));
	// water is perfectly smooth (1.0). The old distance-based 0.9-1.0 value made the reflection roughness filter blur/grain far water reflections; other transparents keep the old value.
	// Every translucent surface (water, ice, glass, stained glass, panes, slime, portal) is a perfect mirror like water.
	// The old distance-based 0.9-1.0 value (only used by non-water) made ice/glass reflections noisy: it made the
	// reflection roughness blur (composite1-4) kick in and use a jittered cone, so the reflection grained up with distance.
	gbuffer.smoothness = 1.0;
	gbuffer.mcLightmap = vec2(lightmap.x, lightmap.z);



	vec3 motion;
	{
		vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
			projPos /= projPos.w;
			projPos = projPos * 0.5 + 0.5;

		vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
		vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
		vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		motion = (projPos.xyz - projPosPrev.xyz);
	}


	vec4 data0, data1;

	OutputGBufferDataTransparent(gbuffer, data0, data1);

	gl_FragData[0] = data0;
	gl_FragData[1] = data1;
	// colortex8.a tags what this pixel is for the wake simulation (composite15): 0.5 = water,
	// 1.0 = anything else solid, 0.85 = entity (the other gbuffers passes).
	gl_FragData[2] = vec4(motion.xyz, isWater > 0.5 ? 0.5 : 1.0);

}

/* DRAWBUFFERS:128 */
