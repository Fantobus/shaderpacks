// MC 26.1+ (MC_VERSION >= 260000): translucent block entities (signs, banners...) are drawn after the deferred pass.
// Older versions: exact copy of gbuffers_terrain.vsh (what Iris used before this program existed, via its fallback).
#if MC_VERSION >= 260000



#define GLOWING_REDSTONE_BLOCK // If enabled, redstone blocks are treated as light sources for GI
#define GLOWING_LAPIS_LAZULI_BLOCK // If enabled, lapis lazuli blocks are treated as light sources for GI


#define GENERAL_GRASS_FIX

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"


attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;
attribute vec3 at_velocity;



out vec4 color;
out vec4 texcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec3 viewPos;
out vec3 velocity;
out vec4 preDownscaleProjPos;

out vec3 worldNormal;

out vec2 blockLight;

out float materialIDs;






void main() {

	color = gl_Color;

	texcoord = gl_MultiTexCoord0;
	lmcoord = gl_TextureMatrix[1] * gl_MultiTexCoord1;

	blockLight.x = clamp((lmcoord.x * 33.05f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);
	blockLight.y = clamp((lmcoord.y * 33.75f / 32.0f) - 1.05f / 32.0f, 0.0f, 1.0f);

	worldNormal = gl_Normal;

	
	vec4 localWorldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

	worldPosition = localWorldPos.xyz + cameraPosition.xyz;
	viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

	#ifdef ENTITY_MOTION_VECTOR_FIX
	velocity = at_velocity;
	#else
	// ENTITY_MOTION_VECTOR_FIX disabled: report zero velocity so the fragment
	// shader always takes its camera-only reprojection branch, matching the
	// original (pre-fix) behavior.
	velocity = vec3(0.0);
	#endif



	


	//Gather materials
	materialIDs = 1.0f;
	








	vec4 vp = gl_ModelViewMatrix * gl_Vertex;
	// Banner pattern layers sit exactly on the (solid) banner base. Nudge 2 mm towards the camera so they never lose the depth test to it.
	vp.xyz *= 1.0 - 0.002 / max(length(vp.xyz), 0.1);

	gl_Position = gl_ProjectionMatrix * vp;
	
	FinalVertexTransformTAA(gl_Position, preDownscaleProjPos);


}
#else



#define GLOWING_REDSTONE_BLOCK // If enabled, redstone blocks are treated as light sources for GI
#define GLOWING_LAPIS_LAZULI_BLOCK // If enabled, lapis lazuli blocks are treated as light sources for GI

#define WIND_EFFECT 0.35 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]

#define WIND_EFFECT_ENABLED // Master switch. Disable to turn off ALL wind sway
// completely - foliage, flowers, grass, leaves, wheat and vines all stand
// fully still, overriding everything else below (WIND_EFFECT strength and
// OUTDOOR_WIND_ONLY included). shadow.vsh mirrors this so shadows stop too.

#define OUTDOOR_WIND_ONLY // If enabled, wind sway is gated by each vertex's own Minecraft SKY light level.
// Fully indoors / caves (no sky light reaching the block) -> wind is completely
// disabled, foliage stands still. Under partial cover (e.g. a tree canopy,
// doorway, cave mouth) sky light is only partly blocked, so wind is scaled
// down to a much slower, subtler sway instead of an on/off snap. Fully
// outdoors (full sky light) behaves exactly like before. This uses the same
// per-vertex sky light value already computed for lighting (blockLight.y),
// so it is unaffected by torches/block light, time of day or weather - a
// torch-lit room still reads as indoors. shadow.vsh mirrors this exactly so
// the shadow a plant casts always matches its own reduced/disabled sway.

// === No-Wind block toggles ===
// Wind sway only ever applies to the explicit foliage whitelist further
// down (isWindFoliage). Everything else - including all of the blocks
// below, and things like signs - stays still by default, regardless of
// what GENERAL_GRASS_FIX decides for lighting purposes.
// Uncomment any line to opt that block category back into swaying.
//#define WIND_AMETHYST_SHARDS   // Amethyst cluster
//#define WIND_AMETHYST_BUDS     // Small/medium/large amethyst buds
//#define WIND_REDSTONE_TORCH    // Redstone torch (lit and unlit)
//#define WIND_CHAINS            // Chain (shares its ID with iron bars)
//#define WIND_BANNERS           // Standing and wall banners
//#define WIND_POINTED_DRIPSTONE // Pointed dripstone
//#define WIND_HEADS             // Mob/player heads - skeleton, wither skeleton, zombie, player, creeper, dragon (+ wall variants)
//#define WIND_LECTERN           // Lectern
//#define WIND_SIGNS             // Standing signs

#define GENERAL_GRASS_FIX

// === Photon waving plants ===
// Small plants (grass, ferns, flowers, saplings, mushrooms, crops, berry bush,
// mangrove propagule, small dripleaf, azalea/flowering azalea bush...), tall
// plants (tall grass, large fern, sunflower, lilac, rose bush, peony) and all
// leaves (oak/spruce/birch/jungle/acacia/dark_oak/mangrove/cherry/pale_oak/
// azalea/flowering_azalea) are animated by an exact port of Photon's wind -
// see lib/PhotonWind.inc.
// WIND_EFFECT below does NOT change those plants (Photon's own weather terms
// do); WIND_EFFECT_ENABLED still switches them off. OUTDOOR_WIND_ONLY is
// applied inside PwPlantDisplacement itself (lib/PhotonWind.inc), so turning
// it off restores full-strength indoor sway for these plants too.
// WIND_EFFECT keeps controlling vines and other foliage Photon does not sway
// (big dripleaf, coral, cave vines...).

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
// Photon-style waving plants (see file for details)
#include "/lib/PhotonWind.inc"


attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;



out vec4 color;
out vec4 texcoord;
out vec4 vtexcoordam;
out vec4 vtexcoord;
out vec4 lmcoord;
out vec3 worldPosition;
out vec3 viewPos;
out vec4 preDownscaleProjPos;
out vec4 glPosition;

out vec3 worldNormal;

out vec2 blockLight;

out float materialIDs;

out mat3 tbnMatrix;
out vec3 tangent;
out vec3 binormal;
out vec3 normal;


#include "/lib/Materials.inc"

 int f(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-0;
 }
 int t(int v)
 {
   return v-FloorToInt(mod(float(v),2.))-1;
 }
 int f()
 {
   ivec2 v=ivec2(viewWidth,viewHeight);
   int x=v.x*v.y;
   return f(FloorToInt(floor(pow(float(x),.333333))));
 }
 int t()
 {
   ivec2 v=ivec2(2048,2048);
   int x=v.x*v.y;
   return t(FloorToInt(floor(pow(float(x),.333333))));
 }
 vec3 s(vec2 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int s=x.x*x.y,y=f();
   ivec2 l=ivec2(v.x*x.x,v.y*x.y);
   float z=float(l.y/y),i=float(int(l.x+mod(x.x*z,y))/y);
   i+=floor(x.x*z/y);
   vec3 m=vec3(0.,0.,i);
   m.x=mod(l.x+mod(x.x*z,y),y);
   m.y=mod(l.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v)
 {
   ivec2 x=ivec2(viewWidth,viewHeight);
   int y=f();
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   r.y=i.y+floor(m/x.x)*y;
   r+=.5;
   r/=x;
   return r;
 }
 vec3 e(vec2 v)
 {
   vec2 i=v;
   i.xy/=.5;
   ivec2 x=ivec2(2048,2048);
   int s=x.x*x.y,y=t();
   ivec2 l=ivec2(i.x*x.x,i.y*x.y);
   float z=float(l.y/y),f=float(int(l.x+mod(x.x*z,y))/y);
   f+=floor(x.x*z/y);
   vec3 m=vec3(0.,0.,f);
   m.x=mod(l.x+mod(x.x*z,y),y);
   m.y=mod(l.y,y);
   m.xyz=floor(m.xyz);
   m/=y;
   m.xyz=m.xzy;
   return m;
 }
 vec2 d(vec3 v,int y)
 {
   v=clamp(v,vec3(0.),vec3(1.));
   vec2 x=vec2(2048,2048);
   vec3 i=v.xzy*y;
   i=floor(i+1e-05);
   float s=i.z;
   vec2 r;
   r.x=mod(i.x+s*y,x.x);
   float m=i.x+s*y;
   r.y=i.y+floor(m/x.x)*y;
   r+=.5;
   r/=x;
   r.xy*=.5;
   return r;
 }
 vec3 e(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v=clamp(v,vec3(0.),vec3(1.)),v;
 }
 vec3 f(vec3 v,int y)
 {
   return v*=1./y,v=v+vec3(.5),v;
 }
 vec3 v(vec3 v)
 {
   int x=t();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 n(vec3 v)
 {
   int x=f();
   v*=1./x;
   v=v+vec3(.5);
   v=clamp(v,vec3(0.),vec3(1.));
   return v;
 }
 vec3 x(vec3 v)
 {
   int x=f();
   v=v-vec3(.5);
   v*=x;
   return v;
 }
 vec3 d()
 {
   vec3 v=cameraPosition.xyz+.5,x=previousCameraPosition.xyz+.5,y=floor(v-.0001),s=floor(x-.0001);
   return y-s;
 }
 vec3 m(vec3 v)
 {
   vec4 x=vec4(v,1.);
   x=shadowModelView*x;
   x=shadowProjection*x;
   x/=x.w;
   float s=sqrt(x.x*x.x+x.y*x.y),y=1.f-SHADOW_MAP_BIAS+s*SHADOW_MAP_BIAS;
   x.xy*=.95f/y;
   x.z=mix(x.z,.5,.8);
   x=x*.5f+.5f;
   x.xy*=.5;
   x.xy+=.5;
   return x.xyz;
 }
 vec3 d(vec3 v,vec3 m,vec2 x,vec2 y,vec4 l,vec4 i,inout float f,out vec2 r)
 {
   bool s=fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.y*2.)>.01&&fract(v.y*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99;
   s=!s;
   if(i.x==8||i.x==9||i.x==79||i.x<1.||!s||i.x==20.||i.x==171.||min(abs(m.x),abs(m.z))>.2)
     f=1.;
   if(i.x==50.||i.x==52.||i.x==76.||i.x==75.||i.x==74.||i.x==72.)
     {
       f=0.;
       if(m.y<.5)
         f=1.;
     }
   if(i.x==51||i.x==53)
     f=0.;
   if(i.x>255)
     f=0.;
   vec3 g,z;
   if(m.x>.5)
     g=vec3(0.,0.,-1.),z=vec3(0.,-1.,0.);
   else
      if(m.x<-.5)
       g=vec3(0.,0.,1.),z=vec3(0.,-1.,0.);
     else
        if(m.y>.5)
         g=vec3(1.,0.,0.),z=vec3(0.,0.,1.);
       else
          if(m.y<-.5)
           g=vec3(1.,0.,0.),z=vec3(0.,0.,-1.);
         else
            if(m.z>.5)
             g=vec3(1.,0.,0.),z=vec3(0.,-1.,0.);
           else
              if(m.z<-.5)
               g=vec3(-1.,0.,0.),z=vec3(0.,-1.,0.);
   r=clamp((x.xy-y.xy)*100000.,vec2(0.),vec2(1.));
   float t=.15,b=.15;
   if(i.x==10.||i.x==11.)
     {
       // wall-mounted torches (copper/redstone): the flame top is tilted ~22.5 deg, so it failed the flat-top test
       // and was never written into the light volume -> very dim light. Accept tilted, non-block-aligned tops.
       bool tiltedTorchTop=m.y>.85&&m.y<=.99&&(fract(v.x*2.)>.01&&fract(v.x*2.)<.99||fract(v.z*2.)>.01&&fract(v.z*2.)<.99);
       if(abs(m.y)<.01&&s||m.y>.99||tiltedTorchTop)
         t=.1,b=.1,f=0.;
       else
          f=1.;
     }
   if(i.x==51||i.x==53)
     t=.5,b=.1;
   if(i.x==76)
     t=.2,b=.2;
   if(i.x-255.+39.>=103.&&i.x-255.+39.<=113.)
     b=.025,t=.025;
   g=normalize(l.xyz);
   z=normalize(cross(g,m.xyz)*sign(l.w));
   vec3 n=v.xyz+mix(g*t,-g*t,vec3(r.x));
   n.xyz+=mix(z*t,-z*t,vec3(r.y));
   n.xyz-=m.xyz*b;
   return n;
 }struct SPcacsgCKo{vec3 GadGLQcpqX;vec3 GadGLQcpqXOrigin;vec3 vAdYwconYe;vec3 AZVxALDdtL;vec3 UekatYTTmj;vec3 OmcxSfXfkJ;};
 SPcacsgCKo r(Ray v)
 {
   SPcacsgCKo i;
   i.GadGLQcpqX=floor(v.origin);
   i.GadGLQcpqXOrigin=i.GadGLQcpqX;
   i.vAdYwconYe=abs(vec3(length(v.direction))/(v.direction+1e-07));
   i.AZVxALDdtL=sign(v.direction);
   i.UekatYTTmj=(sign(v.direction)*(i.GadGLQcpqX-v.origin)+sign(v.direction)*.5+.5)*i.vAdYwconYe;
   i.OmcxSfXfkJ=vec3(0.);
   return i;
 }
 void p(inout SPcacsgCKo v)
 {
   v.OmcxSfXfkJ=step(v.UekatYTTmj.xyz,v.UekatYTTmj.yzx)*step(v.UekatYTTmj.xyz,v.UekatYTTmj.zxy),v.UekatYTTmj+=v.OmcxSfXfkJ*v.vAdYwconYe,v.GadGLQcpqX+=v.OmcxSfXfkJ*v.AZVxALDdtL;
 }
 void d(in Ray v,in vec3 m[2],out float x,out float i)
 {
   float y,z,f,r;
   x=(m[v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   i=(m[1-v.sign[0]].x-v.origin.x)*v.inv_direction.x;
   y=(m[v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   z=(m[1-v.sign[1]].y-v.origin.y)*v.inv_direction.y;
   f=(m[v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   r=(m[1-v.sign[2]].z-v.origin.z)*v.inv_direction.z;
   x=max(max(x,y),f);
   i=min(min(i,z),r);
 }
 vec3 d(const vec3 v,const vec3 x,vec3 y)
 {
   const float z=1e-05;
   vec3 s=(x+v)*.5,i=(x-v)*.5,m=y-s,f=vec3(0.);
   f+=vec3(sign(m.x),0.,0.)*step(abs(abs(m.x)-i.x),z);
   f+=vec3(0.,sign(m.y),0.)*step(abs(abs(m.y)-i.y),z);
   f+=vec3(0.,0.,sign(m.z))*step(abs(abs(m.z)-i.z),z);
   return normalize(f);
 }
 bool e(const vec3 v,const vec3 x,Ray i,out vec2 y)
 {
   vec3 z=i.inv_direction*(v-i.origin),m=i.inv_direction*(x-i.origin),l=min(m,z),s=max(m,z);
   vec2 f=max(l.xx,l.yz);
   float g=max(f.x,f.y);
   f=min(s.xx,s.yz);
   float n=min(f.x,f.y);
   y.x=g;
   y.y=n;
   return n>max(g,0.);
 }
 bool d(const vec3 v,const vec3 x,Ray i,inout float y,inout vec3 z)
 {
   vec3 f=i.inv_direction*(v-1e-05-i.origin),m=i.inv_direction*(x+1e-05-i.origin),l=min(m,f),s=max(m,f);
   vec2 r=max(l.xx,l.yz);
   float g=max(r.x,r.y);
   r=min(s.xx,s.yz);
   float n=min(r.x,r.y);
   bool t=n>max(g,0.)&&max(g,0.)<y;
   if(t)
     z=d(v-1e-05,x+1e-05,i.origin+i.direction*g),y=g;
   return t;
 }
 vec3 e(vec3 v,vec3 i,vec3 y,vec3 x,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 l=m(v);
   float s=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(l.xy,l.z-.0006*s),2).x;
   f*=saturate(dot(i,y));
   {
     vec4 r=texture2DLod(shadowcolor1,l.xy-vec2(0.,.5),4);
     float t=abs(r.x*256.-(v.y+cameraPosition.y)),g=GetCausticsComposite(v,i,t),n=shadow2DLod(shadowtex0,vec3(l.xy-vec2(0.,.5),l.z+1e-06),4).x;
     f=mix(f,f*g,1.-n);
   }
   f=TintUnderwaterDepth(f);
   return f*(1.-rainStrength);
 }
 vec3 f(vec3 x,vec3 i,vec3 y,vec3 f,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   vec3 r=v(x);
   r+=1.;
   r-=Fract01(cameraPosition+.5);
   vec3 l=m(r+y*.99);
   float s=.5;
   vec3 g=vec3(1.)*shadow2DLod(shadowtex0,vec3(l.xy,l.z-.0006*s),3).x;
   g*=saturate(dot(i,y));
   g=TintUnderwaterDepth(g);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(l.xy-vec2(.5,0.),l.z-.0006*s),3).x;
   vec3 n=texture2DLod(shadowcolor,vec2(l.xy-vec2(.5,0.)),3).xyz;
   n*=n;
   g=mix(g,g*n,vec3(1.-t));
   #endif
   return g*(1.-rainStrength);
 }
 vec3 m(vec3 v,vec3 x,vec3 y,vec3 i,int z)
 {
   if(rainStrength>.99)
     return vec3(0.);
   v+=1.;
   v-=Fract01(cameraPosition+.5);
   vec3 l=m(v);
   float s=.5;
   vec3 f=vec3(1.)*shadow2DLod(shadowtex0,vec3(l.xy,l.z-.0006*s),2).x;
   f*=saturate(dot(x,y));
   f=TintUnderwaterDepth(f);
   #ifdef GI_SUNLIGHT_STAINED_GLASS_TINT
   float t=shadow2DLod(shadowtex0,vec3(l.xy-vec2(.5,0.),l.z-.0006*s),3).x;
   vec3 r=texture2DLod(shadowcolor,vec2(l.xy-vec2(.5,0.)),3).xyz;
   r*=r;
   f=mix(f,f*r,vec3(1.-t));
   #endif
   return f*(1.-rainStrength);
 }struct CPrmwMXxJc{float pzBOsrqcFy;float ivaOqoXyFu;float OxTKjfMYEH;float avjkUoKnfB;vec3 PVAMAgODVh;};
 vec4 i(CPrmwMXxJc v)
 {
   vec4 i;
   v.PVAMAgODVh=max(vec3(0.),v.PVAMAgODVh);
   i.x=v.pzBOsrqcFy;
   v.PVAMAgODVh=pow(v.PVAMAgODVh,vec3(.125));
   i.y=PackTwo16BitTo32Bit(v.PVAMAgODVh.x,v.OxTKjfMYEH);
   i.z=PackTwo16BitTo32Bit(v.PVAMAgODVh.y,v.avjkUoKnfB);
   i.w=PackTwo16BitTo32Bit(v.PVAMAgODVh.z,v.ivaOqoXyFu/255.);
   return i;
 }
 CPrmwMXxJc G(vec4 v)
 {
   CPrmwMXxJc i;
   vec2 x=UnpackTwo16BitFrom32Bit(v.y),m=UnpackTwo16BitFrom32Bit(v.z),l=UnpackTwo16BitFrom32Bit(v.w);
   i.pzBOsrqcFy=v.x;
   i.OxTKjfMYEH=x.y;
   i.avjkUoKnfB=m.y;
   i.ivaOqoXyFu=l.y*255.;
   i.PVAMAgODVh=pow(vec3(x.x,m.x,l.x),vec3(8.));
   return i;
 }
 CPrmwMXxJc w(vec2 v)
 {
   vec2 x=1./vec2(viewWidth,viewHeight),y=vec2(viewWidth,viewHeight);
   v=(floor(v*y)+.5)*x;
   return G(texture2DLod(colortex5,v,0));
 }
 float G(float v,float y)
 {
   float x=1.;
   #ifdef FULL_RT_REFLECTIONS
   x=clamp(pow(v,.125)+y,0.,1.);
   #else
   x=clamp(v*10.-7.,0.,1.);
   #endif
   return x;
 }
 bool G(vec3 v,float x,Ray i,bool y,inout float f,inout vec3 z)
 {
   bool m=false,r=false;
   #if RAYTRACE_GEOMETRY_QUALITY==0
   if(y)
     return false;
   if(x>=67.)
     return false;
   r=d(v,v+vec3(1.,1.,1.),i,f,z);
   m=r;
   #else
   if(x<40.)
     return r=d(v,v+vec3(1.,1.,1.),i,f,z),r;
   if(x==40.||x==41.||x>=43.&&x<=54.)
     {
       float s=.5;
       if(x==41.)
         s=.9375;
       r=d(v+vec3(0.,0.,0.),v+vec3(1.,s,1.),i,f,z);
       m=m||r;
     }
   if(x==42.||x>=55.&&x<=66.)
     r=d(v+vec3(0.,.5,0.),v+vec3(1.,1.,1.),i,f,z),m=m||r;
   if(x==43.||x==46.||x==47.||x==52.||x==53.||x==54.||x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==58.||x==59.||x==64.||x==65.||x==66.)
         s=0.;
       r=d(v+vec3(0.,s,0.),v+vec3(.5,.5+s,.5),i,f,z);
       m=m||r;
     }
   if(x==43.||x==45.||x==48.||x==51.||x==53.||x==54.||x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
     {
       float s=.5;
       if(x==55.||x==57.||x==60.||x==63.||x==65.||x==66.)
         s=0.;
       r=d(v+vec3(.5,s,0.),v+vec3(1.,.5+s,.5),i,f,z);
       m=m||r;
     }
   if(x==44.||x==45.||x==49.||x==51.||x==52.||x==54.||x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
     {
       float s=.5;
       if(x==56.||x==57.||x==61.||x==63.||x==64.||x==66.)
         s=0.;
       r=d(v+vec3(.5,s,.5),v+vec3(1.,.5+s,1.),i,f,z);
       m=m||r;
     }
   if(x==44.||x==46.||x==50.||x==51.||x==52.||x==53.||x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
     {
       float s=.5;
       if(x==56.||x==58.||x==62.||x==63.||x==64.||x==65.)
         s=0.;
       r=d(v+vec3(0.,s,.5),v+vec3(.5,.5+s,1.),i,f,z);
       m=m||r;
     }
   if(x>=67.&&x<=82.)
     r=d(v+vec3(6.,0.,6.)/16.,v+vec3(10.,16.,10.)/16.,i,f,z),m=m||r;
   if(x==68.||x==69.||x==70.||x==72.||x==73.||x==74.||x==76.||x==77.||x==78.||x==80.||x==81.||x==82.)
     {
       float s=8.,g=8.;
       if(x==68.||x==70.||x==72.||x==74.||x==76.||x==78.||x==80.||x==82.)
         s=0.;
       if(x==69.||x==70.||x==73.||x==74.||x==77.||x==78.||x==81.||x==82.)
         g=16.;
       r=d(v+vec3(s,6.,7.)/16.,v+vec3(g,9.,9.)/16.,i,f,z);
       m=m||r;
       r=d(v+vec3(s,12.,7.)/16.,v+vec3(g,15.,9.)/16.,i,f,z);
       m=m||r;
     }
   if(x>=71.&&x<=82.)
     {
       float s=8.,t=8.;
       if(x>=71.&&x<=74.||x>=79.&&x<=82.)
         t=16.;
       if(x>=75.&&x<=82.)
         s=0.;
       r=d(v+vec3(7.,6.,s)/16.,v+vec3(9.,9.,t)/16.,i,f,z);
       m=m||r;
       r=d(v+vec3(7.,12.,s)/16.,v+vec3(9.,15.,t)/16.,i,f,z);
       m=m||r;
     }
   #if RAYTRACE_GEOMETRY_QUALITY==2
   if(x>=83.&&x<=86.)
     {
       vec3 s=vec3(0),l=vec3(0);
       if(x==83.)
         s=vec3(0,0,0),l=vec3(16,16,3);
       if(x==84.)
         s=vec3(0,0,13),l=vec3(16,16,16);
       if(x==86.)
         s=vec3(0,0,0),l=vec3(3,16,16);
       if(x==85.)
         s=vec3(13,0,0),l=vec3(16,16,16);
       r=d(v+s/16.,v+l/16.,i,f,z);
       m=m||r;
     }
   if(x>=87.&&x<=102.)
     {
       vec3 s=vec3(0.),l=vec3(1.);
       if(x>=87.&&x<=94.)
         {
           float t=0.;
           if(x>=91.&&x<=94.)
             t=13.;
           s=vec3(0.,t,0.)/16.;
           l=vec3(16.,t+3.,16.)/16.;
         }
       if(x>=95.&&x<=98.)
         {
           float t=13.;
           if(x==97.||x==98.)
             t=0.;
           s=vec3(0.,0.,t)/16.;
           l=vec3(16.,16.,t+3.)/16.;
         }
       if(x>=99.&&x<=102.)
         {
           float g=13.;
           if(x==99.||x==100.)
             g=0.;
           s=vec3(g,0.,0.)/16.;
           l=vec3(g+3.,16.,16.)/16.;
         }
       r=d(v+s,v+l,i,f,z);
       m=m||r;
     }
   if(x>=103.&&x<=113.)
     {
       vec3 s=vec3(0.),l=vec3(1.);
       if(x>=103.&&x<=110.)
         {
           float n=float(x)-float(103.)+1.;
           l.y=n*2./16.;
         }
       if(x==111.)
         l.y=.0625;
       if(x==112.)
         s=vec3(1.,0.,1.)/16.,l=vec3(15.,1.,15.)/16.;
       if(x==113.)
         s=vec3(1.,0.,1.)/16.,l=vec3(15.,.5,15.)/16.;
       r=d(v+s,v+l,i,f,z);
       m=m||r;
     }
   #endif
   #endif
   return m;
 }
 vec3 h(vec2 x)
 {
   vec2 v=vec2(x.xy*vec2(viewWidth,viewHeight));
   v*=1./64.;
   const vec2 i[16]=vec2[16](vec2(-1,-1),vec2(0,-.333333),vec2(-.5,.333333),vec2(.5,-.777778),vec2(-.75,-.111111),vec2(.25,.555556),vec2(-.25,-.555556),vec2(.75,.111111),vec2(-.875,.777778),vec2(.125,-.925926),vec2(-.375,-.259259),vec2(.625,.407407),vec2(-.625,-.703704),vec2(.375,-.037037),vec2(-.125,.62963),vec2(.875,-.481482));
   if(x.x<2./viewWidth||x.x>1.-2./viewWidth||x.y<2./viewHeight||x.y>1.-2./viewHeight)
     ;
   v=(floor(v*64.)+.5)/64.;
   vec3 r=texture2D(noisetex,v).xyz,s=vec3(sqrt(.2),sqrt(2.),1.61803);
   r=mod(r+float(frameCounter%64)*s,vec3(1.));
   return r;
 }
 void main()
 {
    color=gl_Color;
    texcoord=gl_MultiTexCoord0;
    {
        vec2 pomTexMinusMid = texcoord.xy - mc_midTexCoord.xy;
        vtexcoordam.pq = abs(pomTexMinusMid) * 2.0;
        vtexcoordam.st = min(texcoord.xy, mc_midTexCoord.xy - pomTexMinusMid);
        vtexcoord.xy   = sign(pomTexMinusMid) * 0.5 + 0.5;
        vtexcoord.zw   = vec2(0.0);
    }
    lmcoord=gl_TextureMatrix[1]*gl_MultiTexCoord1;
    blockLight.x=clamp(lmcoord.x*33.05f/32.f-.0328125f,0.f,1.f);
    blockLight.y=clamp(lmcoord.y*33.75f/32.f-.0328125f,0.f,1.f);
    worldNormal=gl_Normal;
    vec4 x=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;
    // Save the original vine vertex so its final wind displacement can be
    // constrained to the outside of the block face.
    vec3 vineBasePosition=x.xyz;
    worldPosition=x.xyz+cameraPosition.xyz;
    viewPos=(gl_ModelViewMatrix*gl_Vertex).xyz;



   materialIDs=MAT_ID_OPAQUE;
   float v=0.f,s=abs(normalize(gl_Normal.xz).x),f=abs(gl_Normal.y);
   if(mc_Entity.x==31.||mc_Entity.x==38.f||mc_Entity.x==37.f||mc_Entity.x==1925.f||mc_Entity.x==1920.f||mc_Entity.x==1921.f
      ||mc_Entity.x==2.&&gl_Normal.y<.5&&s>.01&&s<.99&&f<.9
      // Modern vegetation/custom IDs: keep these on the same wind path as
      // the original grass/flower materials so their shadow can follow.
      ||mc_Entity.x>=904.f&&mc_Entity.x<=913.f)
     materialIDs=MAT_ID_GRASS,v=1.f;
   #ifdef GENERAL_GRASS_FIX
   if(abs(worldNormal.x)>.01&&abs(worldNormal.x)<.99||abs(worldNormal.y)>.01&&abs(worldNormal.y)<.99||abs(worldNormal.z)>.01&&abs(worldNormal.z)<.99)
     materialIDs=MAT_ID_GRASS;
   #endif
   if(mc_Entity.x==175.f||mc_Entity.x==PW_UPPER_HALF_ID)
     materialIDs=MAT_ID_GRASS;
   if(mc_Entity.x>=904.f&&mc_Entity.x<=913.f)
     materialIDs=MAT_ID_GRASS,v=1.f;
   if(mc_Entity.x==59.)
     materialIDs=MAT_ID_GRASS,v=1.f;
   if(mc_Entity.x==914.f||mc_Entity.x==915.f||mc_Entity.x==919.f)
     materialIDs=MAT_ID_LEAVES;
   if(mc_Entity.x==916.f||mc_Entity.x==920.f)
     materialIDs=MAT_ID_GRASS,v=1.f;
   if(mc_Entity.x==18.||mc_Entity.x==161.f)
     {
       if(color.x>.999&&color.y>.999&&color.z>.999)
         ;
       else
          materialIDs=MAT_ID_LEAVES;
       if(abs(color.x-color.y)>.001||abs(color.x-color.z)>.001||abs(color.y-color.z)>.001)
         materialIDs=MAT_ID_LEAVES;
     }
   if(mc_Entity.x==50||mc_Entity.x==52)
     materialIDs=MAT_ID_TORCH;
   if(mc_Entity.x==10||mc_Entity.x==11||mc_Entity.x==75||mc_Entity.x==74||mc_Entity.x==72||mc_Entity.x==76)
     materialIDs=MAT_ID_LAVA;
   if(mc_Entity.x==89||mc_Entity.x==124||mc_Entity.x==169||mc_Entity.x==91)
     materialIDs=MAT_ID_GLOWSTONE;
   #ifdef GLOWING_REDSTONE_BLOCK
   if(mc_Entity.x==152)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   #ifdef GLOWING_LAPIS_LAZULI_BLOCK
   if(mc_Entity.x==22)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   #ifdef GLOWING_EMERALD_BLOCK
   if(mc_Entity.x==133)
     materialIDs=MAT_ID_GLOWSTONE;
   #endif
   if(mc_Entity.x==51||mc_Entity.x==53)
     materialIDs=MAT_ID_FIRE;
   if(mc_Entity.x==188||mc_Entity.x==189||mc_Entity.x==190||mc_Entity.x==191)
     materialIDs=MAT_ID_LIT_FURNACE;
    // === Fixed vegetation movement ===
    // Wind sway is now driven ENTIRELY by an explicit whitelist of foliage
    // block IDs (isWindFoliage, below) instead of by materialIDs==MAT_ID_GRASS.
    //
    // Why: GENERAL_GRASS_FIX (top of file) flags ANY block with angled/
    // non-axis-aligned normals as "grass" purely so it gets correct
    // two-sided lighting/wetness. That's fine for lighting, but the wind
    // code used to reuse the SAME flag to decide what should sway - so
    // anything with a tilted normal moved in the wind. Signs are the most
    // visible case: standing signs rotate in 16 small steps, so most
    // placements aren't axis-aligned and got flagged as "grass" and swayed.
    // The previous fix blacklisted a handful of other false positives
    // (amethyst, chains, banners, dripstone, heads, lectern) one at a time,
    // but kept missing new ones like signs.
    //
    // Only mc_Entity IDs listed in isWindFoliage below will ever move in
    // the wind, no matter what GENERAL_GRASS_FIX decides for lighting.
    bool isWindFoliage =
           mc_Entity.x==31.f || mc_Entity.x==38.f || mc_Entity.x==37.f   // tall grass/fern/dead bush, flowers
        || mc_Entity.x==175.f                                           // double plants (sunflower, lilac, peony, tall grass/fern)
        || mc_Entity.x==59.f                                            // wheat
        || mc_Entity.x==6.f                                             // legacy saplings (oak/spruce/birch/jungle/acacia/dark_oak)
        || mc_Entity.x==39.f || mc_Entity.x==40.f                       // brown/red mushroom
        || mc_Entity.x==207.f                                           // beetroots (all growth stages)
        || mc_Entity.x==917.f                                           // sweet berry bush
        || mc_Entity.x==918.f || mc_Entity.x==925.f                      // glow berries (cave vines/cave vines plant, with and without berries)
        || mc_Entity.x==106.f                                           // vines (twisting/weeping vines, 911, no longer sway)
        // big dripleaf (916) removed - no wind sway; small dripleaf (920) uses Photon wind, also disabled above
        || (mc_Entity.x>=904.f && mc_Entity.x<=913.f && mc_Entity.x!=911.f) // saplings, propagule, pitcher plant, flowers, bush/short grass, fungus/roots, coral (911 twisting/weeping vines excluded - no wind)
        || (mc_Entity.x==2. && gl_Normal.y<.5 && s>.01 && s<.99 && f<.9); // grass_block side tuft overlay
    // Sugar cane (mc_Entity.x==83) is deliberately excluded - both the
    // block and its shadow stay fully static.

    // === Opt-in extras ===
    // These blocks aren't vegetation, but if you liked them swaying,
    // uncomment the matching #define near the top of the file to add them
    // back to the whitelist. Off by default - they will NOT move otherwise.
    #ifdef WIND_AMETHYST_SHARDS
    isWindFoliage = isWindFoliage || mc_Entity.x==900.0f; // amethyst_cluster
    #endif
    #ifdef WIND_AMETHYST_BUDS
    isWindFoliage = isWindFoliage || (mc_Entity.x==901.0f||mc_Entity.x==921.0f||mc_Entity.x==922.0f); // small/medium/large amethyst bud
    #endif
    #ifdef WIND_REDSTONE_TORCH
    isWindFoliage = isWindFoliage || mc_Entity.x==76.0f || mc_Entity.x==77.0f; // redstone_torch (lit/unlit)
    #endif
    #ifdef WIND_CHAINS
    isWindFoliage = isWindFoliage || mc_Entity.x==330.0f; // chain (shares ID with iron_bars)
    #endif
    #ifdef WIND_BANNERS
    isWindFoliage = isWindFoliage || mc_Entity.x==176.0f || mc_Entity.x==177.0f; // standing/wall banner
    #endif
    #ifdef WIND_POINTED_DRIPSTONE
    isWindFoliage = isWindFoliage || mc_Entity.x==902.0f; // pointed_dripstone
    #endif
    #ifdef WIND_HEADS
    isWindFoliage = isWindFoliage || mc_Entity.x==144.0f; // skeleton/wither_skeleton/zombie/player/creeper/dragon head + wall variants
    #endif
    #ifdef WIND_LECTERN
    isWindFoliage = isWindFoliage || mc_Entity.x==903.0f; // lectern
    #endif
    #ifdef WIND_SIGNS
    isWindFoliage = isWindFoliage || mc_Entity.x==63.0f; // standing sign
    #endif

    float waveCoeff = (materialIDs == MAT_ID_GRASS || materialIDs == MAT_ID_LEAVES) ? 1.0f : 0.0f;
    // Plants handled by the Photon-style wind (lib/PhotonWind.inc) must NOT also
    // get SEUS's old sway, so they are removed from the old weight here. Blocks
    // Photon does not sway (vines, cave vines, dripleaf, coral...) keep the old sway.
    int pwPlantClass = PwPlantClass(mc_Entity.x);
    float grassWeight = (isWindFoliage && pwPlantClass == 0) ? 1.0f : 0.0f;
    float lightWeight = clamp(max(blockLight.x, blockLight.y), 0.0f, 1.0f);
    const float pi = 3.14159265f;

// Slower, world-anchored vegetation wind.
// Using worldPosition for the phase prevents camera/player movement
// from making the vegetation appear to speed up.
float windTime = WIND_TIME * WIND_EFFECT;

#ifdef WIND_EFFECT_ENABLED
        float windMasterFactor = 1.0f;
#else
        float windMasterFactor = 0.0f;
#endif

#ifdef OUTDOOR_WIND_ONLY
        // Raw per-vertex sky light exposure: 0 = no sky visible (indoors/caves),
        // 1 = fully open sky. Independent of block light so lit indoor areas
        // still count as indoors.
        float outdoorSkylight = blockLight.y;
        // Smoothed 0-1 gate used for sway MAGNITUDE - reaches exactly 0 once
        // sky light is fully blocked, so indoor foliage is perfectly still.
        float outdoorWindFactor = smoothstep(0.0f, 1.0f, outdoorSkylight) * windMasterFactor;
        // Separate, gentler curve for sway SPEED - keeps a slow residual motion
        // under partial cover rather than snapping the animation rate itself,
        // while magnitude alone still fully silences fully-indoor foliage.
        float outdoorWindSpeed = mix(0.2f, 1.0f, smoothstep(0.0f, 1.0f, outdoorSkylight));
        windTime *= outdoorWindSpeed;
#else
        float outdoorWindFactor = windMasterFactor;
#endif

vec3 windWorldPos = worldPosition;
        vec2 addAngleLight = vec2(0.0f);
        vec2 addAngleHeavy = vec2(0.0f);
        vec2 addAngle = vec2(0.0f);

        vec3 addPn0 = windWorldPos;
        addPn0.x -= windTime / 3.0f;

        vec3 addStoch = texture2D(noisetex, addPn0.xz / 64.0f).xyz;
        vec3 addStochLarge = texture2D(noisetex, windWorldPos.xz / (64.0f * 6.0f)).xyz;

        vec3 addPn = windWorldPos;
        addPn.x *= 2.0f;
        addPn.x -= windTime * 15.0f;
        addPn.z *= 8.0f;

        vec3 addStochLargeMoving =
            texture2D(noisetex, addPn.xz / (64.0f * 10.0f)).xyz;

        vec3 addP = windWorldPos;
        addP.x += sin(addP.z / 2.0f);
        addP.xz += addStochLarge.rg * 5.0f;

        float addWindStrength = mix(0.85f, 1.0f, rainStrength);
        float addWindRandom = addStochLargeMoving.x;
        addWindRandom = pow(addWindRandom, mix(2.0f, 1.0f, rainStrength));
        addWindStrength *= mix(addWindRandom, 0.5f, rainStrength * 0.25f);

        float addHeavyAF = 8.0f;
        float addHeavyAL = 0.9f;
        float addHeavyAR = 13.0f;
        float addHeavyAA = 15.0f;
        float addHeavyAO = 15.0f;

        float addHeavyLF = 6.732f;
        float addHeavyLL = 1.274f;
        float addHeavyLR = 1.0f;
        float addHeavyLA = 6.0f;
        float addHeavyLO = 0.0f;

        float addLightAF = 5.5f;
        float addLightAL = 1.1f;
        float addLightAR = 21.0f;
        float addLightAA = 5.0f;
        float addLightAO = 5.0f;

        float addLightLF = 5.9732f;
        float addLightLL = 1.174f;
        float addLightLR = 0.0f;
        float addLightLA = 1.0f;
        float addLightLO = 0.0f;

        float addCrossfade = clamp(addWindStrength * 2.0f - 1.0f, 0.0f, 1.0f);
        float addLightFade = clamp(addWindStrength * 2.0f, 0.2f, 1.0f);

        addAngleLight.x += sin(windTime * addLightAF
            - addP.x * addLightAL + addStoch.x * addLightAR)
            * addLightAA + addLightAO;
        addAngleLight.y += sin(windTime * addLightLF
            - addP.x * addLightLL + addStoch.x * addLightLR)
            * addLightLA + addLightLO;

        addAngleHeavy.x += sin(windTime * addHeavyAF
            - addP.x * addHeavyAL + addStoch.x * addHeavyAR)
            * addHeavyAA + addHeavyAO;
        addAngleHeavy.y += sin(windTime * addHeavyLF
            - addP.x * addHeavyLL + addStoch.x * addHeavyLR)
            * addHeavyLA + addHeavyLO;

        addAngle = mix(addAngleLight * addLightFade, addAngleHeavy,
                       vec2(addCrossfade));
        addAngle *= 2.0f;

        // Vines (entity 106) use the exact same wind bend as grass/plants.
        // Keep the strength tied to the vine vertex height so the attached part
        // stays steadier while the hanging part moves more.
        float vineWeight = (mc_Entity.x == 106.0f) ? clamp(texcoord.t, 0.0f, 1.0f) : 1.0f;
        float vegetationWindWeight = grassWeight * vineWeight * lightWeight * outdoorWindFactor;

        x.x += sin((addAngle.x / 180.0f) * 3.141579f) 
            * vegetationWindWeight * 0.5f;
        x.z += sin((addAngle.y / 180.0f) * 3.141579f)
            * vegetationWindWeight * 0.5f;
        x.y += (cos(((addAngle.x + addAngle.y) / 180.0f) * 3.141579f) - 1.0f)
            * vegetationWindWeight * 0.5f;

    if (mc_Entity.x == 59.0f && texcoord.t < 0.35f)
    {
        float addWheatSpeed = 0.28f;
        float addMagnitude =
            sin((windTime * 20.0f * 3.14159265f / 28.0f) + windWorldPos.x + windWorldPos.z) * 0.12f + 0.02f;
        addMagnitude *= grassWeight * 0.2f;
        addMagnitude *= lightWeight;
        addMagnitude *= outdoorWindFactor;

        float addD0 = sin(windTime * 20.0f * 3.14159265f / (122.0f * addWheatSpeed)) * 3.0f
            - 1.5f + windWorldPos.z;
        float addD1 = sin(windTime * 20.0f * 3.14159265f / (152.0f * addWheatSpeed)) * 3.0f
            - 1.5f + windWorldPos.x;
        float addD2 = sin(windTime * 20.0f * 3.14159265f / (122.0f * addWheatSpeed)) * 3.0f
            - 1.5f + windWorldPos.x;
        float addD3 = sin(windTime * 20.0f * 3.14159265f / (152.0f * addWheatSpeed)) * 3.0f
            - 1.5f + windWorldPos.z;

        x.x += sin((windTime * 20.0f * 3.14159265f / (28.0f * addWheatSpeed))
            + (x.x + addD0) * 0.1f
            + (windWorldPos.z + addD1) * 0.1f) * addMagnitude;
        x.z += sin((windTime * 20.0f * 3.14159265f / (28.0f * addWheatSpeed))
            + (windWorldPos.z + addD2) * 0.1f
            + (x.x + addD3) * 0.1f) * addMagnitude;
    }

    if (mc_Entity.x == 59.0f && texcoord.t < 0.35f)
    {
        float addLeafSpeed = 0.22f;
        float addMagnitude =
            (sin((windWorldPos.y + windWorldPos.x) / 2.0f + windTime * 20.0f * 3.14159265f / 28.0f)
            * 0.025f + 0.075f) * 0.2f;
        addMagnitude *= grassWeight;
        addMagnitude *= lightWeight;
        addMagnitude *= outdoorWindFactor;

        float addD0 = sin(windTime * 20.0f * 3.14159265f / (112.0f * addLeafSpeed)) * 3.0f - 1.5f;
        float addD1 = sin(windTime * 20.0f * 3.14159265f / (142.0f * addLeafSpeed)) * 3.0f - 1.5f;
        float addD2 = sin(windTime * 20.0f * 3.14159265f / (112.0f * addLeafSpeed)) * 3.0f - 1.5f;
        float addD3 = sin(windTime * 20.0f * 3.14159265f / (142.0f * addLeafSpeed)) * 3.0f - 1.5f;

        x.x += sin((windTime * 20.0f * 3.14159265f / (18.0f * addLeafSpeed))
            + (-windWorldPos.x + addD0) * 1.6f
            + (windWorldPos.z + addD1) * 1.6f)
            * addMagnitude * (1.0f + rainStrength * 2.0f);
        x.z += sin((windTime * 20.0f * 3.14159265f / (18.0f * addLeafSpeed))
            + (windWorldPos.z + addD2) * 1.6f
            + (-windWorldPos.x + addD3) * 1.6f)
            * addMagnitude * (1.0f + rainStrength * 2.0f);
        x.y += sin((windTime * 20.0f * 3.14159265f / (11.0f * addLeafSpeed))
            + windWorldPos.z + addD2 + windWorldPos.x + addD3)
            * (addMagnitude / 3.0f) * (1.0f + rainStrength * 2.0f);
    }

    // === Vine wind ===
    // Minecraft vines use entity ID 106. Keep the attached edge fixed and
    // make the free part of the vine gently sway with the same world wind.
    // pwPlantClass == 0: vines now use the Photon-style leaf wind below, so
    // the old vine sway is skipped to avoid two animations at once.
    if (mc_Entity.x == 106.0f && pwPlantClass == 0)
    {
        float vineSpeed = 0.32f;
        float vineTime = windTime * 20.0f * 3.14159265f / 28.0f;

        // Bottom vertices stay anchored; upper vertices receive more motion.
        float vineWeight = clamp(fract(worldPosition.y) * 1.25f, 0.0f, 1.0f);
        vineWeight *= lightWeight;
        vineWeight *= outdoorWindFactor;

        float vineNoise = texture2D(
            noisetex,
            worldPosition.xz / 32.0f
        ).r;

        float vineSway =
            sin(vineTime / vineSpeed
                + worldPosition.x * 1.7f
                + worldPosition.z * 1.3f
                + vineNoise * 6.2831853f) * 0.035f;

        float vineSway2 =
            cos(vineTime / (vineSpeed * 1.35f)
                + worldPosition.z * 1.4f
                - worldPosition.x * 1.1f
                + vineNoise * 4.0f) * 0.025f;

        // Push away from the wall/face the vine is attached to.
        vec2 vineDir = normalize(gl_Normal.xz + vec2(1e-5f));
        x.xz += vineDir * (vineSway + vineSway2) * vineWeight;

        // Small vertical flutter keeps vines from looking rigid.
        x.y += sin(vineTime / (vineSpeed * 1.7f)
            + worldPosition.x * 1.2f
            + worldPosition.z * 1.5f) * 0.018f * vineWeight;
    }

    // pwPlantClass == 0 excludes leaves now handled by the Photon-style wind
    // below (id 18/914/915), so they don't get both animations at once.
    if (materialIDs == 3.0f && texcoord.t < 1.90f && texcoord.t > -1.0f && pwPlantClass == 0)
    {
        float addLeavesSpeed = 0.25f;
        float addMagnitude =
            (sin(windWorldPos.y + windWorldPos.x + windTime * 20.0f * 3.14159265f / (28.0f * addLeavesSpeed))
            * 0.15f + 0.15f) * 0.30f * lightWeight * 0.2f;
        addMagnitude *= lightWeight;
        addMagnitude *= outdoorWindFactor;

        float addD0 = sin(windTime * 20.0f * 3.14159265f / (112.0f * addLeavesSpeed)) * 3.0f - 1.5f;
        float addD1 = sin(windTime * 20.0f * 3.14159265f / (142.0f * addLeavesSpeed)) * 3.0f - 1.5f;
        float addD2 = sin(windTime * 20.0f * 3.14159265f / (132.0f * addLeavesSpeed)) * 3.0f - 1.5f;
        float addD3 = sin(windTime * 20.0f * 3.14159265f / (122.0f * addLeavesSpeed)) * 3.0f - 1.5f;

        x.x += sin((windTime * 20.0f * 3.14159265f / (18.0f * addLeavesSpeed))
            + (-windWorldPos.x + addD0) * 1.6f
            + (windWorldPos.z + addD1) * 1.6f)
            * addMagnitude * (1.0f + rainStrength);
        x.z += sin((windTime * 20.0f * 3.14159265f / (17.0f * addLeavesSpeed))
            + (windWorldPos.z + addD2) * 1.6f
            + (-windWorldPos.x + addD3) * 1.6f)
            * addMagnitude * (1.0f + rainStrength);
        x.y += sin((windTime * 20.0f * 3.14159265f / (11.0f * addLeavesSpeed))
            + windWorldPos.z + addD2 + windWorldPos.x + addD3)
            * (addMagnitude / 2.0f) * (1.0f + rainStrength);
    }
    // === Photon waving plants ===
    // Exact port of Photon's plant animation (small plants, and tall plants
    // split into lower/upper half). WIND_EFFECT does not scale it - Photon's
    // own weather terms control the strength. OUTDOOR_WIND_ONLY is honored
    // inside PwPlantDisplacement (see lib/PhotonWind.inc): when it's off,
    // indoor plants sway at full strength instead of being silenced by
    // skylight==0. WIND_EFFECT_ENABLED still works as the master off switch.
    #ifdef WIND_EFFECT_ENABLED
    if (pwPlantClass > 0)
    {
        bool pwIsTopVertex = texcoord.y < mc_midTexCoord.y;
        float pwSkylight = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
        x.xyz += PwPlantDisplacement(windWorldPos, pwIsTopVertex, pwSkylight, pwPlantClass);
    }
    #endif

    // x may have been displaced by vegetation; update derived positions.
    worldPosition=x.xyz+cameraPosition.xyz;
    viewPos=(gl_ModelViewMatrix * vec4(x.xyz, 1.0)).xyz;
   // Vines only: never let wind move a vine vertex through the block it is
   // attached to.  We keep the component parallel to the wall (so the wave
   // still works), but remove any displacement pointing into the wall.
   if(mc_Entity.x==106.f)
   {
     vec3 vineNormal=normalize(worldNormal);
     float vineNormalLength=length(vineNormal.xz);
     if(vineNormalLength>0.001f)
     {
       vineNormal.y=0.0f;
       vineNormal=normalize(vineNormal);
       vec3 vineDelta=x.xyz-vineBasePosition;
       float inward=dot(vineDelta,vineNormal);
       if(inward<0.0f)
         x.xyz-=vineNormal*inward;
     }
   }

   float m=1.;
   if(color.x==1.&&color.y==1.&&color.z==1.)
     m=0.;
   normal=normalize(gl_NormalMatrix*gl_Normal);
   float i=-1.;
   if(gl_Normal.x>.5)
     tangent=normalize(gl_NormalMatrix*vec3(0.,0.,i)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
   else
      if(gl_Normal.x<-.5)
       tangent=normalize(gl_NormalMatrix*vec3(0.,0.,1.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
     else
        if(gl_Normal.y>.5)
         tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,0.,1.));
       else
          if(gl_Normal.y<-.5)
           tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,0.,-1.));
         else
            if(gl_Normal.z>.5)
             tangent=normalize(gl_NormalMatrix*vec3(1.,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
           else
              if(gl_Normal.z<-.5)
               tangent=normalize(gl_NormalMatrix*vec3(i,0.,0.)),binormal=normalize(gl_NormalMatrix*vec3(0.,-1.,0.));
   tbnMatrix=mat3(tangent.x,binormal.x,normal.x,tangent.y,binormal.y,normal.y,tangent.z,binormal.z,normal.z);
   gl_Position=gl_ProjectionMatrix*gbufferModelView*x;
   FinalVertexTransformTAA(gl_Position,preDownscaleProjPos);
   glPosition=gl_Position;
 };
#endif
