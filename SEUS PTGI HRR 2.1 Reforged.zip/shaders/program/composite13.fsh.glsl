#extension GL_ARB_gpu_shader5 : enable

/*
 _______ _________ _______  _______  _
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/


#define AVERAGE_EXPOSURE //Toggle automatic scene-average exposure. Manually adjust exposure is needed when disabled.

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"



/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////CONFIGURABLE VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////END OF CONFIGURABLE VARIABLES/////////////////////////////////////////////////////////////////////////////////////////////////////////////



in vec4 texcoord;
in vec3 lightVector;


in float timeSunriseSunset;
in float timeNoon;
in float timeMidnight;

in vec3 colorSunlight;
in vec3 colorSkylight;

in float avgSkyBrightness;

#define COLOR_TEX colortex1

// overlap/rbOverlap bumped to match SEUS PTGI HRR GFME v1.13: coneOverlap is no longer
// applied inside each individual tonemap operator (see Tonemap() below), it's applied once
// globally around whichever operator is selected, so the constant was retuned for that.
#ifdef HRR3_LOOK
const float overlap = 1.9;
#else
const float overlap = 0.2;
#endif

const float rgOverlap = 0.1 * overlap;
#ifdef HRR3_LOOK
const float rbOverlap = 0.03 * overlap;
#else
const float rbOverlap = 0.01 * overlap;
#endif
const float gbOverlap = 0.04 * overlap;

const mat3 coneOverlap = mat3(1.0, 			rgOverlap, 	rbOverlap,
							  rgOverlap, 	1.0, 		gbOverlap,
							  rbOverlap, 	rgOverlap, 	1.0);

const mat3 coneOverlapInverse = mat3(	1.0 + (rgOverlap + rbOverlap), 			-rgOverlap, 	-rbOverlap,
									  	-rgOverlap, 		1.0 + (rgOverlap + gbOverlap), 		-gbOverlap,
									  	-rbOverlap, 		-rgOverlap, 	1.0 + (rbOverlap + rgOverlap));

// ACES
const mat3 ACESInputMat = mat3(
    0.59719, 0.35458, 0.04823,
    0.07600, 0.90834, 0.01566,
    0.02840, 0.13383, 0.83777
);

const mat3 ACESOutputMat = mat3(
     1.60475, -0.53108, -0.07367,
    -0.10208,  1.10813, -0.00605,
    -0.00327, -0.07276,  1.07602
);

vec3 Uncharted2Tonemap(vec3 x)
{
	x *= 3.0;

	// float A = 0.15;
	// float B = 0.50;
	// float C = 0.10;
	// float D = 0.20;
	// float E = 0.02;
	// float F = 0.30;

	float A = 0.9;
	float B = 0.8;
	float C = 0.1;
	float D = 1.0;
	float E = 0.02;
	float F = 0.30;

	#ifdef HRR3_LOOK
	// coneOverlap is now applied once globally in Tonemap(), matching GFME v1.13.
	// x = x * coneOverlap;
	#else
	x = x * coneOverlap;
	#endif

	x = ((x*(A*x+C*B)+D*E)/(x*(A*x+B)+D*F))-E/F;

	#ifdef HRR3_LOOK
	// x = x * coneOverlapInverse;
	#else
	x = x * coneOverlapInverse;
	#endif

    return x;
}

float almostIdentity( float x, float m, float n )
{
    if( x>m ) return x;

    float a = 2.0*n - m;
    float b = 2.0*m - 3.0*n;
    float t = x/m;

    return (a*t + b)*t*t + n;
}

vec3 almostIdentity(vec3 x, vec3 m, vec3 n)
{
	return vec3(
		almostIdentity(x.x, m.x, n.x),
		almostIdentity(x.y, m.y, n.y),
		almostIdentity(x.z, m.z, n.z)
		);
}

vec3 BlackDepth(vec3 color, vec3 blackDepth)
{
	vec3 m = blackDepth;
	vec3 n = blackDepth * 0.5;
	return (almostIdentity(color, m, n) - n);// * (vec3(1.0) - n);
}

vec3 BurgessTonemap(vec3 col)
{
	col *= 0.9;
	#ifdef HRR3_LOOK
	// coneOverlap is now applied once globally in Tonemap(), matching GFME v1.13.
	// col = col * coneOverlap;
	#else
	col = col * coneOverlap;
	#endif

	vec3 maxCol = col;


    const float p = 1.0;
    maxCol = pow(maxCol, vec3(p));

    vec3 retCol = (maxCol * (6.2 * maxCol + 0.05)) / (maxCol * (6.2 * maxCol + 2.3) + 0.06);
	retCol = pow(retCol, vec3(1.0 / p));

	#ifdef HRR3_LOOK
	// retCol = retCol * coneOverlapInverse;
	#else
	retCol = retCol * coneOverlapInverse;
	#endif

    return retCol;
}

vec3 SEUSTonemap(vec3 color)
{
#ifdef HRR3_LOOK
	// Reworked SEUSTonemap ("HRR3 look"):
	// - drops the old coneOverlap channel-crosstalk step and the TransformOutputColor()
	//   red-channel tilt at the end, letting channels respond more independently/punchily.
	// - adds a soft filmic S-curve rolloff (the two blocks below) on top of the classic
	//   Reinhard-style curve, which lifts shadow contrast and rolls off highlights more gently.
	color *= 1.1;

	const float p = EFFECTIVE_TONEMAP_CURVE;

	color = pow(color, vec3(p));
	color = color / (1.0 + color);
	color = pow(color, vec3((1.0 / GAMMA) / p));

	{
		const float a = 0.3;
		float l = a * a * (3.0 - 2.0 * a);

		vec3 c = color * (1.0 - a) + a;

		color = c * c * (3.0 - 2.0 * c);
		color -= l;
		color /= 1.0 - l;
		color = max(vec3(0.0), color);
	}

	{
		vec3 c = color;
		color = mix(color, c * c * (3.0 - 2.0 * c), vec3(0.2));
	}
#else
	const float p = EFFECTIVE_TONEMAP_CURVE;

		color = color * coneOverlap;

	color = pow(color, vec3(p));
	color = color / (1.0 + color);
	// color = 1.0 - exp(-color);
	color = pow(color, vec3((1.0 / GAMMA) / p));


		color = color * coneOverlapInverse;

	color = TransformOutputColor(color);
#endif

	return color;
}

vec3 ReinhardJodie(vec3 v)
{
	v = pow(v, vec3(EFFECTIVE_TONEMAP_CURVE));
    float l = Luminance(v);
    vec3 tv = v / (1.0f + v);

    vec3 tonemapped = mix(v / (1.0f + l), tv, tv);
	tonemapped = pow(tonemapped, vec3(1.0 / EFFECTIVE_TONEMAP_CURVE));

	return tonemapped;
}



/////////////////////////////////////////////////////////////////////////////////
//	ACES Fitting by Stephen Hill
vec3 RRTAndODTFit(vec3 v)
{
    vec3 a = v * (v + 0.0245786f) - 0.000090537f;
    vec3 b = v * (1.0f * v + 0.4329510f) + 0.238081f;
    return a / b;
}

vec3 ACESTonemap2(vec3 color)
{
	color *= 1.5;
	color = color * ACESInputMat;

    // Apply RRT and ODT
    color = RRTAndODTFit(color);


    // Clamp to [0, 1]
	color = color * ACESOutputMat;
    color = saturate(color);

    return color;
}
/////////////////////////////////////////////////////////////////////////////////





vec3 ACESTonemap(vec3 color)
{
	#ifdef HRR3_LOOK
	color *= 0.4;
	#else
	color *= 0.7;
	#endif

		#ifdef HRR3_LOOK
		// coneOverlap is now applied once globally in Tonemap(), matching GFME v1.13.
		// color = color * coneOverlap;
		#else
		color = color * coneOverlap;
		#endif



		vec3 crosstalk = vec3(0.05, 0.2, 0.05) * 2.9;

		// float avgColor = (color.r + color.g + color.b) * 0.33333;
		float avgColor = Luminance(color.rgb);

		// color = mix(color, vec3(avgColor), crosstalk);


	const float p = 1.0;
	color = pow(color, vec3(p));
	color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14);
	// color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.1);
	color = pow(color, vec3(1.0 / p));

		#ifdef HRR3_LOOK
		// color = color * coneOverlapInverse;
		#else
		color = color * coneOverlapInverse;
		#endif


		// float avgColorTonemapped = (color.r + color.g + color.b) * 0.33333;
		float avgColorTonemapped = Luminance(color.rgb);

		// color = mix(color, vec3(avgColorTonemapped), -crosstalk * 1.0);


	color = saturate(color);

	#ifdef HRR3_LOOK
	color = pow(color, vec3(0.85));
	#else
	color = pow(color, vec3(0.9));
	#endif

	// color = mix(color, vec3(avgColorTonemapped), vec3(-saturate(avgColor * 0.25 + 0.0)));


	return color;
}

// New tonemap option.
vec3 ExponentialTonemap(vec3 c)
{
	// c = 1.0 - exp2(-c*1.3);

	const vec3 t = vec3(2.0);
	const vec3 p = vec3(10.5);

	c = 1.0 - pow((t*c + 1.0) * p, -c);
	return c;
}



void CalculateExposureEyeBrightness(inout vec3 color) 
{
	float exposureMax = 1.55f;
		  //exposureMax *= mix(1.0f, 0.25f, timeSunriseSunset);
		  //exposureMax *= mix(1.0f, 0.0f, timeMidnight);
		  //exposureMax *= mix(1.0f, 0.25f, rainStrength);
		  exposureMax *= avgSkyBrightness * 2.0;
	float exposureMin = 0.07f;
	float exposure = pow(eyeBrightnessSmooth.y / 240.0f, 6.0f) * exposureMax + exposureMin;

	//exposure = 1.0f;

	color.rgb /= vec3(exposure);
	color.rgb *= 350.0;
}



void 	Vignette(inout vec3 color) {
	float dist = distance(texcoord.st, vec2(0.5f)) * 2.0f;
		  dist /= 1.5142f;

		  //dist = pow(dist, 1.1f);

	color.rgb *= 1.0f - dist * 0.5;

}

void DoNightEye(inout vec3 color)
{
	float lum = Luminance(color * vec3(1.0, 1.0, 1.0));
	float mixSize = 1250000.0;
	float mixFactor = 0.01 / (pow(lum * mixSize, 2.0) + 0.01);


	vec3 nightColor = mix(color, vec3(lum), vec3(0.9)) * vec3(0.25, 0.5, 1.0) * 2.0;

	color = mix(color, nightColor, mixFactor);
}

void Overlay(inout vec3 color, vec3 overlayColor)
{
	vec3 overlay = vec3(0.0);

	for (int i = 0; i < 3; i++)
	{
		if (color[i] > 0.5)
		{
			float valueUnit = (1.0 - color[i]) / 0.5;
			float minValue = color[i] - (1.0 - color[i]);
			overlay[i] = (overlayColor[i] * valueUnit) + minValue;
		}
		else
		{
			float valueUnit = color[i] / 0.5;
			overlay[i] = overlayColor[i] * valueUnit;
		}
	}

	color = overlay;
}

// GFME v1.10's exact auto-exposure formula: color = (color/(avgLum+min)) * mult.
// GFME's own constants (min=0.00064, mult=25) assume GFME's avgLum scale, which is
// not the same as Reforged's colortex6 average-luminance encoding (Reforged's is
// capped at 0.0035; see D() in composite7.fsh) - plugging GFME's raw constants in
// directly over-amplified everything to solid white.
//
// Reforged's original, proven-good response was color /= avgLum*23.9+0.0008 (then
// *9.6*EXPOSURE afterward). That's algebraically the exact same formula shape:
//   9.6 / (avgLum*23.9 + 0.0008)  ==  (9.6/23.9) / (avgLum + 0.0008/23.9)
// so mult = 9.6/23.9 and min = 0.0008/23.9 below reproduce Reforged's old, working
// brightness *exactly* at nightVision = 0, while now sharing GFME's exact formula
// and gaining GFME's nightVision-aware shadow lift (the min term shrinks toward
// ~0 as nightVision increases, matching GFME's own mix() behaviour).
#ifdef HRR3_LOOK
#ifdef GFME_EXPOSURE
// GFME's own constants, paired with GFME's brightness measurement in composite7.fsh
float AutoExposureMin = mix(0.00064, 0.0000001, nightVision);
const float AutoExposureMult = 25.0;
#define AVG_LUM_FALLBACK 0.1
#else
float AutoExposureMin = mix(0.0008 / 23.9, 0.0000001, nightVision);
const float AutoExposureMult = 9.6 / 23.9;
#define AVG_LUM_FALLBACK 0.0035
#endif
#else
#define AVG_LUM_FALLBACK 0.0035
#endif

void AverageExposure(inout vec3 color, float avgLum)
{
	// When AVERAGE_EXPOSURE is disabled, fall back to a fixed scene luminance
	// instead of the measured average, matching SEUS PTGI HRR GFME's behaviour:
	// the image no longer auto-adapts, and EXPOSURE becomes a purely manual
	// brightness control. Reforged's measured avgLum is capped at 0.0035 (see
	// D() in composite7.fsh) and sits at that cap in most lit scenes, so that
	// cap - not GFME's own fallback value, which lives on a different scale -
	// is the correct "neutral" constant here.
	#ifndef AVERAGE_EXPOSURE
		avgLum = AVG_LUM_FALLBACK;
	#endif

	#ifdef HRR3_LOOK
	color = (color / (avgLum + AutoExposureMin)) * AutoExposureMult;
	#else
	color /= avgLum * 23.9 + 0.0008;
	#endif
}

// coneOverlap channel crosstalk and the
// TransformOutputColor() red-channel tilt used to live inside individual tonemap
// operators (or, for SEUSTonemap, not at all - see the note in SEUSTonemap above).
// v1.13 moves both steps out here so every operator gets the same crosstalk bleed
// and warm output tilt, which is what makes bright saturated emitters (lava, fire,
// torches) bloom harder and read brighter/warmer after tonemapping.
vec3 Tonemap(vec3 color)
{
#ifdef HRR3_LOOK
	color *= coneOverlap;
	color = TONEMAP_OPERATOR(color);
	color *= coneOverlapInverse;
	color = TransformOutputColor(color);
#else
	color = TONEMAP_OPERATOR(color);
#endif
	return color;
}


#include "/lib/Bloom.inc"

#include "/lib/FXAA.inc"

/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// --- Color grading --------------------------------------------------------------
float ApplyGradeChannel(float value, float lift, float gamma, float gain, float offset, float contrast, float mixAmount)
{
	float v = max(value + lift + offset, 0.0);
	v = pow(v, 1.0 / max(gamma, 0.001)) * gain;
	v = (v - 0.5) * contrast + 0.5;
	return mix(value, max(v, 0.0), clamp(mixAmount, 0.0, 1.0));
}

vec3 ApplyColorGrading(vec3 color)
{
	color.r = ApplyGradeChannel(color.r, RED_LIFT, RED_GAMMA, RED_GAIN, RED_OFFSET, RED_CONTRAST, RED_MIX);
	color.g = ApplyGradeChannel(color.g, GREEN_LIFT, GREEN_GAMMA, GREEN_GAIN, GREEN_OFFSET, GREEN_CONTRAST, GREEN_MIX);
	color.b = ApplyGradeChannel(color.b, BLUE_LIFT, BLUE_GAMMA, BLUE_GAIN, BLUE_OFFSET, BLUE_CONTRAST, BLUE_MIX);

	vec3 tint = max(vec3(TINT_R, TINT_G, TINT_B), vec3(0.0));
	vec3 tinted = color * tint;
	float lum = Luminance(tinted);
	tinted = mix(vec3(lum), tinted, max(TINT_SATURATION, 0.0));
	tinted = (tinted - 0.5) * TINT_CONTRAST + 0.5;
	tinted = max(tinted + TINT_LIFT, 0.0) * TINT_GAIN;
	tinted = pow(max(tinted, 0.0), vec3(1.0 / max(TINT_GAMMA, 0.001)));
	color = mix(color, tinted, clamp(TINT_STRENGTH, 0.0, 1.0));
	return max(color, vec3(0.0));
}

void main() {


	vec3 color = 	(texture2D(COLOR_TEX, texcoord.st).rgb);



	
	color = GammaToLinear(color);

	#ifndef SKIP_AA
	#if PIXEL_LOOK == 1
	{
		#ifdef HRR3_LOOK
		// Sampling: switched from a diagonal
		// 4-tap blur blended at 0.999 to a straight 2x2 box average, sampled from
		// the (0,0)-(1,1) texel quad and assigned directly instead of mixed in.
		vec3 col = vec3(0.0);
		col += GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(0.0, 0.0)).rgb);
		col += GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(0.0, 1.0)).rgb);
		col += GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(1.0, 0.0)).rgb);
		col += GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(1.0, 1.0)).rgb);
		col /= 4.0;
		color = col;
		#else
		const float s = 0.33;
		vec3 mb = GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(s, s)).rgb)
				  + GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(s, -s)).rgb)
				  + GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(-s, s)).rgb)
				  + GammaToLinear(texture2D(COLOR_TEX, texcoord.st + ScreenTexel * vec2(-s, -s)).rgb);

		color = mix(color, mb * 0.25, vec3(0.999));
		#endif
	}
	#endif
	#endif



	// Bloom mix + AverageExposure both need the scene's average luminance, so it's
	// computed once here (ported structure from SEUS PTGI HRR GFME v1.10 "HRR3 look").
	// The AVERAGE_EXPOSURE fallback is applied here too, so both consumers agree.
	float avgLum = texture2DLod(colortex6, vec2(0.0, 0.0), 0).a * 0.01;
	#ifndef AVERAGE_EXPOSURE
		avgLum = AVG_LUM_FALLBACK;
	#endif

	// Bloom mix: bloom strength now scales inversely with scene
	// brightness (more visible bloom in dark scenes, less in bright ones) instead of the
	// old flat 0.055 * BLOOM_AMOUNT blend.
	#ifdef HRR3_LOOK
	{
		vec3 bloom = GetBloom(texcoord.st);
		float bloomAmount = 0.06 * BLOOM_AMOUNT;
		bloomAmount /= sqrt(avgLum) * 4.0 + 0.5;
		bloomAmount = mix(bloomAmount, 0.9, saturate(isEyeInWater));
		color = mix(color, bloom, saturate(vec3(bloomAmount)));
	}
	#else
	color = mix(color, GetBloom(texcoord.st), vec3(0.055 * BLOOM_AMOUNT + isEyeInWater * 0.6));
	#endif


	Vignette(color);

	color = BlackDepth(color, vec3(0.000015 * BLACK_DEPTH * BLACK_DEPTH));

	// Scotopic ("rod excitement") rolloff ("HRR3 look").
	// Adds a faint blue-shifted glow to near-black areas, mimicking how human night vision
	// desaturates and blue-shifts in very dim light.
	#ifdef HRR3_LOOK
	{
		color *= 2.0;

		vec3 oc = color;
		float PP = 3.0;
		color = pow(color, vec3(1.0 / PP));
		color = saturate(color - 0.001);
		color = pow(color, vec3(PP));

		float rL = 0.00000008;
		float rodExcitement = dot(oc, vec3(0.001, 0.3, 0.8));
		rodExcitement = rodExcitement * rL / (rL + rodExcitement);
		color += rodExcitement * vec3(0.2, 0.3, 0.4) * 5.0;

		color /= 2.0;
	}
	#endif


	AverageExposure(color, avgLum);
	// color *= 71.0;




	// const float blackRolloff = 0.005 * BLACK_DEPTH;
	// const float blackClip = 0.0;

 //    color = vec3(
 //    	almostIdentity(color.x, blackRolloff, blackClip),
 //    	almostIdentity(color.y, blackRolloff, blackClip),
 //    	almostIdentity(color.z, blackRolloff, blackClip)
 //    	) - blackClip;



	// Pre-tonemap warm/cool channel tint ("HRR3 look").
	#ifdef HRR3_LOOK
	color *= pow(vec3(1.0, 1.07, 1.25), vec3(1.1));
	#endif

	// Restored EXPOSURE-only scaling to match GFME v1.10's structure - the old "9.6 *"
	// multiplier is now folded into AutoExposureMult above, so it's no longer needed here.
	#ifdef HRR3_LOOK
	color *= EXPOSURE;
	#else
	color *= 9.6 * EXPOSURE;
	#endif

	// Contrast (Photon contrast formula).
	const float log_midpoint = log2(0.18);
	color = log2(color + 1e-8);
	color = CONTRAST * (color - log_midpoint) + log_midpoint;
	color = max(exp2(color) - 1e-8, 0.0);


	#ifdef TONEMAP_COMPARISON
		// Split-screen tonemap comparison: Left Tonemap on the left half, Right Tonemap on the right half.
		if (texcoord.s < 0.5)
		{
			color = saturate(LEFT_TONEMAP(color) * (1.0 + WHITE_CLIP));
		}
		else
		{
			color = saturate(RIGHT_TONEMAP(color) * (1.0 + WHITE_CLIP));
		}
	#else
		color = saturate(Tonemap(color) * (1.0 + WHITE_CLIP));
	#endif


	// color = texture2DLod(shadowcolor1, texcoord.st * 0.5 + 0.5, 0).rrr;



	color = pow(color, vec3(1.0 / 2.2 + (1.0 - GAMMA)));


	#ifdef HRR3_LOOK
		// Baked-in HRR3 Look saturation boost (fixed, not user-adjustable).
		color = (mix(color, vec3(Luminance(color)), vec3(1.0 - HRR3_LOOK_SATURATION)));
	#endif
	// SATURATION menu slider applies on top of the above; default 1.0 is a no-op here.
	color = (mix(color, vec3(Luminance(color)), vec3(1.0 - SATURATION)));

	#ifdef COLOR_GRADING
		color = ApplyColorGrading(color);
	#endif
	// color = (mix(color, vec3(Luminance(color)), vec3(
	// 	(-Luminance(color) * 0.4) + 0.1
	// 	)));

	// color = (mix(color, vec3(Luminance(color)), vec3(
	// 	(-Luminance(color) * 0.2) + 0.0
	// )));




	// Dithering upgraded from white noise (rand) to temporal blue noise, matching
	// SEUS PTGI HRR GFME v1.10 ("HRR3 look"); blue noise dithers with less visible
	// low-frequency clumping than uniform white noise.
	#ifdef HRR3_LOOK
	color += (BlueNoiseTemporal(texcoord.st) - 0.95) * (3.0 / 255.0);
	#else
	color += rand(texcoord.st) * (1.0 / 255.0);
	#endif

	// color = mix(color, SampleCPrmwMXxJc(texcoord.xy).PVAMAgODVh * 3.0, vec3(0.9));

	// color = vec3(texture2DLod(colortex7, texcoord.st, 0).a);

	// color = texture2D(colortex6, texcoord.st).rgb * 12.0;
	// color = texture2D(colortex2, texcoord.st).rgb * 1.0;

	// color = vec3(texture2D(colortex2, texcoord.st).rgb) * 1.0;
	// color = vec3(texture2D(colortex4, texcoord.st).rgb) * 12.0;

	// color = vec3(texture2D(colortex1, texcoord.st).rgb) * 10.0;



	gl_FragData[0] = vec4(color.rgb, Luminance(color.rgb));
}


/* DRAWBUFFERS:0 */
