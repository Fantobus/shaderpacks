
#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
in vec4 color;
in vec4 preDownscaleProjPos;

#if MC_VERSION >= 260000

#include "/lib/GBufferData.inc"

// Iris, MC 26.1+: the block outline / leash / fishing line are drawn in the translucent phase, AFTER the
// deferred lighting pass. Writing only the scene colour (colortex0) is lost there, which made the outline
// invisible. Like particles, it is written into the TRANSPARENT gbuffer layout (colortex1 + colortex2,
// material 111) and blended over the scene in composite.fsh.
/* DRAWBUFFERS:12 */

void main() {
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	vec4 albedo = color;
	albedo.a = 0.5;

	GBufferDataTransparent gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = vec3(0.0, 0.0, 1.0);
	gbuffer.geoNormal = vec3(0.0, 0.0, 1.0);
	gbuffer.materialID = (111.0 + 0.1) / 255.0;
	gbuffer.smoothness = 0.0;
	gbuffer.mcLightmap = vec2(1.0);

	vec4 frag1, frag2;
	OutputGBufferDataTransparent(gbuffer, frag1, frag2);

	gl_FragData[0] = frag1;
	gl_FragData[1] = frag2;
}

#else

// Below 26 (1.21.x, OptiFine): original behaviour, unchanged.
/* DRAWBUFFERS:0 */

void main() {
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	vec4 albedo = color;
	albedo.a = 0.5;
	gl_FragData[0] = albedo;
}

#endif
