
// Glowing mob eyes (enderman, spiders, phantom, ender dragon, breeze, ...).
// Writes the eye pixels into the solid G-buffer as a flat, fully emissive surface
// (same approach as the beacon beam fix), so they glow instead of rendering black.

in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec3 velocity;
in vec4 preDownscaleProjPos;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"
#include "/lib/Materials.inc"

void main()
{
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}

	vec4 albedo = texture2D(texture, texcoord.st);
	albedo *= color;

	// Eye textures are black/transparent everywhere except the eyes themselves.
	// Vanilla draws them additively, so black contributes nothing - we have to
	// discard those pixels or they would overwrite the mob's body with black.
	if (albedo.a < 0.1 || max(albedo.r, max(albedo.g, albedo.b)) < 0.04) {
		discard;
		return;
	}

	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	GBufferData gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = N.xyz;
	gbuffer.mcLightmap = blockLight;
	gbuffer.smoothness = 0.0;
	gbuffer.metalness = 0.0;
	gbuffer.materialID = (MAT_ID_DYNAMIC_ENTITY + 0.1) / 255.0;
	// 0.5 marks "mob eyes" for the deferred pass (1.0 is the beacon beam value)
	gbuffer.emissive = 0.5;
	gbuffer.geoNormal = N.xyz;
	gbuffer.totalTexGrad = length(fwidth(texcoord.st)) * (256.0 / 8.0);

	vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	{
		// Same reprojection as gbuffers_entities.fsh (moving mob vs. static fallback)
		vec4 projPosPrev;

		if (dot(velocity.xyz, velocity.xyz) > 1e-8) {
			vec3 viewPosPrev = viewPos.xyz - velocity.xyz;
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev, 1.0);
		} else {
			vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
			vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		}

		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		gbuffer.motion = (projPos.xyz - projPosPrev.xyz);
	}

	vec4 frag0, frag1, frag2, frag3;

	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	gl_FragData[3] = frag3;
}

/* RENDERTARGETS: 0,1,2,8 */
