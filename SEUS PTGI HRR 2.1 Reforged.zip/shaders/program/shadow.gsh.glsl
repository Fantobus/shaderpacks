uniform vec3 cameraPosition;
#define MOB_LIGHTS_VOLUME_MATH
#include "/lib/MobLights.inc"


layout(triangles) in;
layout(triangle_strip, max_vertices = 6) out;

in vec4 vTexcoord[];
in vec4 vColor[];
// in vec3 vnormal[];
// in vec3 vrawNormal[];
in vec4 vViewPos[];
in float vMaterialIDs[];

in float NfBQQONGIL[];
in vec2 iqqNEmzHrA[];   	
in float GgEUdJcgVD[];
// in float vIsWater[];
// in float vIsStainedGlass[];
in float vMCEntity[];
in float vMobLight[];
in vec3 vMobPos[];
in vec3 MHKfCXtBYe[];  

in vec4 zoZckPcbco[];
in vec4 RrnawHBGMh[];



out vec4 color;
out vec4 texcoord;
// out vec3 normal;
// out vec3 rawNormal;
out vec4 viewPos;
out float materialIDs;

out float aGBCSUeTQs;		
out vec2 sbxhonUINy;		
out float fragDepth;
// out float isWater;
// out float isStainedGlass;
out float mcEntity;
out vec3 zrEuGoMOCd;  	


void main()
{
	int i;
	vec4 vertex;

	//Standard shadow pos
	for (i = 0; i < 3; i++)
	{
		vertex = gl_in[1].gl_Position;

		//...
		vertex = RrnawHBGMh[i];

		gl_Position = vertex;

		//copy varying here
		color = vColor[i];
		texcoord = vTexcoord[i];
		// normal = vnormal[i];
		// rawNormal = vrawNormal[i];
		viewPos = vViewPos[i];
		materialIDs = vMaterialIDs[i];
		sbxhonUINy = iqqNEmzHrA[i];
		fragDepth = GgEUdJcgVD[i];
		// isWater = vIsWater[i];
		// isStainedGlass = vIsStainedGlass[i];
		mcEntity = vMCEntity[i];
		aGBCSUeTQs = 0.0;

		EmitVertex();
	}
	EndPrimitive();


	//volume pos
	bool valid = true;
	if (NfBQQONGIL[0] > 0.5 || NfBQQONGIL[1] > 0.5 || NfBQQONGIL[2] > 0.5)
	{
		valid = false;
	}

	if (valid)
	{
		if (distance(zoZckPcbco[0].xy, zoZckPcbco[1].xy) > 1.0 / 1024.0 ||
			distance(zoZckPcbco[0].xy, zoZckPcbco[2].xy) > 1.0 / 1024.0 ||
			distance(zoZckPcbco[1].xy, zoZckPcbco[2].xy) > 1.0 / 1024.0)
		{

		}
		else
		{
			for (i = 0; i < 3; i++)
			{
				vertex = gl_in[1].gl_Position;

				//...
				vertex = zoZckPcbco[i];


				gl_Position = vertex;

				//copy varying here
				color = vColor[i];
				texcoord = vTexcoord[i];
				// normal = vnormal[i];
				// rawNormal = vrawNormal[i];
				viewPos = vViewPos[i];
				materialIDs = vMaterialIDs[i];
				sbxhonUINy = iqqNEmzHrA[i];
				fragDepth = GgEUdJcgVD[i];
				// isWater = vIsWater[i];
				// isStainedGlass = vIsStainedGlass[i];
				mcEntity = vMCEntity[i];
				zrEuGoMOCd = MHKfCXtBYe[i];
				aGBCSUeTQs = 1.0;


				EmitVertex();
			}
			EndPrimitive();
		}
	}


	// Mob lights: light-emitting mobs have no voxel-snapped vertices (the path above rejects entities), so snap the
	// WHOLE triangle to the cell holding its triCenter and draw it as one tiny triangle that covers exactly one texel
	// of the volume (see lib/MobLights.inc). Depth is MOB_VOXEL_Z so terrain voxels are never overwritten.
	if (vMobLight[0] > 0.5)
	{
		vec3 triCenter = (vMobPos[0] + vMobPos[1] + vMobPos[2]) / 3.0;
		vec2 cellClip;
		if (MobVoxelClip(floor(triCenter), cameraPosition, cellClip))
		{
			const float px = 2.0 / 4096.0; // one shadow-map texel in clip space
			vec2 corner[3] = vec2[3](vec2(-0.25, -0.25), vec2(0.75, -0.25), vec2(-0.25, 0.75));

			for (i = 0; i < 3; i++)
			{
				gl_Position = vec4(cellClip + corner[i] * px, MOB_VOXEL_Z, 1.0);

				color = vColor[i];
				texcoord = vTexcoord[i];
				viewPos = vViewPos[i];
				materialIDs = vMaterialIDs[i];
				sbxhonUINy = iqqNEmzHrA[i];
				fragDepth = 0.0;
				mcEntity = vMCEntity[i];
				zrEuGoMOCd = MHKfCXtBYe[i];
				aGBCSUeTQs = 1.0;

				EmitVertex();
			}
			EndPrimitive();
		}
	}


	// vec4 bottomLeft = 	vec4(-1.0, 	0.0, 	0.0, 1.0);
	// vec4 bottomRight = 	vec4(0.0, 	0.0, 	0.0, 1.0);
	// vec4 topLeft = 		vec4(-1.0, 	1.0,    0.0, 1.0);
	// vec4 topRight = 	vec4(0.0, 	1.0,    0.0, 1.0);

	// //Albedo quad
	// color = vec4(1.0);
	// normal = vec3(1.0);
	// rawNormal = vec3(1.0);
	// viewPos = vec4(0.0);
	// materialIDs = 1.0;
	// isStainedGlass = 0.0;
	// aGBCSUeTQs = 0.0;

	// texcoord = vec4(0.0, 0.0, 0.0, 0.0);
	// gl_Position = bottomLeft;

	// EmitVertex();


	// texcoord = vec4(0.0, 1.0, 0.0, 0.0);
	// gl_Position = topLeft;

	// EmitVertex();


	// texcoord = vec4(1.0, 1.0, 0.0, 0.0);
	// gl_Position = topRight;

	// EmitVertex();


	// EndPrimitive();



	// texcoord = vec4(0.0, 0.0, 0.0, 0.0);
	// gl_Position = bottomLeft;

	// EmitVertex();



	// texcoord = vec4(1.0, 1.0, 0.0, 0.0);
	// gl_Position = topRight;

	// EmitVertex();



	// texcoord = vec4(1.0, 0.0, 0.0, 0.0);
	// gl_Position = bottomRight;

	// EmitVertex();


	// EndPrimitive();



}
