// MC 26.1+ (MC_VERSION >= 260000; Iris encodes 26.1.0 as 260100, 1.21.11 as 12111): translucent-entity path below.
// Older versions: this file is an exact copy of gbuffers_entities.fsh, i.e. the behaviour before this fix.
#if MC_VERSION >= 260000

/*
	gbuffers_entities_translucent  (Iris only - OptiFine has no such program and ignores this file)

	Minecraft 26.1+ draws many entities - including the PLAYER (its skin uses the translucent entity
	render type) - in the translucent phase. Iris therefore runs them AFTER the deferred (lighting)
	pass, using this program (falling back to gbuffers_entities when it does not exist).

	gbuffers_entities writes the SOLID gbuffer layout (colortex0/1/2/8). Drawn after deferred that
	corrupts the buffers the composite passes read and the model comes out invisible/transparent.

	This program instead writes the TRANSPARENT gbuffer layout (the same one water / glass / particles
	use: colortex1 + colortex2 + motion in colortex8). Because the deferred lighting has already run,
	the entity cannot be lit there, so it is tagged with MAT_ID_TRANSLUCENT_ENTITY and lit +
	blended over the scene in composite.fsh (see TranslucentEntityLighting).
*/

in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec3 velocity;
in vec4 preDownscaleProjPos;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"
#include "/lib/Materials.inc"
#include "/lib/CustomRain.inc"

void main()
{
	if (PixelOutOfScreenBounds(preDownscaleProjPos)
		#ifdef NAMETAG_BACKGROUND_FIX
		|| (dot(color.rgb, vec3(1.0)) < 0.001 && abs(color.a - 0.5) < 0.49)
		#endif
	) {
		discard;
		return;
	}

	vec4 albedo = texture2D(texture, texcoord.st);
	albedo *= color;

	// Fully transparent texels (e.g. the player's hat / jacket / sleeve overlay layers) must not
	// write colour or depth.
	if (albedo.a < 0.01)
	{
		discard;
	}

	// Damage flash / creeper flash etc.
	albedo.rgb = mix(albedo.rgb, entityColor.rgb, vec3(entityColor.a));

	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	GBufferDataTransparent gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = N.xyz;
	gbuffer.geoNormal = N.xyz;
	gbuffer.materialID = (MAT_ID_TRANSLUCENT_ENTITY + 0.1) / 255.0;
	gbuffer.smoothness = 0.0;
	gbuffer.mcLightmap = blockLight;
	gbuffer.depth = 0.0;

	vec4 frag1, frag2;
	OutputGBufferDataTransparent(gbuffer, frag1, frag2);

	// Motion vector for TAA: camera-only reprojection (Iris does not supply usable at_velocity data).
	vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
	vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
	vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
	projPosPrev.xyz /= projPosPrev.w;
	projPosPrev = projPosPrev * 0.5 + 0.5;

	vec3 motion = projPos.xyz - projPosPrev.xyz;

	gl_FragData[0] = frag1;
	gl_FragData[1] = frag2;
	gl_FragData[2] = vec4(motion.xyz, 0.85); // wake simulation: "entity"
}

/* RENDERTARGETS: 1,2,8 */
#else

/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

















in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec3 velocity;
in vec4 preDownscaleProjPos;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;






#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"
#include "/lib/Materials.inc"
#include "/lib/CustomRain.inc"

// OptiFine: entity.properties maps the player to id 10001 (see lib/PlayerOcclusion.inc)
uniform int entityId;




void main() 
{	
	if (PixelOutOfScreenBounds(preDownscaleProjPos)
		#ifdef NAMETAG_BACKGROUND_FIX
		|| (dot(color.rgb, vec3(1.0)) < 0.001 && abs(color.a - 0.5) < 0.49)
		#endif
	) {
		discard;
		return;
	}
	float lodOffset = 0.0;

	vec4 albedo = texture2D(texture, texcoord.st, lodOffset);
	albedo *= color;

	vec2 mcLightmap = blockLight;



	float wetnessModulator = 1.0;

	vec3 rainNormal = vec3(0.0, 0.0, 0.0);
	#if defined(RAIN_SPLASH_EFFECT) && !defined(RAIN_RIPPLE_MOBS)
	rainNormal = GetRainSplashNormal(worldPosition, worldNormal, wetnessModulator);
	#endif

	wetnessModulator *= saturate(worldNormal.y * 10.5 + 0.7);
	wetnessModulator *= saturate(abs(2.0 - materialIDs));
	wetnessModulator *= clamp(blockLight.y * 1.05 - 0.7, 0.0, 0.3) / 0.3;
	wetnessModulator *= saturate(wetness * 1.1 - 0.1);



	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);




	vec4 specTex = texture2D(specular, texcoord.st, lodOffset);
		 #ifdef SPEC_SMOOTHNESS_AS_ROUGHNESS
specTex.SPEC_CHANNEL_SMOOTHNESS = 1.0 - specTex.SPEC_CHANNEL_SMOOTHNESS;
#endif
specTex.SPEC_CHANNEL_SMOOTHNESS = specTex.SPEC_CHANNEL_SMOOTHNESS * 0.992; 								// Fix weird specular issue
	vec4 normalTex = texture2D(normals, texcoord.st, lodOffset) * 2.0 - 1.0;

	float normalMapStrength = NORMAL_MAP_STRENGTH;
	#ifdef FORCE_WET_EFFECT
	normalMapStrength = mix(NORMAL_MAP_STRENGTH, 0.1, wetnessModulator * wetnessModulator * wetnessModulator * wetnessModulator);
	#endif

	vec3 viewNormal = tbn * normalize(normalTex.xyz * vec3(normalMapStrength, normalMapStrength, 1.0) + rainNormal * wetnessModulator);

	#ifdef RAIN_RIPPLE_MOBS
	// Rain ripples on the tops of mobs (lib/CustomRain.inc). World space slope -> view space.
	if (isEyeInWater < 1)
	{
		float mobUp = (mat3(gbufferModelViewInverse) * N).y;
		viewNormal = normalize(viewNormal + mat3(gbufferModelView) * rainRippleSurface(worldPosition, mobUp, blockLight.y, saturate(wetness * 1.1 - 0.1)));
	}
	#endif

	
	// Get specular data from specular texture
	float smoothness = specTex.SPEC_CHANNEL_SMOOTHNESS;
	float metallic = specTex.SPEC_CHANNEL_METALNESS;
	float emissive = specTex.SPEC_CHANNEL_EMISSIVE;
	emissive -= step(0.999, emissive);

	#ifdef FORCE_WET_EFFECT
	smoothness = mix(smoothness, 1.0, saturate(wetnessModulator * 1.0 * saturate(1.0 - metallic)));
	#endif

	// Darker albedo when wet
	albedo.rgb = pow(albedo.rgb, vec3(1.0 + wetnessModulator * (1.0 - metallic) * 0.3));




	// Fix impossible normal angles
	vec3 viewDir = -normalize(viewPos.xyz);
	vec3 relfectDir = reflect(-viewDir, viewNormal);
	// make outright impossible
	viewNormal.xyz = normalize(viewNormal.xyz + (N / (pow(saturate(dot(viewNormal, viewDir)) + 0.001, 0.5)) * 1.0));

	// Physics Mod snow support: snow is drawn through the entity program with a constant
	// (non-varying) texcoord, so use the geometric normal and a matte material.
	if (dot(abs(dFdx(texcoord.st)) + abs(dFdy(texcoord.st)), vec2(1.0)) < 1e-6) {
		viewNormal.xyz = N;
		smoothness = 0.0;
		metallic = 0.0;
	}





	// vec3 analyticNormal = normalize(cross(dFdx(viewPos.xyz), dFdy(viewPos.xyz)));

	// albedo.rgb = analyticNormal.xyz * 0.5 + 0.5;


	albedo.rgb = mix(albedo.rgb, entityColor.rgb, vec3(entityColor.a));




	GBufferData gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = viewNormal.xyz;
	gbuffer.mcLightmap = mcLightmap;
	gbuffer.smoothness = smoothness;
	gbuffer.metalness = metallic;
	gbuffer.materialID = (MAT_ID_DYNAMIC_ENTITY + 0.1) / 255.0;
	gbuffer.emissive = saturate(emissive);
	#ifndef SPEC_EMISSIVE
	gbuffer.emissive = 0.0;
	#endif
	gbuffer.geoNormal = N.xyz;
	// Marker read back by lib/PlayerOcclusion.inc: 3 in the parallaxOffset channel (unused for entities) = the player's own model
	gbuffer.parallaxOffset = (entityId == 10001) ? (3.0 + 0.1) / 255.0 : 0.0;
	gbuffer.totalTexGrad = length(fwidth(texcoord.st)) * (256.0 / 8.0);


	vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	{
		// Two different cases share this code path, and they need different math:
		//
		// 1) Real moving entities (mobs, players, etc). at_velocity here is in the
		//    CURRENT frame's view-space orientation. Reprojecting it required
		//    combining it with the PREVIOUS frame's view matrix (below), which also
		//    re-applies last frame's view-bob rotation on top of this frame's
		//    velocity. Bob rotation changes every frame and spikes during jumps, so
		//    that mismatch is exactly what caused the jump-time entity blur/distortion.
		//    Solving it entirely with the CURRENT-frame VIEW matrix sidesteps that
		//    mismatch, since velocity is already expressed in that frame's space -
		//    this is the originally-proven, stable mob-motion formula.
		//
		//    The projection matrix is a separate axis from the view matrix, though:
		//    it changes on its own whenever FOV animates (e.g. the ~1s FOV ramp when
		//    sprinting starts/stops), independently of view rotation/bob. The color
		//    buffer being reprojected against was rendered with LAST frame's
		//    projection, so projecting the "previous" entity position with the
		//    CURRENT projection (as before) is only correct while FOV is constant -
		//    during an FOV transition it silently assumes no projection change,
		//    which is exactly the sprint-start distortion. Using
		//    gbufferPreviousProjection here (while still keeping the current-frame
		//    VIEW matrix for viewPosPrev) fixes that without reintroducing the bob
		//    mismatch, since view and projection are independent.
		//
		// 2) Static "entities" with no real motion of their own (holograms, nametags,
		//    etc, where velocity is ~0). These have no velocity signal to reproject
		//    with, so they need the full previous-camera reprojection (matching the
		//    terrain formula) to avoid dragging/ghosting when the camera itself moves.
		vec4 projPosPrev;

		if (dot(velocity.xyz, velocity.xyz) > 1e-8) {
			vec3 viewPosPrev = viewPos.xyz - velocity.xyz;
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev, 1.0);
		} else {
			vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
			vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
			projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		}

		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		gbuffer.motion = (projPos.xyz - projPosPrev.xyz);
	}


	vec4 frag0, frag1, frag2, frag3;

	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	frag3.a = (entityId == 10001) ? 0.7 : ((entityId == 10002) ? 0.77 : 0.85); // wake simulation: "entity" (0.7 = the player's own model, 0.85 = anything else)
	gl_FragData[3] = frag3;

}

/* RENDERTARGETS: 0,1,2,8 */
#endif
