// MC 26.1+ (MC_VERSION >= 260000): translucent block entities (signs, banners...) are drawn after the deferred pass.
// Older versions: exact copy of gbuffers_terrain.fsh (what Iris used before this program existed, via its fallback).
#if MC_VERSION >= 260000

/*
	gbuffers_entities_translucent  (Iris only - OptiFine has no such program and ignores this file)

	Minecraft 26.1+ draws many entities - including the PLAYER (its skin uses the translucent entity
	render type) - in the translucent phase. Iris therefore runs them AFTER the deferred (lighting)
	pass, using this program (falling back to gbuffers_entities when it does not exist).

	gbuffers_entities writes the SOLID gbuffer layout (colortex0/1/2/8). Drawn after deferred that
	corrupts the buffers the composite passes read and the model comes out invisible/transparent.

	This program instead writes the TRANSPARENT gbuffer layout (the same one water / glass / particles
	use: colortex1 + colortex2 + motion in colortex8). Because the deferred lighting has already run,
	the entity cannot be lit there, so it is tagged with MAT_ID_TRANSLUCENT_ENTITY and lit +
	blended over the scene in composite.fsh (see TranslucentEntityLighting).
*/

in vec4 color;
in vec4 texcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec3 velocity;
in vec4 preDownscaleProjPos;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;

#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"
#include "/lib/Materials.inc"

void main()
{
	if (PixelOutOfScreenBounds(preDownscaleProjPos)
		#ifdef NAMETAG_BACKGROUND_FIX
		|| (dot(color.rgb, vec3(1.0)) < 0.001 && abs(color.a - 0.5) < 0.49)
		#endif
	) {
		discard;
		return;
	}

	vec4 albedo = texture2D(texture, texcoord.st);
	albedo *= color;

	// Fully transparent texels (e.g. the player's hat / jacket / sleeve overlay layers) must not
	// write colour or depth.
	if (albedo.a < 0.01)
	{
		discard;
	}

	// Damage flash / creeper flash etc.
	albedo.rgb = mix(albedo.rgb, entityColor.rgb, vec3(entityColor.a));

	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	GBufferDataTransparent gbuffer;
	gbuffer.albedo = albedo;
	gbuffer.normal = N.xyz;
	gbuffer.geoNormal = N.xyz;
	gbuffer.materialID = (MAT_ID_TRANSLUCENT_ENTITY + 0.1) / 255.0;
	gbuffer.smoothness = 0.0;
	gbuffer.mcLightmap = blockLight;
	gbuffer.depth = 0.0;

	vec4 frag1, frag2;
	OutputGBufferDataTransparent(gbuffer, frag1, frag2);

	// Motion vector for TAA: camera-only reprojection (Iris does not supply usable at_velocity data).
	vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	vec4 projPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
	vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
	vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
	projPosPrev.xyz /= projPosPrev.w;
	projPosPrev = projPosPrev * 0.5 + 0.5;

	vec3 motion = projPos.xyz - projPosPrev.xyz;

	gl_FragData[0] = frag1;
	gl_FragData[1] = frag2;
	gl_FragData[2] = vec4(motion.xyz, 1.0);
}

/* RENDERTARGETS: 1,2,8 */
#else

#define PARALLAX_MOTION_VECTOR_FIX // Prevents parallax from creating false motion vectors and temporal flicker. Disable for comparison with the original behavior.
#extension GL_ARB_gpu_shader5 : enable

/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
		) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

















in vec4 color;
in vec4 texcoord;
in vec4 vtexcoordam;
in vec4 vtexcoord;
in vec4 lmcoord;
in vec3 worldPosition;
in vec3 viewPos;
in vec4 preDownscaleProjPos;
in vec4 glPosition;

in vec3 worldNormal;

in vec2 blockLight;

in float materialIDs;


in mat3 tbnMatrix;
in vec3 tangent;
in vec3 binormal;
in vec3 normal;





#include "/lib/Uniforms.inc"
#include "/lib/Common.inc"
#include "/lib/GBufferData.inc"
#include "/lib/GBuffersCommon.inc"

// ---------------------------------------------------------------------------
// POM: exact port of Bliss's parallax occlusion mapping (all_solid.fsh).
// It works on per-block tile coordinates (vtexcoord / vtexcoordam) that the
// vertex shader derives from mc_midTexCoord, so it needs no texture resolution.
// ---------------------------------------------------------------------------
const float pomMinCoord = 1.0 / 4096.0;
#define POM_DEPTH (0.25 * PARALLAX_DEPTH)          // Bliss default 0.25 at Parallax Depth 1.0
#define POM_MAX_DIST (25.0 * PARALLAX_DISTANCE)    // Bliss default 25 blocks at Parallax Distance 1.0
#define POM_MIX_DIST (POM_MAX_DIST * 0.9)
#define POM_LIGHTING_DEPTH_CAP 0.02                // max blocks the POM may push the depth-buffer surface (keeps GI valid)

vec4 pomReadNormal(vec2 coord, vec2 gx, vec2 gy)
{
	return textureGrad(normals, fract(coord) * vtexcoordam.pq + vtexcoordam.st, gx, gy);
}

vec4 pomReadTexture(vec2 coord, vec2 gx, vec2 gy)
{
	return textureGrad(texture, fract(coord) * vtexcoordam.pq + vtexcoordam.st, gx, gy);
}

// Bilinear height sample in atlas uv, wrapped inside the current tile (resolution independent).
float BilinearHeightSample(vec2 coord)
{
	vec2 atlas = vec2(atlasSize);
	vec2 tileLo = vtexcoordam.st * atlas;
	vec2 tileSize = max(vtexcoordam.pq * atlas, vec2(1.0));
	vec2 p = coord * atlas - 0.5;
	vec2 f = fract(p);
	vec2 i0 = floor(p);

	vec2 a = tileLo + mod(i0 - tileLo, tileSize);
	vec2 b = tileLo + mod(i0 + 1.0 - tileLo, tileSize);

	float h00 = texture2DLod(normals, (vec2(a.x, a.y) + 0.5) / atlas, 0).a;
	float h10 = texture2DLod(normals, (vec2(b.x, a.y) + 0.5) / atlas, 0).a;
	float h01 = texture2DLod(normals, (vec2(a.x, b.y) + 0.5) / atlas, 0).a;
	float h11 = texture2DLod(normals, (vec2(b.x, b.y) + 0.5) / atlas, 0).a;

	return mix(mix(h00, h10, f.x), mix(h01, h11, f.x), f.y);
}




void main() 
{	
	if (PixelOutOfScreenBounds(preDownscaleProjPos)) {
		discard;
		return;
	}
	float lodOffset = 0.0;

	float gradMult = 1.0 / TEXTURE_LOD_BIAS;

	vec2 texGradX = dFdx(texcoord.st) * gradMult;
	vec2 texGradY = dFdy(texcoord.st) * gradMult;

	#ifdef ANISOTROPIC_LOD_BIAS
	if (length(texGradX) < length(texGradY)) {
		texGradY = texGradX;
	} else {
		texGradX = texGradY;
	}
	#endif

	vec2 textureCoordinate = texcoord.st;





	vec3 N;
	mat3 tbn;
	mat3 tbnRaw;
	CalculateNormalAndTBN(viewPos.xyz, texcoord.st, N, tbn, tbnRaw);

	#ifdef PARALLAX
		vec3 offsetCoord = vec3(0.0, 0.0, 1.0);
		vec3 pomViewPos = viewPos.xyz;
		{
			// ---- Bliss POM (exact port) ----
			vec2 pomCoord = fract(vtexcoord.st) * vtexcoordam.pq + vtexcoordam.st;
			vec3 pomViewVector = normalize(tbnRaw * viewPos.xyz);
			float pomDist = length(viewPos.xyz);
			textureCoordinate = pomCoord;

			if (pomDist < POM_MAX_DIST)
			{
				float depthmap = pomReadNormal(vtexcoord.st, texGradX, texGradY).a;

				if (pomViewVector.z < 0.0 && depthmap < 0.9999 && depthmap > 0.00001)
				{
					float noise = BlueNoiseTemporal(gl_FragCoord.xy / vec2(viewWidth, viewHeight)).x;

					// Adaptive step length (Bliss default)
					vec3 interval = (pomViewVector.xyz / -pomViewVector.z / float(POM_STEPS) * POM_DEPTH) * clamp(1.0 - pow(depthmap, 2.0), 0.1, 1.0);

					vec3 coord = vec3(vtexcoord.st, 1.0);
					coord += interval * noise;

					float sumVec = noise;
					for (int loopCount = 0; (loopCount < POM_STEPS) && (1.0 - POM_DEPTH + POM_DEPTH * pomReadNormal(coord.st, texGradX, texGradY).a) < coord.p && coord.p >= 0.0; ++loopCount)
					{
						coord = coord + interval;
						sumVec += 1.0;
					}

					if (coord.t < pomMinCoord)
					{
						if (pomReadTexture(vec2(coord.s, pomMinCoord), texGradX, texGradY).a == 0.0)
						{
							coord.t = pomMinCoord;
							discard;
						}
					}

					textureCoordinate = mix(fract(coord.st) * vtexcoordam.pq + vtexcoordam.st, pomCoord, max(pomDist - POM_MIX_DIST, 0.0) / (POM_MAX_DIST - POM_MIX_DIST));

					pomViewPos = viewPos.xyz + sumVec * (transpose(tbnRaw) * interval);
					// Lighting/GI rebuilds the surface position from the depth buffer. Bliss's full POM depth
					// would put that position inside the solid block (GI turns black), so only a small,
					// capped part of the displacement is written to depth. The texture offset stays exact Bliss.
					{
						vec3 pomDisp = pomViewPos - viewPos.xyz;
						float pomPerp = abs(dot(pomDisp, N));
						// Move straight along the face normal (never sideways along the view ray), so pixels at
						// block corners/edges stay inside their own block and don't pick up a false shadow.
						float pomSide = (dot(pomDisp, N) >= 0.0) ? 1.0 : -1.0;
						pomViewPos = viewPos.xyz + N * pomSide * min(pomPerp, POM_LIGHTING_DEPTH_CAP);
					}
					offsetCoord = vec3(0.0, 0.0, 1.0 - saturate((1.0 - coord.z) / POM_DEPTH));
				}
			}
		}
	#endif
	
	// #ifndef SKIP_AA
	// vec3 dither = BlueNoiseTemporal(abs(glPosition.xy / glPosition.w) * 1.0).rgb;
	// textureCoordinate = OffsetCoord(textureCoordinate, dither.x * texGradX * 1.0 + dither.y * texGradY * 1.0, 0);
	// #endif


	// vec4 albedo = GetSourceTexture(texture, textureCoordinate);

	vec4 albedo = textureGrad(texture, textureCoordinate, texGradX, texGradY);










	albedo *= color;

	vec2 mcLightmap = blockLight;



	float wetnessModulator = 1.0;

	vec3 rainNormal = vec3(0.0, 0.0, 0.0);
	#ifdef RAIN_SPLASH_EFFECT
	rainNormal = GetRainSplashNormal(worldPosition, worldNormal, wetnessModulator);
	#endif

	wetnessModulator *= saturate(worldNormal.y * 10.5 + 0.7);
	wetnessModulator *= saturate(abs(2.0 - materialIDs));
	wetnessModulator *= clamp(blockLight.y * 1.05 - 0.7, 0.0, 0.3) / 0.3;
	wetnessModulator *= saturate(wetness * 1.1 - 0.1);








	vec4 specTex = textureGrad(specular, textureCoordinate, texGradX, texGradY);
	#ifdef SPEC_SMOOTHNESS_AS_ROUGHNESS
	specTex.SPEC_CHANNEL_SMOOTHNESS = 1.0 - specTex.SPEC_CHANNEL_SMOOTHNESS;
	#endif
	specTex.SPEC_CHANNEL_SMOOTHNESS = specTex.SPEC_CHANNEL_SMOOTHNESS * 0.992; 								// Fix weird specular issue
	

	vec4 normalTex = textureGrad(normals, textureCoordinate, texGradX, texGradY) * 2.0 - 1.0;
	normalTex.xy = sign(normalTex.xy) * max(vec2(0.0), abs(normalTex.xy) - 0.003);

	float normalMapStrength = NORMAL_MAP_STRENGTH;
	#ifdef FORCE_WET_EFFECT
	normalMapStrength = mix(NORMAL_MAP_STRENGTH, 0.1, wetnessModulator * wetnessModulator * wetnessModulator * wetnessModulator);


	vec3 viewNormal = tbn * normalize(normalTex.xyz * vec3(normalMapStrength, normalMapStrength, 1.0) + rainNormal * wetnessModulator);
	#else
	// normalTex is already computed above (line 265) - do not redeclare it here,
	// that caused a duplicate-declaration compile error whenever FORCE_WET_EFFECT
	// was disabled, killing the whole gbuffers_terrain program.
	vec3 viewNormal;
	{
		const float eps = 0.00001;
		float cD = BilinearHeightSample(textureCoordinate);
		float rD = BilinearHeightSample(textureCoordinate + vec2(eps, 0.0));
		float uD = BilinearHeightSample(textureCoordinate + vec2(0.0, eps));

		float xDiff = (cD - rD) / eps;
		float yDiff = (cD - uD) / eps;

		vec3 heightNormal = normalize(vec3(2.0 * xDiff, 2.0 * yDiff, -4.0));

		viewNormal = tbn * heightNormal;
	}
	#endif
	
	// Get specular data from specular texture
	float smoothness = specTex.SPEC_CHANNEL_SMOOTHNESS;
	float metallic = specTex.SPEC_CHANNEL_METALNESS;
	float emissive = specTex.SPEC_CHANNEL_EMISSIVE;
	// Fix false-positive emissive on resource packs whose specular texture has no real
	// emissive data: an untouched channel commonly sits at 1.0 (fully opaque/white),
	// which would otherwise read as "fully emissive" everywhere.
	emissive -= step(0.999, emissive);

	#ifdef FORCE_WET_EFFECT
	if (isEyeInWater < 1)
	{
		smoothness = mix(smoothness, 1.0, saturate(wetnessModulator * 1.0 * saturate(1.0 - metallic)));
	}
	#endif

	// Darker albedo when wet
	albedo.rgb = pow(albedo.rgb, vec3(1.0 + wetnessModulator * (1.0 - metallic) * 0.1));




	// Fix impossible normal angles
	vec3 viewDir = -normalize(viewPos.xyz);
	vec3 relfectDir = reflect(-viewDir, viewNormal);
	// make outright impossible
	viewNormal.xyz = normalize(viewNormal.xyz + (N / (pow(saturate(dot(viewNormal, viewDir)) + 0.001, 0.5)) * 1.0));





	// vec3 analyticNormal = normalize(cross(dFdx(viewPos.xyz), dFdy(viewPos.xyz)));

	// albedo.rgb = analyticNormal.xyz * 0.5 + 0.5;
	// albedo.rgb *= 0.5;
	// albedo.rgb = vec3(0.1);
	// smoothness = 0.0;
	// metallic = 0.0;


	// metallic += 0.2;

	#ifdef WET_CAVE_EFFECT
	float caveDamp = 1.0 - metallic;
	caveDamp *= pow((1.0 - mcLightmap.y), 2.0);
	caveDamp *= pow((1.0 - mcLightmap.x), 1.0);
	smoothness = mix(smoothness, 1.0, 0.9 * caveDamp);
	#endif




	GBufferData gbuffer;
	gbuffer.albedo = albedo * 1.0;
	gbuffer.normal = viewNormal.xyz;
	gbuffer.mcLightmap = mcLightmap;
	gbuffer.smoothness = smoothness;
	gbuffer.metalness = metallic;
	gbuffer.materialID = (materialIDs + 0.1) / 255.0;
	gbuffer.emissive = saturate(emissive);
	#ifndef SPEC_EMISSIVE
	gbuffer.emissive = 0.0;
	#endif
	gbuffer.geoNormal = N.xyz;
	gbuffer.totalTexGrad = length(fwidth(texcoord.st)) * (256.0 / 8.0);




	// vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	// vec3 worldPosC = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
	// vec3 worldViewDir = normalize(worldPosC.xyz);

	// vec3 modifiedViewPos = (gbufferModelView * vec4(worldPos.xyz, 1.0)).xyz;


	// #ifdef PARALLAX
	// 	float NdotV = dot(worldNormal.xyz, -worldViewDir);

	// 	worldPos += normalize(worldPos) * (1.0 - offsetCoord.z) * 0.2 / (saturate(NdotV) + 0.00001);
	// 	modifiedViewPos = (gbufferModelView * vec4(worldPos.xyz, 1.0)).xyz;
	// #endif

	// vec4 projPos = gbufferProjection * vec4(modifiedViewPos.xyz, 1.0);
	// projPos /= projPos.w;
	// projPos = projPos * 0.5 + 0.5;

	// #ifdef PARALLAX
	// 	gl_FragDepth = projPos.z;
	// 	gbuffer.parallaxOffset = (1.0 - offsetCoord.z);
	// #else
	// 	gbuffer.parallaxOffset = 0.0;
	// #endif





	vec3 fuckingViewDir = normalize(viewPos.xyz);

	vec3 modifiedViewPos = viewPos.xyz;


	#ifdef PARALLAX
		modifiedViewPos = pomViewPos;
	#endif

	vec4 projPos = gbufferProjection * vec4(modifiedViewPos.xyz, 1.0);
	projPos /= projPos.w;
	projPos = projPos * 0.5 + 0.5;

	#ifdef PARALLAX
		gl_FragDepth = projPos.z;
		gbuffer.parallaxOffset = (1.0 - offsetCoord.z);
	#else
		gbuffer.parallaxOffset = 0.0;
	#endif


	vec3 worldPos = (gbufferModelViewInverse * vec4(modifiedViewPos.xyz, 1.0)).xyz;


	#ifdef PARALLAX_MOTION_VECTOR_FIX
	// Parallax is a view-dependent sub-pixel surface displacement. Do not feed
	// that displacement into the motion-vector calculation: the previous frame
	// has no matching parallax intersection, which can create huge false motion
	// vectors (especially near the top/edge of the screen) and make motion blur
	// / temporal filtering flicker. Keep the parallax-adjusted position for depth
	// and lighting, but calculate velocity from the underlying geometry position.
	{
		vec3 motionWorldPos = (gbufferModelViewInverse * vec4(viewPos.xyz, 1.0)).xyz;
		vec4 worldPosPrev = vec4(motionWorldPos + cameraPosition - previousCameraPosition, 1.0);
		vec4 viewPosPrev = gbufferPreviousModelView * worldPosPrev;
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		vec4 motionProjPos = gbufferProjection * vec4(viewPos.xyz, 1.0);
		motionProjPos /= motionProjPos.w;
		motionProjPos = motionProjPos * 0.5 + 0.5;

		gbuffer.motion = (motionProjPos.xyz - projPosPrev.xyz);
	}
	#else
	// Original behavior: motion vectors use the parallax-adjusted position.
	{
		vec3 worldPosPrev = worldPos + cameraPosition - previousCameraPosition;
		vec4 viewPosPrev = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
		vec4 projPosPrev = gbufferPreviousProjection * vec4(viewPosPrev.xyz, 1.0);
		projPosPrev.xyz /= projPosPrev.w;
		projPosPrev = projPosPrev * 0.5 + 0.5;

		gbuffer.motion = (projPos.xyz - projPosPrev.xyz);
	}
	#endif





	vec4 frag0, frag1, frag2, frag3;

	OutputGBufferDataSolid(gbuffer, frag0, frag1, frag2, frag3);

	gl_FragData[0] = frag0;
	gl_FragData[1] = frag1;
	gl_FragData[2] = frag2;
	gl_FragData[3] = frag3;

}

/* RENDERTARGETS: 0,1,2,8 */
#endif
