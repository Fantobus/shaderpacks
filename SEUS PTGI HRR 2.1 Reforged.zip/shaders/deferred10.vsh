#version 330 compatibility

#include "/program/deferred10.vsh.glsl"
