#version 330 compatibility

#define DIM_END 1
#include "/program/composite4.fsh.glsl"
