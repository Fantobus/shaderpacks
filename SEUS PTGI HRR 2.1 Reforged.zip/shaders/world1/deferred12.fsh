#version 330 compatibility

#define DIM_END 1
#include "/program/deferred12.fsh.glsl"
