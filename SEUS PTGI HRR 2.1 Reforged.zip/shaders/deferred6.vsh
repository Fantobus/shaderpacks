#version 330 compatibility

#include "/program/deferred6.vsh.glsl"
