#version 330 compatibility

#include "/program/deferred.vsh.glsl"
