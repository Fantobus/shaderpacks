#version 330 compatibility

#include "/program/gbuffers_skytextured.fsh.glsl"
