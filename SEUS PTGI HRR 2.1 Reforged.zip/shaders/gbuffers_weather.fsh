#version 120

#include "/program/gbuffers_weather.fsh.glsl"
