#version 330 compatibility

#include "/program/deferred5.vsh.glsl"
