#version 330 compatibility

#include "/program/composite12.vsh.glsl"
