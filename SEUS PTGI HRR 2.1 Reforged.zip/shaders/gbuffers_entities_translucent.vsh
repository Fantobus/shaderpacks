#version 330 compatibility

#include "/program/gbuffers_entities_translucent.vsh.glsl"
