#version 330 compatibility

#include "/program/deferred12.vsh.glsl"
