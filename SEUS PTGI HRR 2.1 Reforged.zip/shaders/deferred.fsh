#version 330 compatibility

#include "/program/deferred.fsh.glsl"
