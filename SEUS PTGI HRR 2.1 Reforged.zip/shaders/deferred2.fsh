#version 330 compatibility

#include "/program/deferred2.fsh.glsl"
